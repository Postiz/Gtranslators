$("document").ready(function(){
	var queryString = document.location.search;
	items = queryString.split("=");
	var disp = items[1];

	if(disp == 1){
		transApps();
	}else if(disp == 2){
		qualityStandards();
	}else if(disp == 3){
		payment();
	}else if(disp == 4){
		process();
	}else if(disp == 5){
		benifits();
	}else{
		transApps();
	}
});

function transApps(){
	document.title = 'Become an Transcree Translator translator';
	
	var idx = window.location.href.indexOf('pages/', 0);
	var URL = window.location.href.substring(0, idx) + 'translators/add';
	
	$("#div_list").html('<ul>'
						+ '<li>'
						+ '<a href="javascript:transApps();" style="font-weight: bold">Translator applications</a></li>'
						+ '<li>'
						+ '<a href="javascript:qualityStandards()">Quality standards</a></li>'
						+ '<li>'
						+ '<a href="javascript:payment()">Payment</a></li>'
						+ '<li>'
						+ '<a href="javascript:process()">Process</a></li>'
						+ '<li>'
						+ '<a href="javascript:benifits()">Benifits</a></li>'
						+ '<li>'
						+ '<a href="' + URL + '">Rigister now</a></li>'
						+ '</ul>');
	
	$("#title").html('<h2>Join our team</h2>');
	
	var txt = '';
	txt += '<h3>Never stop trying to be better.</h3>';
	txt += '<p>Welcome to the first 24-hour online translation agency. Transcree Translator works with the best translators worldwide to provide translations of any text at any time day or night.</p>';
	txt += '<p>Our vision is to improve a little more each day, and we hope that you will help us to achieve this goal.</p>';
	txt += '<hr/>';
	txt += '<br/>';	
	txt += '<p><b>Register now</b></p>';
	txt += '<a href="' + URL + '">Click here</a> to register as a Transcree Translator translator!';
	txt += '<br/><br/>';
	$("#form").html(txt);
}

function qualityStandards(){
	document.title = 'Transcree Translator quality standards';
	
	var idx = window.location.href.indexOf('pages/', 0);
	var URL = window.location.href.substring(0, idx) + 'translators/add';
	
	$("#div_list").html('<ul>'
			+ '<li>'
			+ '<a href="javascript:transApps();" >Translator applications</a></li>'
			+ '<li>'
			+ '<a href="javascript:qualityStandards()" style="font-weight: bold">Quality standards</a></li>'
			+ '<li>'
			+ '<a href="javascript:payment()">Payment</a></li>'
			+ '<li>'
			+ '<a href="javascript:process()">Process</a></li>'
			+ '<li>'
			+ '<a href="javascript:benifits()">Benifits</a></li>'
			+ '<li>'
			+ '<a href="' + URL + '">Rigister now</a></li>'
			+ '</ul>');
	
	$("#title").html('<h2>Quality control</h2>');
	
	var txt = '';
	txt += '<h3>All our translations are the same: professional and top quality. </h3>';
	txt += '<p>If you are a professional and experienced translator we will be happy to receive your application. Transcree Translator has high standards; join us and be among the best worldwide.</p>';
	txt += '<hr/>';
	txt += '<br/>';	
	txt += '<p><b>Jetzt anmelden</b></p>';
	txt += '<p>Register with Transcree Translator and benefit from our service now.&nbsp;<a href="' + URL + '">Click here to register</a></p>';
	txt += '<br/><br/>';
	$("#form").html(txt);
}

function payment(){
	document.title = 'Transcree Translator earnings';
	
	var idx = window.location.href.indexOf('pages/', 0);
	var URL = window.location.href.substring(0, idx) + 'translators/add';
	
	$("#div_list").html('<ul>'
			+ '<li>'
			+ '<a href="javascript:transApps();">Translator applications</a></li>'
			+ '<li>'
			+ '<a href="javascript:qualityStandards()">Quality standards</a></li>'
			+ '<li>'
			+ '<a href="javascript:payment()" style="font-weight: bold">Payment</a></li>'
			+ '<li>'
			+ '<a href="javascript:process()">Process</a></li>'
			+ '<li>'
			+ '<a href="javascript:benifits()">Benifits</a></li>'
			+ '<li>'
			+ '<a href="' + URL + '">Rigister now</a></li>'
			+ '</ul>');
	
	$("#title").html('<h2>Translation earnings</h2>');
	
	var txt = '';
	txt += '<h3>No costs, fair pay.</h3>';
	txt += '<p>We offer our customers a competitive service, but we also believe in fair pay for our translators. We calculate the earnings for each assignment according to the word count, language combination and text category.</p>';
	txt += '<br/>';
	txt += "<p>What 'fair' means: There is no fee for registration at tolingo, and you will always be told what you will be paid for an assignment before you accept it.</p>";
	txt += '<hr/>';
	txt += '<br/>';	
	txt += '<p><b>Register now</b></p>';
	txt += '<a href="' + URL + '">Click here</a> to register as a Transcree Translator translator!';
	txt += '<br/><br/>';
	$("#form").html(txt);
}

function process(){
	document.title = 'Transcree Translator procedures';
	
	var idx = window.location.href.indexOf('pages/', 0);
	var URL = window.location.href.substring(0, idx) + 'translators/add';
	
	$("#div_list").html('<ul>'
			+ '<li>'
			+ '<a href="javascript:transApps();" >Translator applications</a></li>'
			+ '<li>'
			+ '<a href="javascript:qualityStandards()">Quality standards</a></li>'
			+ '<li>'
			+ '<a href="javascript:payment()">Payment</a></li>'
			+ '<li>'
			+ '<a href="javascript:process()" style="font-weight: bold">Process</a></li>'
			+ '<li>'
			+ '<a href="javascript:benifits()">Benifits</a></li>'
			+ '<li>'
			+ '<a href="' + URL + '">Rigister now</a></li>'
			+ '</ul>');
	
	$("#title").html('<h2>Process</h2>');
	
	var txt = '';
	txt += '<h3>Fast-track translation.</h3>';
	txt += '<p>As an online agency, Transcree Translator can act faster and more efficiently than the conventional translation company and you will start to benefit from this as soon as you register. Simply fill out our online application form, submit your supporting documents and within a few hours you could be free to do the work that you enjoy most.</p>';
	txt += '<p>To take on new assignments, all you need to do is log into your Transcree Translator account. We support you throughout the translation process by providing you with a constant point of contact and facilitating communication between customer, translator and proofreader. Together we hope to exceed customer expectations, and to keep the customers coming back for more!</p>';
	txt += '<hr/>';
	txt += '<p><b>Register now</b></p>';
	txt += '<a href="' + URL + '">Click here</a> to register as a Transcree Translator translator!';
	txt += '<br/><br/>';
	
	$("#form").html(txt);
}

function benifits(){
	document.title = 'Transcree Translator advantages';
	
	var idx = window.location.href.indexOf('pages/', 0);
	var URL = window.location.href.substring(0, idx) + 'translators/add';
	
	$("#div_list").html('<ul>'
			+ '<li>'
			+ '<a href="javascript:transApps();" >Translator applications</a></li>'
			+ '<li>'
			+ '<a href="javascript:qualityStandards()">Quality standards</a></li>'
			+ '<li>'
			+ '<a href="javascript:payment()">Payment</a></li>'
			+ '<li>'
			+ '<a href="javascript:process()">Process</a></li>'
			+ '<li>'
			+ '<a href="javascript:benifits()" style="font-weight: bold">Benifits</a></li>'
			+ '<li>'
			+ '<a href="' + URL + '">Rigister now</a></li>'
			+ '</ul>');
	
	$("#title").html('<h2>The advantagest</h2>');
	
	var txt = '';
	txt += '<h3>Flexible working hours, guaranteed payment.</h3>';
	txt += '<p>Focus on what you are best at: translating. Transcree Translator does the customer acquisition and billing for you, so that you can devote your time to more important tasks, such as the perfect translation!</p>';
	txt += '<p>As a translator, you will be paid for your work every month without exception. Guaranteed.</p>';
	txt += '<hr/>';
	txt += '<br/>';	
	txt += '<p><b>Register now</b><br/></p>';
	txt += '<br/>';
	txt += '<a href="' + URL + '">Click here</a> to register as a Transcree Translator translator!';
	txt += '<br/><br/>';
	$("#form").html(txt);
}