$("document").ready(function()
{
	qualityControl();
});

function qualityControl(){
	document.title = 'High quality translations by Transcree Translator';
	
	$("#div_list").html('<ul>'
						+ '<li>'
						+ '<a href="javascript:qualityControl();" style="font-weight: bold">Quality control</a></li>'
						+ '<li>'
						+ '<a href="javascript:process()">Process</a></li>'
						+ '<li>'
						+ '<a href="javascript:specialistCats()">Specialist categories</a></li>'
						+ '<li>'
						+ '<a href="javascript:philosophy()">Philosophy</a></li>'
						+ '</ul>');
	
	$("#title").html('<h2>Quality control</h2>');
	
	var txt = '';
	txt += '<h3>Never stop trying to be better.</h3>';
	txt += '<p>Not only do we work with motivated and highly-qualified translators, but we also carry out rigorous quality control checks at every stage of the translation process. This ensures that our service meets the highest possible standards.</p>';
	txt += "<p>But that doesn't mean that everything at Transcree Translator is set in stone. We are constantly improving our service by re-evaluating our process, and listening to the feedback of our customers and translators.</p>";
	txt += '<p>No one translates like Transcree Translator</p>';
	
	txt += '<p>Our 6 golden rules:</p>';
	
	txt += '<ol>';
	txt += '<li><b>Native speakers</b><br />We have a strict policy of working exclusively with qualified translators and proofreaders who are native speakers of the target language.</li>';
	txt += '<li> <b>Proofreading</b><br />Every translation is proofread by a second equally qualified translator.</li>';
	txt += '<li> <b>The triple check</b><br />Your text will be checked for linguistic, stylistic and technical accuracy.</li>';
	txt += '<li> <b>Translation memory</b><br />Our translation memory system guarantees the right terminology for every text.</li>';
	txt += '<li> <b>Cost calculator</b><br />Our cost calculator gives you an instant and exact </li>quote. This price is fixed, so that you can manage your costs.</li>';
	txt += '<li> <b>Security</b><br />We protect your personal data at every stage; guaranteed.</li>';
	txt += '</ol>';
	$("#form").html(txt);
}

function process(){
	document.title = 'Our process';
	
	$("#div_list").html('<ul>'
			+ '<li>'
			+ '<a href="javascript:qualityControl();">Quality control</a></li>'
			+ '<li>'
			+ '<a href="javascript:process()" style="font-weight: bold">Process</a></li>'
			+ '<li>'
			+ '<a href="javascript:specialistCats()">Specialist categories</a></li>'
			+ '<li>'
			+ '<a href="javascript:philosophy()">Philosophy</a></li>'
			+ '</ul>');
	
	$("#title").html('<h2>Our Process</h2>');
	
	var txt = '';
	txt += '<h3> We want you to be happy</h3><p>At Transcree Translator your text is in safe hands. As soon as we receive your order we use strict criteria to select the best translator for your document. The category of the text, the language combination and the specialist knowledge requirements of the translator are all taken into account. Customer satisfaction is of utmost importance to us.</p><p>To ensure an optimal translation of your text, our account managers will contact you to clarify any issues that our translators encounter during their work.</p><p>During the proofreading stage of your order, your translator will work closely with a proofreader to check the quality and precision of the translation. Our quality control will then read the translation for technical, linguistic and stylistic accuracy, before the text is delivered to you. This comprehensive quality control procedure means that your order will not only be delivered in time, but also completed to the highest possible standards.</p>';
	$("#form").html(txt);
}

function specialistCats(){
	var URL = window.location.href;
	var idx = URL.indexOf('pages/quality', 0);
	URL = URL.substring(0, idx) + 'feedbacks/add';
	
	document.title = 'Profissional specialist translations by Transcree Translator';
	
	$("#div_list").html('<ul>'
			+ '<li>'
			+ '<a href="javascript:qualityControl();">Quality control</a></li>'
			+ '<li>'
			+ '<a href="javascript:process()">Process</a></li>'
			+ '<li>'
			+ '<a href="javascript:specialistCats()" style="font-weight: bold">Specialist categories</a></li>'
			+ '<li>'
			+ '<a href="javascript:philosophy()">Philosophy</a></li>'
			+ '</ul>');
	
	$("#title").html('<h2>Specialist categories</h2>');
	
	var txt = '';
	txt += '<h3> Any text, any language.</h3><h2 class="second">Specialist categories:</h2><p>If the category of your text is not listed here, please contact us using our <a href="#" class="contact">contact form</a></p><ol><li>Correspondence/Job applications</li><li>Economy/Business</li><li>Software/Internet</li><li>Industry/Technology</li><li>Marketing/PR</li><li>Tourism</li><li>Art/Culture</li><li>Architecture</li><li>Law</li><li>Politics</li><li>Medical Science/Pharmaceutical</li><li>Insurance/Finance</li><li>Science/Research</li><li>Environment/Energy</li><li>Private/Leisure</li></ol>';
	$("#form").html(txt);
}

function philosophy() {
	document.title = 'Transcree Translator philosofy';
	
	$("#div_list").html('<ul>'
			+ '<li>'
			+ '<a href="javascript:qualityControl();">Quality control</a></li>'
			+ '<li>'
			+ '<a href="javascript:process()">Process</a></li>'
			+ '<li>'
			+ '<a href="javascript:specialistCats()">Specialist categories</a></li>'
			+ '<li>'
			+ '<a href="javascript:philosophy()" style="font-weight: bold">Philosophy</a></li>'
			+ '</ul>');
	
	$("#title").html('<h2>Our Philosophy</h2>');
	
	var txt = '';
	txt += '<h3> Quality cannot be compromised.</h3>';
	txt += '<p>As an online translation office we are able to offer a faster and more direct service than the traditional translation agency. We have cut out bureaucracy to create a more flexible and transparent system, combined with fair pricing, for the benefit of both our customers and tranlators.</p><p>Our Vision:</p><p><b>We aim to provide fast translations without compromising on quality.</b></p>';
	txt += '<p>We believe that every text should be translated to the highest standard. For this reason, we carry out rigorous quality control checks at every stage of the translation process. Furthermore, we work with highly motivated and qualified translators to ensure that our service meets the highest possible standards.</p><p>But that does not mean that everything at Transcree Translator is set in stone. We are constantly improving our service by re-evaluating our process, and listening to the feedback of our customers. You are important to us. </p>';

	$("#form").html(txt);
}