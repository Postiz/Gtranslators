$("document").ready(function(){
	faq();
});

function faq(){
	document.title = 'F.A.Q about Transcree Translator translations';
	
	var URL = window.location.href;
	var idx = URL.indexOf('pages/questions', 0);
	URL = URL.substring(0, idx) + 'feedbacks/add';
	
	$("#div_list").html('<ul>'
						+ '<li>'
						+ '<a href="javascript:faq();" style="font-weight: bold">F.A.Q</a></li>'
						+ '<li>'
						+ '<a href="javascript:docFormat()">Document format</a></li>'
						+ '<li>'
						+ '<a href="javascript:expTranslations()">Express translations</a></li>'
						+ '<li>'
						+ '<a href="javascript:payment()">Methods of payment</a></li>'
						+ '</ul>');
	
	$("#title").html('<h2>F.A.Q</h2>');
	
	var txt = '';
	txt += '<h3> Frequently asked questions from Transcree Translator users</h3>';
	txt += '<ul><li><b>Who will translate my text?</b><br />Your text will be translated by one of our qualified and experienced translators. You can also request that your text be proofread by a senior translator.</li>';
	txt += '<li><b>How long will it take?</b><br />As soon as you place your order, we will give you an estimate of the processing time for your translation. Whilst we hope to deliver your text sooner than this, it can in some cases take longer. We always endeavour to complete your translation in the fastest possible time.</li><li><b>How will I know when it is finished?</b><br />As soon as your translation is finished, you will receive an e-mail containing a link which will take you directly to your translation.</li><li><b>Is it possible to get a faster translation?</b><br />If you need a really fast translation, then please contact us using the contact form and we will do our best to help you meet your deadline.</li><li><b>Do I have to pay to register at tolingo?</b><br />No, registration at our online translation platform is free for translators and customers alike.</li><li><b>Is there a minimum order?</b><br />Our only requirements are that the text contain at least three words, and that the value of the order is at least $5.</li><li><b>What happens to my private data?</b><br />tolingo requires your personal information to process your order. Your security is a priority for us, and we treat your data with the highest confidentiality. You can access and edit/delete your personal details at any time. Please see our terms and conditions for more detailed information.</li><li><b>How is the confidential information in the text secured?</b><br />All of our translators sign a confidentiality agreement before they start to work with us, and we trace all traffic on our site. Your text will be translated via our online software at tolingo.com, thereby avoiding third party downloading of your document.</li><li><b>The cost calculator can not read my text. What can I do?</b><br />If you encounter problems when uploadin your document, please send an e-mail to support@tolingo.com. We will find a solution and get back to you as soon as possible.</li><li><b>Is the quote from the cost calculator final, or are there any extra costs?</b><br />As soon as you enter your order details into the cost calculator you will receive a fixed net price for the translation. We guarantee that there are no additional or hidden costs. Then all you need to do is wait for your translation!</li></ul><h3>Further questions</h3><p>Should you have any further questions, please feel free to contact us using <a href="#" class="active">our contact form</a>.</p>';
	$("#form").html(txt);
}

function docFormat(){
	document.title = 'Translation of Word, PDF, XML and other files.';
	
	$("#div_list").html('<ul>'
			+ '<li>'
			+ '<a href="javascript:faq();">F.A.Q</a></li>'
			+ '<li>'
			+ '<a href="javascript:docFormat()" style="font-weight: bold">Document format</a></li>'
			+ '<li>'
			+ '<a href="javascript:expTranslations()">Express translations</a></li>'
			+ '<li>'
			+ '<a href="javascript:payment()">Methods of payment</a></li>'
			+ '</ul>');
	
	$("#title").html('<h2>Document formats</h2>');
	
	var txt = '';
	txt += '<h3> Whatever the format we willl find a solution.</h3>';
	txt += '<p>We can currently process the following formats; XML, Word, PDF files generated from Word, HTML and PowerPoint. Every PDF document is generated from a source file (e.g. Word). Our system will be able to recognise the orginal document.</p>';
	txt += '<p>If you have any further questions, please contact us using <a href="#">our contact form.</a>.</p>';

	$("#form").html(txt);
}

function expTranslations(){
	document.title = 'Express translations';
	
	$("#div_list").html('<ul>'
			+ '<li>'
			+ '<a href="javascript:faq();">F.A.Q</a></li>'
			+ '<li>'
			+ '<a href="javascript:docFormat()">Document format</a></li>'
			+ '<li>'
			+ '<a href="javascript:expTranslations()" style="font-weight: bold">Express translations</a></li>'
			+ '<li>'
			+ '<a href="javascript:payment()">Methods of payment</a></li>'
			+ '</ul>');
	
	$("#title").html('<h2>Express translations</h2>');
	
	var txt = '';
	txt += '<h3> At Transcree Translator fast means now.</h3><p>No bureaucracy; no delays. We deliver translations around the clock. Simply upload your text into our cost calculator for an estimate of the processing time.</p><p>If that is not fast enough, no problem, just use our express translations service!</p>';
	
	$("#form").html(txt);
}

function payment(){
	document.title = 'Payment methods';
	
	$("#div_list").html('<ul>'
			+ '<li>'
			+ '<a href="javascript:faq();">F.A.Q</a></li>'
			+ '<li>'
			+ '<a href="javascript:docFormat()">Document format</a></li>'
			+ '<li>'
			+ '<a href="javascript:expTranslations()">Express translations</a></li>'
			+ '<li>'
			+ '<a href="javascript:payment()" style="font-weight: bold">Methods of payment</a></li>'
			+ '</ul>');
	
	$("#title").html('<h2>Methods of payment</h2>');
	
	var txt = '';
	txt += '<h3>How would you like to pay?</h3>';
	txt += '<p>For customers outside of Germany, we currently accept the following methods of payment:<p>';
	txt += '<ul>';
	txt += '<li>credit card</li>';
	txt += '<li>PayPal</li>';
	txt += '</ul>';
	txt += '<p>You can also transfer payment (EU), but please note that your order will not be activated until the payment reaches our account.</p>';
	txt += '<br/>';
	txt += '<br/>';
	$("#form").html(txt);
}