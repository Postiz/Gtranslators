$("document").ready(function(){
	$("#sendFeedbackForm").validate();	
});