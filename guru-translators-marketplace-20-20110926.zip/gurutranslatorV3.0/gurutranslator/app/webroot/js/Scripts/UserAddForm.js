$("document").ready(function(){
	$(function() {
		// a workaround for a flaw in the demo system (http://dev.jqueryui.com/ticket/4375), ignore!
		$("#dialog").dialog("destroy");
	
		$("#dialog-general-terms").dialog({
			height: 140,
			width: 600,
			modal: true,
			bgiframe: true,
			autoOpen: false
		});
		
		$("#dialog-data-protection").dialog({
			height: 140,
			width: 600,
			modal: true,
			bgiframe: true,
			autoOpen: false
		});
	});
	
	$("#div_accept").hide();
	$("#div_passError").hide();
	
	$("#UserAddForm").validate();
	
	$("#UserAddForm").submit(function(e){
		$("#div_accept").hide();
		if(!$("#UserAccepted").is(':checked')){
			$("#div_accept").show();
			e.preventDefault();
            return false;
		}else{
			if ($("#UserPassword").val().length < 6) {
	            $("#div_passError").show();
	            e.preventDefault();
	            return false;
			}else{
				$("#div_passError").hide();
			}
		}
	});
	
	$("#UserUsername").change(function(){
		checkEmailExists();
	});
	
	$("#div_email_exists").hide();
	$("#div_email_available").hide();
	
	$("#sidebar").append($.cookie("sidebar"));
});

function checkEmailExists(){
	var URL = window.location.href;
	var reqURL = URL.substring(0, URL.indexOf('add', 0)) + 'checkEmailExists/' + $("#UserUsername").val();
	$.ajax({
    	type: 'POST',
    	url: reqURL,
    	success: function(data){
			var msg;
			if(data == true){
				$("#div_email_exists").show();
				$("#div_email_available").hide();
			}else{
				$("#div_email_available").show();
				$("#div_email_exists").hide();
			}
	    },
	    error: function(message){
	        alert(message);
	    }
	});
}

function showDialogGeneral(){
	$("#dialog-general-terms").dialog('open');
}

function showDialogDataProtec(){
	$("#dialog-data-protection").dialog('open');
}