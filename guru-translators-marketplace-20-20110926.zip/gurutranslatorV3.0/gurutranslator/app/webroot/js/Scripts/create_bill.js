$("document").ready(function(){
	
	$("#PaymentMethod").change(function(){
		paymentMethodChanged();
	});
});

function paymentMethodChanged(){
	if($("#PaymentMethod").val() == 0){
		$("#paymentInfo").html('After payment by PayPal, your orders instantly will be activated and processed without any delay. Please note that the additional PayPal fees will be added to your bill.'
								+ '<br/><br/>'
								+ '<div align="right">'
								+ '<img src="/tolingo/img/payment_methods.gif" alt="" />');
		$("#div_credit_form").html('');
	}else{
		$("#paymentInfo").html('After payment by credit card your orders will be instantly  activated and processed without any delay. The total bill will be deducted from your credit card.');
		
		var txt = '';
		txt += '<br/><br/><hr/><br/>';
		txt += '<font size="3">Credit card payment</font>';
		txt += '<br/><br/>';
		txt += '<table width="100%">';
		txt += '<tr><td>Credit card*:</td>';
		txt += '<td><div class="input text"><input name="data[createBill][CreditCardType]" type="text" class="required" id="createBillCreditCardType" /></div></td></tr>';
		txt += '<tr><td>Card holder*:</td>';
		txt += '<td><div class="input text"><input name="data[createBill][CreditCardHolder]" type="text" class="required" id="createBillCreditCardHolder" /></div></td></tr>';
		txt += '<tr><td>Card number*:</td>';
		txt += '<td><div class="input text"><input name="data[createBill][CreditCardNumber]" type="text" class="required" id="createBillCreditCardNumber" /></div></td></tr>';
		txt += '<tr><td valign="top">Expiry date*:</td>';
		txt += '<td><div class="input select"><select name="data[createBill][CreditCardExpMonth]" class="required" id="createBillCreditCardExpMonth">';
		txt += '<option value="0">teet</option></select></div>&nbsp;&nbsp;';
		txt += '<div class="input select"><select name="data[createBill][CreditCardExpYear]" class="required" id="createBillCreditCardExpYear">';
		txt += '<option value="0">teet</option></select></div></td></tr>';
		txt += '<tr><td>Security code*:</td>';
		txt += '<td><div class="input text"><input name="data[createBill][CreditCardSecode]" type="text" class="required" id="createBillCreditCardSecode" /></div></td></tr></table>';
		
		$("#div_credit_form").html(txt);
	}
}