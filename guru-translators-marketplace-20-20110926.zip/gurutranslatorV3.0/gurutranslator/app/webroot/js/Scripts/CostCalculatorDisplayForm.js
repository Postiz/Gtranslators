$("document").ready(function(){
	$("#CostCalculatorDisplayForm").validate();
	
	fillLangs(true);
	fillCategories();
	
	$("#CostCalculatorTrgtLang").hide();
	
	$("#CostCalculatorSrcLang").change(function(){
		showHideTargetLang();
	});
	
	$("#CostCalculatorInputText").change(function(){
		calcCost();
	});
});

function fillLangs(src){
	var URL = window.location.href;
	var idx = URL.indexOf('pages/home', 0);
	var reqURL;
	
	if(idx == -1){
		idx = URL.indexOf('#', 0);
		if(idx == -1){
			reqURL = URL + 'languages/listLanguages';
		}else{
			reqURL = URL.substring(0, URL.indexOf('#', 0)) + 'languages/listLanguages';
		}
	}else{
		reqURL = URL.substring(0, URL.indexOf('pages/home', 0)) + 'languages/listLanguages';
	}
	 
	$.ajax({
    	type: 'POST',
    	url: reqURL,
    	dataType: 'json',
    	success: function(data){
			if(data.length != 0){
				var languages = "";
				if(src){
					languages += '<option value="">Original languages</option>';
				}else{
					languages += '<option value="">Target languages</option>';
				}
				$.each(data, function(){
					languages += '<option value="' + this['Language']['id'] + '">' + this['Language']['name'] + '</option>';						
				});
				if(src){
					$("#CostCalculatorSrcLang").append(languages);
				}else{
					$("#CostCalculatorTrgtLang").append(languages);
				}
			}
		}
	});	
}

function fillCategories(){
	var URL = window.location.href;
	var idx = URL.indexOf('pages/home', 0);
	var reqURL;
	if(idx == -1){
		idx = URL.indexOf('#', 0);
		if(idx == -1){
			reqURL = URL + 'categories/listCategories';
		}else{
			reqURL = URL.substring(0, URL.indexOf('#', 0)) + 'categories/listCategories';
		}
	}else{
		reqURL = URL.substring(0, URL.indexOf('pages/home', 0)) + 'categories/listCategories';
	}
	
	$.ajax({
    	type: 'POST',
    	url: reqURL,
    	dataType: 'json',
    	success: function(data){
			if(data.length != 0){
				var cats = "";
				cats += '<option value="">Category</option>';				
				$.each(data, function(){
					cats += '<option value="' + this['Category']['id'] + '">' + this['Category']['name'] + '</option>';						
				});
				$("#CostCalculatorCategory").append(cats);
			}
		},
		error: function(message){
	        //alert(message);
	    }
	});
}

function showHideTargetLang(){
	if($("#CostCalculatorSrcLang").val() != ""){
		fillLangs(false);
		$("#CostCalculatorTrgtLang").addClass('required');
		$("#CostCalculatorTrgtLang").show();
	}else{
		$("#CostCalculatorTrgtLang").hide();
		$("#CostCalculatorTrgtLang").html('');
		$("#CostCalculatorTrgtLang").removeClass('required');
	}
}

function uploadFileText(){
	if($("#x").html() == 'Upload file'){
		$("#x").html('Enter text');
		$("#div_fileText").html('<br/><input type="file" name="srcFile"><br/><br/><font size="1">Supported file formates:</font><br/>.doc, .docx, .xml, .pdf, .rtf or .txt');
	}else{
		$("#x").html('Upload file');
		$("#div_fileText").html('<textarea id="CostCalculatorInputText" class="required" cols="20" rows="5" name="data[CostCalculator][input_text]"></textarea>');
	}		
}

function calcCost(){
	if($("#CostCalculatorSrcLang").val() == ""){
		var count = $("#CostCalculatorInputText").val().split(" ");
		if(count.length == 1){
			$("#div_price").html('1 Word');
		}else{
			$("#div_price").html(count.length + ' Words');
		}
	}
}