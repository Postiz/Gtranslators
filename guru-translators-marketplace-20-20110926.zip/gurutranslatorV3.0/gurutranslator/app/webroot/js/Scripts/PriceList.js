$("document").ready(function(){	
	buildList();
});

function buildList(){

	var idx = window.location.href.indexOf('prices', 0);
	var URL = window.location.href.substring(0, idx) + 'pages/prices';
	
	$("#sidebar").html('<h3>Price</h3><ul class="list">'
						+ '<li>'
						+ '<a href="' + URL + '?disp=1' + '">Pricing</a></li>'
						+ '<li>'
						+ '<a href="' + URL + '?disp=2' + '">Cost calculator</a></li>'
						+ '<li>'
						+ '<a href=# style="font-weight: bold">Pric list</a></li>'
						+ '</ul><h3>Cost calculator </h3><p>Quick and convenient way of testing the costs of your translation.<a href="#">Calculate</a></p>');
}