$(document).ready(function(){
	$("#BidAddForm").validate();
});