$(document).ready(function(){
	$("#credit").hide();
	$("#row_credit").hide();
	
	$(".radio").change(function(){
		if ($("input[@name='payment']:checked").val() == 'p'){
	        $("#paypal").show();
	        $("#credit").hide();
	        $("#row_credit").hide();
	    }else if ($("input[@name='payment']:checked").val() == 'c'){
	    	$("#paypal").hide();
	        $("#credit").show();
	        $("#row_credit").show();
	    }
	});
});