$(document).ready(function(){
	$("#AdminAddForm").validate();
});