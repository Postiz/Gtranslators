$("document").ready(function(){	
	
	buildList();
	
	$("#div_accept").hide();
	$("#div_passError").hide();
	
	$("#TranslatorAddForm").submit(function(e){
		$("#div_accept").hide();
		if(!$("#TranslatorAccept1").is(':checked') || !$("#TranslatorAccept2").is(':checked')){
			$("#div_accept").show();
			e.preventDefault();
            return false;
		}else{
			if ($("#TranslatorPassword").val().length < 6) {
	            $("#div_passError").show();
	            e.preventDefault();
	            return false;
			}else{
				$("#div_passError").hide();
			}
		}
	});
	
	$("#div_email_exists").hide();
	$("#div_email_available").hide();
	
	$("#TranslatorUsername").change(function(){
		checkEmailExists();
	});
	
	$('#TranslatorAddForm').validate();
	
	$(function() {
		// a workaround for a flaw in the demo system (http://dev.jqueryui.com/ticket/4375), ignore!
		$("#dialog").dialog("destroy");
	
		$("#dialog-general-terms").dialog({
			height: 140,
			width: 600,
			modal: true,
			bgiframe: true,
			autoOpen: false
		});
		
		$("#privacy-policy").dialog({
			height: 140,
			width: 600,
			modal: true,
			bgiframe: true,
			autoOpen: false
		});
		
		$("#confidentiality-agreement").dialog({
			height: 140,
			width: 600,
			modal: true,
			bgiframe: true,
			autoOpen: false
		});
	});
});

function checkEmailExists(){
	var URL = window.location.href;
	var reqURL = URL.substring(0, URL.indexOf('add', 0)) + 'checkEmailExists/' + $("#TranslatorUsername").val();
	$.ajax({
    	type: 'POST',
    	url: reqURL,
    	success: function(data){
			var msg;
			if(data == true){
				$("#div_email_exists").show();
				$("#div_email_available").hide();
			}else{
				$("#div_email_available").show();
				$("#div_email_exists").hide();
			}
	    },
	    error: function(message){
	        alert(message);
	    }
	});
}

function buildList(){
	var idx = window.location.href.indexOf('/translators/add', 0);
	var URL = window.location.href.substring(0, idx) + '/pages/translators';
	
	$("#sidebar").html('<ul class="list">'
						+ '<li>'
						+ '<a href="' + URL + '?disp=1' + '">Translator applications</a></li>'
						+ '<li>'
						+ '<a href="' + URL + '?disp=2' + '">Quality standards</a></li>'
						+ '<li>'
						+ '<a href="' + URL + '?disp=3' + '">Payment</a></li>'
						+ '<li>'
						+ '<a href="' + URL + '?disp=4' + '">Process</a></li>'
						+ '<li>'
						+ '<a href="' + URL + '?disp=5' + '">Benifits</a></li>'
						+ '<li>'
						+ '<a href=# style="font-weight: bold">Register now</a></li>'
						+ '</ul>');
}

function showTerms(){
	$("#dialog-general-terms").dialog('open');
}

function showPrivacy(){
	$("#privacy-policy").dialog('open');
}

function showConfidentiality(){
	$("#confidentiality-agreement").dialog('open');
}