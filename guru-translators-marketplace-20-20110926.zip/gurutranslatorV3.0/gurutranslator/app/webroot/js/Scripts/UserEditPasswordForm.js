$(document).ready(function(){
	$("#UserEditPasswordForm").validate();
	$("#div_passError").hide();
	$("#UserEditPasswordForm").submit(function(e){
		$("#div_passError").hide();
		
			if ($("#UserNewPassword").val().length < 6) {
	            $("#div_passError").show();
	            e.preventDefault();
	            return false;
			}else{
				$("#div_passError").hide();
			}
		
	});
});