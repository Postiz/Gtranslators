$(document).ready(function(){
	$("#UserEditDetailsForm").validate();
	
	$("#UserNots").change(function(){
		if(!$("#UserNots").is(':checked')){
			$("#UserNotifications").val(0);
		}else{
			$("#UserNotifications").val(1);
		}
	});
});