$("document").ready(function(){
	$("#FeedbackAddForm").validate();	
});