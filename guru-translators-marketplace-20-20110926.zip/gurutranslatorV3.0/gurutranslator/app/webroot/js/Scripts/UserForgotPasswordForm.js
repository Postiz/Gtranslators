$(document).ready(function(){
	$("#UserForgotPasswordForm").validate();
});