$(document).ready(function(){
	$("#row_transSkills").hide();
	
	$('#TranslatorAddLanguagesForm').validate();
	
	$("#TranslatorBiling").change(function(){
		showHideSecondLang();
	});
	
	showHideTransSkills();
	buildToLangList();
	showHideSecondLang();
	
	$("#TranslatorFirstLanguageId").change(function(){
		showHideTransSkills();
		buildToLangList();
	});
	
	
});

function addLanguages(id){
	if($("#TranslatorSkillSrcLang").val() == null || $("#TranslatorSkillSrcLang").val() == ''){
		alert('Please select language');
		return false;
	}
	if($("#TranslatorTransLang").val() == null || $("#TranslatorTransLang").val() == ''){
		alert('Please select language');
		return false;
	}
	
	var URL = window.location.href;
	var reqURL = URL.substring(0, URL.indexOf('addLanguages', 0)) + 'addSkillLanguages' + '/' + id + '/' + $("#TranslatorSkillSrcLang").val() + '/' + $("#TranslatorTransLang").val();
	$.ajax({
    	type: 'POST',
    	url: reqURL,
    	dataType: 'json',
    	success: function(data){
			if(data.length != 0){
				var languages = "";				
				$.each(data, function(){
					languages += this['lang1']['name'] + '    ==>    ' + this['lang2']['name'];
					languages += '    <a href="javascript:removeLanguage(' + this['translator_skills']['id'] + ');">Delete</a>';
					languages += '<br/>';
				});
				$("#div_skills").html(languages);
			}
		}
	});
	
	return false;
}

function removeLanguage(skillID){
	var URL = window.location.href;
	var reqURL = URL.substring(0, URL.indexOf('addLanguages', 0)) + 'removeSkillLanguages' + '/' + skillID;
	$.ajax({
    	type: 'POST',
    	url: reqURL,
    	dataType: 'json',
    	success: function(data){
			if(data.length != 0){
				var languages = "";				
				$.each(data, function(){
					languages += this['lang1']['name'] + '    ==>    ' + this['lang2']['name'];
					languages += '    <a href="javascript:removeLanguage(' + this['translator_skills']['id'] + ');">Delete</a>';
					languages += '<br/>';
				});
				$("#div_skills").html(languages);
			}
		}
	});
}

function showHideTransSkills(){
	$("#TranslatorTransLang").html("");
	if($("#TranslatorSecondLanguageId").val() != null && $("#TranslatorSecondLanguageId").val() != ""){
		$("#TranslatorTransLang").append("<option value=" + $("#TranslatorSecondLanguageId").val() + ">" + $("#TranslatorSecondLanguageId :selected").text() + "</option>");
	}
	
	if($("#TranslatorFirstLanguageId").val() == null || $("#TranslatorFirstLanguageId").val() == ""){
		$("#row_transSkills").hide();		
	}else{
		$("#TranslatorTransLang").append("<option value=" + $("#TranslatorFirstLanguageId").val() + ">" + $("#TranslatorFirstLanguageId :selected").text() + "</option>");
		
		$("#row_transSkills").show();
	}
	/*if($("#TranslatorFirstLanguageId").val() == null || $("#TranslatorFirstLanguageId").val() == ""){
		$("#row_transSkills").html('');
	}else{
		var rowData = "";
		rowData += '<td colspan="3"><br/><hr/><br/>';
		rowData += '<font size="3">Please list your translation skills</font><br/><br/>';
		rowData += '<code>Please enter only translation skills for which you possess a perfect command. Your settings will be verified and approved by the Guru Translator team. </code><br/>';
		rowData += 'Enter skills:&nbsp;&nbsp;&nbsp;&nbsp;';
		rowData += '<select id="fromLang"></select>&nbsp;&nbsp;';
		rowData += '&nbsp;&nbsp;to&nbsp;&nbsp;<select id="toLang"></select>&nbsp;&nbsp;';
		rowData += '<a href="#">Add language</a>';
		rowData += '</td>';
		
		var URL = window.location.href;
		var reqURL = URL.substring(0, URL.indexOf('translators/', 0)) + 'languages/listLanguages'; 
		$.ajax({
	    	type: 'POST',
	    	url: reqURL,
	    	dataType: 'json',
	    	success: function(data){
				if(data.length != 0){
					var languages = "";
					languages += '<option value="">-- Choose Language --</option>';
					$.each(data, function(){
						languages += '<option value="' + this['Language']['id'] + '">' + this['Language']['name'] + '</option>';						
					});
					$("#fromLang").html(languages);
				}
			}
		});
		
		$("#row_transSkills").html(rowData);
	}*/
}

function showHideSecondLang(){
	if(!$("#TranslatorBiling").is(':checked')){
		$("#row_secondLang").html('');
		$("#row_secLanguageDesc").html('');
	}else{		
		var URL = window.location.href;
		var reqURL = URL.substring(0, URL.indexOf('translators/', 0)) + 'languages/listLanguages'; 
		reqURL = "http://" + window.location.host + "/" + reqURL;
		$.ajax({
	    	type: 'POST',
	    	url: reqURL,
	    	dataType: 'json',
	    	success: function(data){
				if(data.length != 0){
					var languages = "";
					languages += '<div "input select">';
					languages += '<select id="TranslatorSecondLanguageId" class="required" name="data[Translator][second_language_id]">';
					languages += '<option value="">-- Choose Second Language --</option>';
					$.each(data, function(){
						languages += '<option value="' + this['Language']['id'] + '">' + this['Language']['name'] + '</option>';						
					});
					languages += '</select>';
					languages += '</div>';
				}
				
				var rowData = "";
				rowData += "<td>Second language:</td>";
				rowData += "<td>";
				rowData += languages;
				rowData += "</td>";				
				$("#row_secondLang").html(rowData);
				
				$("#TranslatorSecondLanguageId").change(function(){
					buildToLangList();
				});
				
				rowData = "";
				rowData += '<td valign="top" width="35%">Please tell us why you have two first languages:</td>';
				rowData += '<td colspan="2"><textarea id="TranslatorBilingualDesc" rows="10" cols="35" class="required" maxlength="5000" name="data[Translator][bilingual_desc]"></textarea></td>';
				$("#row_secLanguageDesc").html(rowData);
				
				$("#TranslatorSecondLanguageId").change(function(){
					$("#TranslatorTransLang").html("");
					if($("#TranslatorFirstLanguageId").val() != null && $("#TranslatorFirstLanguageId").val() != ""){
						$("#TranslatorTransLang").append("<option value=" + $("#TranslatorFirstLanguageId").val() + ">" + $("#TranslatorFirstLanguageId :selected").text() + "</option>");
					}
					
					if($("#TranslatorSecondLanguageId").val() != null && $("#TranslatorSecondLanguageId").val() != ""){
						$("#TranslatorTransLang").append("<option value=" + $("#TranslatorSecondLanguageId").val() + ">" + $("#TranslatorSecondLanguageId :selected").text() + "</option>");			
					}
				});
		    },
		    error: function(message){
		        alert(message);
		    }
		});
	}
}

function buildToLangList(){
	$("#toLang").html('');
	
	if($("#TranslatorFirstLanguageId").val() != "" || $("#TranslatorFirstLanguageId").val() != null){
		$("#toLang").html('<option value="' + $("#TranslatorFirstLanguageId").val() + '">' + $("#TranslatorFirstLanguageId option:selected").text() + '</option>');
	}
	
	if($("#TranslatorSecondLanguageId").val() != "" || $("#TranslatorSecondLanguageId").val() != null){
		$("#toLang").append('<option value="' + $("#TranslatorSecondLanguageId").val() + '">' + $("#TranslatorSecondLanguageId option:selected").text() + '</option>');
	}
}