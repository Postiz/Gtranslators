$(document).ready(function(){
	$(".check").click(function(){
		checkBoxClicked(this);
	});
	
	$("#quotes").click(function(){
		total = Number($("#JobTotal").val());
		if(total == 0){
			alert('Please select at least one order');
			return false;
		}
	});
});

function checkBoxClicked(checkBox){
	total = Number($("#JobTotal").val());
	
	if(!$(checkBox).is(':checked')){
		total -= Number($(checkBox).val());
		total = Math.round(total * 100)/100;
		$("#price").html(total + '&nbsp;$');
		$("#JobTotal").val(total);
		setKey($(checkBox).attr('id'), false);
	}else{
		total += Number($(checkBox).val());
		total = Math.round(total * 100)/100;
		$("#price").html(total + '&nbsp;$');
		$("#JobTotal").val(total);
		setKey($(checkBox).attr('id'), true);
	}
	
	$("#JobSelectAll").val(false);
}

function setKey(jobID, set){
	var URL = window.location.href;
	var reqURL;
	
	if(set){
		reqURL = URL.substring(0, URL.indexOf('customerJobs', 0)) + 'setJobKey/' + jobID + '/' + $("#key").val();
	}else{
		reqURL = URL.substring(0, URL.indexOf('customerJobs', 0)) + 'setJobKey/' + jobID + '/null';
	}
	$.ajax({
    	type: 'POST',
    	url: reqURL,
    	success: function(data){
			
	    },
	    error: function(message){
	        alert(message);
	    }
	});
}

function selectAll(){
	if($("#JobSelectAll").val() != 0){
		$('.check').attr('checked', true);
		$('.check').each(function(){
			setKey($(this).attr('id'), true);
		});
		$("#JobSelectAll").val(0);
		$("#JobTotal").val($("#JobTotal2").val());
		$("#price").text($("#JobTotal2").val() + ' $');
	}else{
		$('.check').attr('checked', false);
		$('.check').each(function(){
			setKey($(this).attr('id'), false);
		});
		$("#JobSelectAll").val(1);
		$("#JobTotal").val(0);
		$("#price").text('0 $');
	}
}