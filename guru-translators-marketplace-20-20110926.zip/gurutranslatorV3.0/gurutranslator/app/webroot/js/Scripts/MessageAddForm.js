$(document).ready(function(){
	$("#MessageAddForm").validate();
});