$(document).ready(function(){
	$("#BidEditForm").validate();
});