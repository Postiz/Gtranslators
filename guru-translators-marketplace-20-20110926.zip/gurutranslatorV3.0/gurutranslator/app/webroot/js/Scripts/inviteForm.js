$("document").ready(function(){
	$("#company_inviteForm").validate();
	showHideMsgRow();
	$("#editMsg").change(function(){
		showHideMsgRow();
	});
	
	$(".radioMsgLang").change(function(){
		createMsg();
	});
});

function showHideMsgRow(){
	createMsg();
	
	if(!$("#editMsg").is(':checked')){
		$("#row_msg1").hide();
		$("#row_msg2").hide();
	}else{
		$("#row_msg1").show();
		$("#row_msg2").show();
	}	
}

function createMsg(){
	switch ($("#msgLang:checked").val()) {
		case 'E':
			$("#textMsg").val('English message');
			break;
			
		case 'F':
			$("#textMsg").val('Frensh message');		
			break;
					
		case 'I':
			$("#textMsg").val('Italian message');
			break;
			
		case 'G':
			$("#textMsg").val('German message');
			break;
			
		case 'P':
			$("#textMsg").val('Polish message');
			break;
	}
}