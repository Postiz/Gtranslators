$('document').ready(function(){
	$("#JobJobSettingsForm").validate();
	$("#sidebar").html($.cookie("sidebar"));
	$("#div_period").html("<p>"+$.cookie("period")+"</p>");
	$("#div_word_count").html("<p>"+$.cookie("UploadFileSize")+"</p>");
	$("#div_price").html($.cookie("totalCost"));
	
	$("#JobOrderTitle").counter({
	    type: 'char',
	    goal: 60,
	    count: 'down'           
	});
	
	$("#JobOrderBrief").counter({
	    type: 'char',
	    goal: 1000,
	    count: 'down'           
	});
});