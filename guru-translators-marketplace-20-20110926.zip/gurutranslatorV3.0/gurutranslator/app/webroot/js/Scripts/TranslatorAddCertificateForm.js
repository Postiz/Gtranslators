$(document).ready(function(){
	$("#TranslatorAddCertificateForm").ajaxStop(function() {
		
		/*var URL = window.location.href;
		var reqURL = URL.substring(0, URL.indexOf('addCertificate', 0)) + 'getFileName';
		$.ajax({
	    	type: 'POST',
	    	url: reqURL,
	    	success: function(data){
				alert(data);
		    },
		    error: function(message){
		        alert(message);
		    }
		});*/
    });
});

function removeFile(file, id){
	var URL = window.location.href;
	var reqURL = URL.substring(0, URL.indexOf('addCertificate', 0)) + 'removeFile/' + file + '/' + id;
	$.ajax({
    	type: 'POST',
    	url: reqURL,
    	success: function(data){
			alert(data);
	    },
	    error: function(message){
	        alert(message);
	    }
	});
}