$('document').ready(function(){
	translationService();
});

function translationService(){
	$("#div_service").html("<p><b>Translation service:</b><br/>If you need fast, high quality translation Guru Translator is the translator for you. We offer a wide range of languages and our sophisticated online system allows your document to be passed onto a professional translator and processed in the shortest possible time. More information about <a href=#>translation services</a></p>.");
}

function technicalTranslation(){
	$("#div_service").html("<p><b>Technical translation:</b><br/>A technical translation needs a translator with specialist knowledge and skills. Some popular translation offices are unable to process technical documents because this demands an excellent technical vocabulary. Guru Translator will find you a technical translator who meets your requirements with the lowest possible cost to you. More information about <a href=#>technical translation</a>."
							+ "<br/><b>Professional technical translation:</b>Our translators translate even the most complex and high level technical documents</p>");
}

function translationGermanEnglish(){
	$("#div_service").html("<p><b>Translation German - English:</b><br/>If you need an English-German translation then you can trust tolingo. Our English-German translators deliver a fast and competent translation of your text. Our certified translators also offer you fast and high quality translations to and from many other languages for the best possible price. More information about <a href=#>English German translation</a>."
							+ "<br/><b>tolingo.com:</b>"
							+ "The professional translation office for you also has an express service for English and many more languages</p>");
}

function EnglishSpanish(){
	$("#div_service").html("<p><b>English - Spanish:</b><br/>Besides fast and high quality English-Spanish translations our certified English-Spanish translators also offer you fast and high quality translations to and from many other languages for the best possible price. More information about <a href=#>English Spanish translation</a>."
							+ "<br/><b>English - Russian:</b> Our English-Russian translators will deliver a competent and fast translation of your text. If needed also from Russian to English.</p>");
}

function websiteTranslation(){
	$("#div_service").html("<p><b>Website translation:</b><br/>tolingo is an expert when it comes to web site translation. As an internet platform for translation services, Guru Translator understands how important your website is to the success of your company. Our team of website translators has a lot of experience in web page translation. Our vast translator team also allows us to translate websites around the clock to guarantee you a fast translation service. Whatever your translation needs, Guru Translator will find the best web page translator for you. More information about <a href=#>Website translation</a>."
							+ "<br/>tolingo in your language: <a href=#>tolingo Ubersetzungen</a> | <a href=#>tolingo traduzione</a> | <a href=#>tolingo traduction</a> | <a href=#>tolingo tumaczenia</a></p>");
}

function documentTranslationServices(){
	$("#div_service").html("<p><b>Document translation services:</b><br/>tolingo offers document translation for a wide range of document types and formats. Our team of translators collectively span a broad spectrum of languages and specialist fields. So regardless of whether you need a Spanish document translation for a newsletter, or a legal document translation in English Guru Translator is the document translation service for you. We offer a fast and efficient service without compromising on quality. More information about <a href=#>document translation</a>."
							+ "<br/><b>Easy and professional translation:</b> Simply upload your document into our cost calculator to receive an instant quote to translate your document.</p>");
}

function translationRates(){
	$("#div_service").html("<p><b>Translation rates:</b><br/>tolingo offers very competitive translation charges. As an online office we are able to cut down on paperwork and therefore save money to benefit our customers. But even though the translation fees at Guru Translator are competitively low, we in no way compromise on quality. Every translation is thoroughly checked for stylistic, grammatic and technical accuracy before it is delivered to the customer and we also offer a proofreading service for additional security. The translation rate at Guru Translator therefore represents cost efficiency on all levels. Use the cost calculator on our home page to get an instant translation quote for your text. More information about <a href=#>translation rates</a>."
							+ "<br/><b>Get your instant quote online:</b> Simply upload your document into our cost calculator to receive an instant quote.</p>");
}

function EnglishTextTranslation(){
	$("#div_service").html("<p><b>English text translation:</b><br/>tolingo is an online translation agency that offers a high quality English text translation service into many different languages. We work exclusively with native speakers of the target language to ensure that the translated text is as good as the original. Whilst we can�t translate text instantly, we will give you an instant quote and guarantee a very fast text translation without drawbacks on quality. More information about <a href=#>English text translation</a>."
							+ "<br/><b>Translate text:</b> Whatever the nature of your text, be it general or more specialist, Guru Translator can find the English text translator for you.</p>");
}

function freeTranslation(){
	$("#div_service").html("<p><b>Free translatione:</b><br/>tolingo provides a free translation tool which you can use to produce a computer-generated, <a href=#>free text translation</a> and <a href=#>free website translation</a>. But please be aware that machine translations cannot match the quality of the professional translations provided by our team of certified translators."
							+ "<br/>To our <a href=#>free translation tools</a></p>");
}

function onlineUbersetzungsburo(){
	$("#div_service").html("<p><b>Online Ubersetzungsburo:</b><br/>Ihr  <a href=#>Ubersetzungsburo tolingo.de</a> fur professionelle Deutsch Englich Ubersetzung und viel mehr. Muttersprachliche Online Fachubersetzungen, schnell und kompetent bei tolingo. Gearbeitet wird nach dem Vier-Augen-Prinzip. Ubersetzungen in samtliche Sprachen dieser Erde sind moglich, wie beispielsweise Ubersetzungen in Englisch, Franzosisch, Spanisch, Italienisch uva."
							+ "<br/>Copyright 2010 Guru Translator GmbH All rights reserved</p>");
}