$("document").ready(function(){
	$("#AdminLoginForm").validate();	
});