$('document').ready(function(){
	$("#JobEditForm").validate();
	
	$("#JobOrderTitle").counter({
	    type: 'char',
	    goal: 60,
	    count: 'down'           
	});
	
	$("#JobTranslatorBriefing").counter({
	    type: 'char',
	    goal: 1000,
	    count: 'down'           
	});
});