$("document").ready(function(){

	var queryString = document.location.search;

	items = queryString.split("=");

	var disp = items[1];

	

	if(disp == 1){

		pricing();

	}else if(disp == 2){

		costCalc();	

	}else{

		pricing();

	}

});



function pricing(){

	document.title = 'Guru Translator price information';

	

	var idx = window.location.href.indexOf('pages/', 0);

	var URL = window.location.href.substring(0, idx) + 'prices/index';

	

	$("#div_list").html('<ul>'

						+ '<li>'

						+ '<a href="javascript:pricing();" style="font-weight: bold">Pricing</a></li>'

						+ '<li>'

						+ '<a href="javascript:costCalc()">Cost calculator</a></li>'

						+ '<li>'

						+ '<a href="' + URL + '">Price list</a></li>'

						+ '</ul>');

	

	$("#title").html('<h2>Our Pricing</h2>');

	

	var txt = '';

	txt += '<h3>An efficient way to manage your costs.</h3>';

	txt += '<p>We take three factors into account when calculating the price of your translation: word count, text category and the combination of original and target language.</p>';

	txt += "<p>To get an instant and exact quote for your translation, simply enter or upload your text into our cost calculator. You will find further information about pricing on our <a href='" + URL + "'>price list page.</a></p>";

	txt += '<br/><br/>';	

	$("#form").html(txt);

}



function costCalc(){

	document.title = 'Guru Translator cost calculator';

	

	var idx = window.location.href.indexOf('pages/', 0);

	var URL = window.location.href.substring(0, idx) + 'prices/index';

	

	$("#div_list").html('<ul>'

			+ '<li>'

			+ '<a href="javascript:pricing();">Pricing</a></li>'

			+ '<li>'

			+ '<a href="javascript:costCalc()" style="font-weight: bold">Cost calculator</a></li>'

			+ '<li>'

			+ '<a href="' + URL + '">Price list</a></li>'

			+ '</ul>');

	

	$("#title").html('<h2>Cost calculator</h2>');

	

	var txt = '';

	txt += '<h3>Exact quote in Real-time.</h3>';

	txt += '<p>There is no need to wait for a quote at GuruTranslators. Just enter or upload your text into our cost calculator, and receive an instant quote for your translation. No rough estimates, no hidden expenses; know your exact costs from the word go.</p>';

	txt += '<p><a href="/pages/home">Click here to go to our calculator</a></p>';

	

	$("#form").html(txt);

}