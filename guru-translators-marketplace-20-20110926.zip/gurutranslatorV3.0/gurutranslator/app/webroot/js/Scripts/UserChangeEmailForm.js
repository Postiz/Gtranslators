$(document).ready(function(){
	$("#UserChangeEmailForm").validate();	
})