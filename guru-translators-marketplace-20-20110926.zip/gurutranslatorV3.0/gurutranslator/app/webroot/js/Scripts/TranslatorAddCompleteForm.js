$(document).ready(function(){
	$("#accept").hide();
	$("#TranslatorAddCompleteForm").submit(function(e){
		$("#accept").hide();
		if(!$("#TranslatorAccept").is(':checked')){
			$("#accept").show();
			e.preventDefault();
            return false;
		}
	});
});