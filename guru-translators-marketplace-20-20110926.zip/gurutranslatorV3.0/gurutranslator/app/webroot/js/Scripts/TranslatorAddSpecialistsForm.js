$("document").ready(function(){
	$(".specDesc").hide();
	$(".spec").change(function(){
		id = $(this).attr('id');
		options = $(this).attr('id').split('_');
		//alert(options[1]);
		if($(this).val() == 'E'){
			$("#div_specDesc" + options[1]).show();
		}else{
			$("#div_specDesc" + options[1]).hide();
		}
	});
});