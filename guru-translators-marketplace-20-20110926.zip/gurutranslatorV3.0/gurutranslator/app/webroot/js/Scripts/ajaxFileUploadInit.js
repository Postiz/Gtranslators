function ajaxFileUpload(page, destFolder, fileInputName, extensions){
	var URL = window.location.href;
	var reqURL = URL.substring(0, URL.indexOf(page, 0)) + 'uploadFile/' + destFolder + '/' + fileInputName + '/' + extensions;
	$.ajaxFileUpload({
		url:reqURL, //'doajaxfileupload.php',
		secureuri:false,
		async: false,
		cache: false,
		fileElementId: fileInputName, //'fileToUpload',
		dataType: 'json',
		success: function (data, status)
		{
			if(typeof(data.error) != 'undefined')
			{
				if(data.error != '')
				{
					alert(data.error);
				}else
				{
					alert(data.msg);
				}
			}
		},
		error: function (data, status, e)
		{
			//alert(data.length);
			alert(e);
		}
	});
	
	/*var URL = window.location.href;
	var reqURL = URL.substring(0, URL.indexOf('addCertificate', 0)) + 'getFileName';
	$.ajax({
    	type: 'POST',
    	url: reqURL,
    	success: function(data){
			alert(0);
			alert(data);
	    },
	    error: function(message){
	        alert(message);
	    }
	});*/
	return false;
}