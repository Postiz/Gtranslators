$(document).ready(function(){
	$("#AdminSetCommissionForm").validate();
});