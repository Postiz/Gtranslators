$(document).ready(function(){
	$("#PaymentRequestAddForm").validate();
});