$("document").ready(function(){
	$("#UserLoginForm").validate();	
});