$('document').ready(function(){
	$("#JobEnterTextForm").validate();
	writeQuote();
	showHideTrgtLang();
	$("#JobSrcLanguageId").change(function(){
		showHideTrgtLang();
		writeQuote();
		//zwriteQuote();
	});
	$("#JobTrgtLanguageId").change(function(){
		writeQuote();
	});
	$("file_upload").change(function(){
		writeQuote();
	});
});


function writeQuote(){
	var textValue = $("#next").val();
	
	var text = "";
	var tmp;
	
	var URL = window.location.href;
	var idx = URL.indexOf('jobs/enterText', 0);
	var reqURL = URL.substring(0, idx) + 'jobs/userdetail/';
	
	$.ajax({
		type: 'POST',
		url: reqURL,
		success: function(returnuser)
		{
			$("#loginuserdetail").attr('value',returnuser);
		}
	});
	
	if($("#JobSrcLanguageId").val() == "" || $("#JobSrcLanguageId").val() == null
			|| $("#JobTrgtLanguageId").val() == "" || $("#JobTrgtLanguageId").val() == null)
	{
		text += '<h3>Quote</h3>';
		text += '<p>To request a quote please select original and target language.</p>';

		if($("#loginuserdetail").val() == 0)
		{
			text1 = '<h3>Discount</font></h3>';
			text1 += "<p>Upload an email list as csv file and get 20% off on translation price</p>";
		}
		else if($("#loginuserdetail").val() == 1)
		{
			text1 = '<h3>Discount</font></h3>';
			text1 += "<p>You have uploaded csv file from now you will get the 20 %off on translation price</p>";
		}
	}
	/*
	if($("#JobInputTxt").val() != "" && $("#JobInputTxt").val() != null){

		var count = $("#JobInputTxt").val().split(" ");
		text += '<br/><br/>The text contains ';
		tmp = 'The text contains ';
		if(count.length == 1){
			text += '1 Word';
			tmp += '1 Word';
		}else{
			text += count.length + ' Words';
			tmp += count.length + ' Words';
		}
		$.cookie('wordsCount', tmp);
	}
	*/
	if($("#JobSrcLanguageId").val() != "" && $("#JobSrcLanguageId").val() != null
			&& $("#JobTrgtLanguageId").val() != "" && $("#JobTrgtLanguageId").val() != null
			&& $("#next").val() != "" && $("#next").val() != null){

		if(textValue != '')
		{
			var ajax = '';
			var URL1 = window.location.href;
			var idx1 = URL1.indexOf('jobs/enterText', 0);
			var reqURL1 = URL1.substring(0, idx1) + 'jobs/ajaxfilecalculation/'+textValue;
			var ajaxCount = '';

			var totalCost = 0;
			$.ajax({
				type: 'POST',
				url: reqURL1,
				success: function(data1){					
					ajaxCount = data1;
					var URL2 = window.location.href;
					var idx2 = URL2.indexOf('jobs/enterText', 0);
					var reqURL2 = URL2.substring(0, idx2) + 'prices/getPairPrice/' + $("#JobSrcLanguageId").val() + "/" + $("#JobTrgtLanguageId").val();
					var kbsize = $.cookie('kbsize');
					var totalCost = 0;
					$.ajax({
						type: 'POST',
						url: reqURL2,
						success: function(data){
							totalCost = ajaxCount * data * kbsize * 0.02;
							
							var mints = ajaxCount * 5;
							var hours = parseFloat(mints / 60).toFixed(2);

							if(hours < 24)
							{
								$.cookie('dayCounts',hours +" hours");	
							}
							else
							{
								var days = parseFloat(hours / 24).toFixed(1);
								$.cookie('dayCounts',days +" days");								
							}
							if($("#loginuserdetail").val() == 1)
							{
								discount = (totalCost * 20)/100;
								totalCost = totalCost - discount;
							}
							text += '<h3>Quote</h3>';
							text += '<p>Your order costs ';
							text += Math.round(totalCost, 2);
							text += '$ and will be finished during '+$.cookie('dayCounts')+'</p>';
							$.cookie('period', Math.round(totalCost, 2)+'$ and will be finished during '+$.cookie('dayCounts'));							
							$.cookie('totalCost', Math.round(totalCost, 2) + '$');
							
							
							var finalText = text + text1;
							$("#sidebar").html(finalText);

							$.cookie('sidebar', text);
							
						}
					});	
					
				}
			});
		}
		else
		{
		
			var URL = window.location.href;
			var idx = URL.indexOf('jobs/enterText', 0);
			var reqURL = URL.substring(0, idx) + 'prices/getPairPrice/' + $("#JobSrcLanguageId").val() + "/" + $("#JobTrgtLanguageId").val();
			
			var totalCost = 0;
			$.ajax({
				type: 'POST',
				url: reqURL,
				success: function(data){
					var count = $("#JobInputTxt").val().split(" ");
					totalCost = count.length * data;
					if($("#loginuserdetail").val() == 1)
					{
						discount = (totalCost * 20)/100;
						totalCost = totalCost - discount;
					}
					text += '<h3>Quote</h3>';
					text += '<p>Your order costs ';
					text += Math.round(totalCost, 2);
					text += '$ and will be finished during x days</p>';
					$.cookie('period', 'Your order will be finished during x days');
					
					$.cookie('totalCost', Math.round(totalCost, 2) + '$');
					
					
					$("#sidebar").html(text);
					
					$.cookie('sidebar', text);
					
					
				}
			});	
		}
		
	}
	
	
	
	var finalText = text + text1;
	$("#sidebar").html(finalText);

	$.cookie('sidebar', text);
}

function showHideTrgtLang(){
	if($("#JobSrcLanguageId").val() == null || $("#JobSrcLanguageId").val() == ""){
		$("#div_trgt_lang").html('Please select the original language first.');
	}else{
		var URL = window.location.href;
		var reqURL = URL.substring(0, URL.indexOf('jobs/', 0)) + 'languages/listLanguages'; 
		$.ajax({
	    	type: 'POST',
	    	url: reqURL,
	    	dataType: 'json',
	    	success: function(data){
				if(data.length != 0){
					var languages = "";
					languages += '<select id="JobTrgtLanguageId" class="required" name="data[Job][trgt_language_id]">';
					languages += '<option value="">-- Choose Target Language --</option>';
					$.each(data, function(){
						languages += '<option value="' + this['Language']['id'] + '">' + this['Language']['name'] + '</option>';						
					});
					languages += '</select>';
				}
				
				$("#div_trgt_lang").html(languages);
				
				$("#JobTrgtLanguageId").change(function(){
					writeQuote();
				});
		    },
		    error: function(message){
		        alert(message);
		    }
		});
	}
}