$("document").ready(function(){
	$(function() {
		// a workaround for a flaw in the demo system (http://dev.jqueryui.com/ticket/4375), ignore!
		$("#dialog").dialog("destroy");
	
		$("#dialog-modal-cust").dialog({
			height: 140,
			width: 600,
			modal: true,
			bgiframe: true,
			autoOpen: false
		});
		
		$("#dialog-modal-trans").dialog({
			height: 140,
			width: 600,
			modal: true,
			bgiframe: true,
			autoOpen: false
		});
		
		$("#dialog-modal-privacy").dialog({
			height: 140,
			width: 600,
			modal: true,
			bgiframe: true,
			autoOpen: false
		});
	});
});

function showDialogCust(){
	$("#dialog-modal-cust").dialog('open');
}

function showDialogTrans(){
	$("#dialog-modal-trans").dialog('open');
}

function showDialogPrivacy(){
	$("#dialog-modal-privacy").dialog('open');
}