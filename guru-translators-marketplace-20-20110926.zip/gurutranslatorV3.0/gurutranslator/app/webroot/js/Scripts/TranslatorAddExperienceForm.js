$("document").ready(function(){
	$("#TranslatorAddExperienceForm").validate();
	
	$("#TranslatorExperience").counter({
	    type: 'word',
	    goal: 400,
	    count: 'down'           
	});
});