$(document).ready(function(){
	$("#AdminEditEmailForm").validate();
});