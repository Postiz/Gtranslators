$(document).ready(function(){
	$("#AdminEditForm").validate();
});