<?php
class Job extends AppModel {
	var $name = 'Job';
//	var $validate = array(
//		'input_txt' => array(
//			'notempty' => array(
//				'rule' => array('notempty'),
//				//'message' => 'Your custom message here',
//				//'allowEmpty' => false,
//				//'required' => false,
//				//'last' => false, // Stop validation after this rule
//				//'on' => 'create', // Limit validation to 'create' or 'update' operations
//			),
//		),
////		'output_txt' => array(
//////			'notempty' => array(
//////				'rule' => array('notempty'),
//////				//'message' => 'Your custom message here',
//////				//'allowEmpty' => false,
//////				//'required' => false,
//////				//'last' => false, // Stop validation after this rule
//////				//'on' => 'create', // Limit validation to 'create' or 'update' operations
//////			),
////		),
//		'src_language_id' => array(
//			'numeric' => array(
//				'rule' => array('numeric'),
//				//'message' => 'Your custom message here',
//				//'allowEmpty' => false,
//				//'required' => false,
//				//'last' => false, // Stop validation after this rule
//				//'on' => 'create', // Limit validation to 'create' or 'update' operations
//			),
//		),
//		'trgt_language_id' => array(
//			'numeric' => array(
//				'rule' => array('numeric'),
//				//'message' => 'Your custom message here',
//				//'allowEmpty' => false,
//				//'required' => false,
//				//'last' => false, // Stop validation after this rule
//				//'on' => 'create', // Limit validation to 'create' or 'update' operations
//			),
//		),
//		'category_id' => array(
//			'numeric' => array(
//				'rule' => array('numeric'),
//				//'message' => 'Your custom message here',
//				//'allowEmpty' => false,
//				//'required' => false,
//				//'last' => false, // Stop validation after this rule
//				//'on' => 'create', // Limit validation to 'create' or 'update' operations
//			),
//		),
//		'trans_type' => array(
//			'notempty' => array(
//				'rule' => array('notempty'),
//				//'message' => 'Your custom message here',
//				//'allowEmpty' => false,
//				//'required' => false,
//				//'last' => false, // Stop validation after this rule
//				//'on' => 'create', // Limit validation to 'create' or 'update' operations
//			),
//		),
//		'currency' => array(
//			'numeric' => array(
//				'rule' => array('numeric'),
//				//'message' => 'Your custom message here',
//				//'allowEmpty' => false,
//				//'required' => false,
//				//'last' => false, // Stop validation after this rule
//				//'on' => 'create', // Limit validation to 'create' or 'update' operations
//			),
//		),
////		'order_title' => array(
////			'notempty' => array(
////				'rule' => array('notempty'),
////				//'message' => 'Your custom message here',
////				//'allowEmpty' => false,
////				//'required' => false,
////				//'last' => false, // Stop validation after this rule
////				//'on' => 'create', // Limit validation to 'create' or 'update' operations
////			),
////		),
////		'translator_briefing' => array(
////			'notempty' => array(
////				'rule' => array('notempty'),
////				//'message' => 'Your custom message here',
////				//'allowEmpty' => false,
////				//'required' => false,
////				//'last' => false, // Stop validation after this rule
////				//'on' => 'create', // Limit validation to 'create' or 'update' operations
////			),
////		),
//		'user_id' => array(
//			'numeric' => array(
//				'rule' => array('numeric'),
//				//'message' => 'Your custom message here',
//				//'allowEmpty' => false,
//				//'required' => false,
//				//'last' => false, // Stop validation after this rule
//				//'on' => 'create', // Limit validation to 'create' or 'update' operations
//			),
//		),
//	);
	//The Associations below have been created with all possible keys, those that are not needed can be removed

	var $belongsTo = array(
		'SrcLanguage' => array(
			'className' => 'Language',
			'foreignKey' => 'src_language_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'TrgtLanguage' => array(
			'className' => 'Language',
			'foreignKey' => 'trgt_language_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Category' => array(
			'className' => 'Category',
			'foreignKey' => 'category_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'User' => array(
			'className' => 'User',
			'foreignKey' => 'user_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		)
	);
	
	var $hasMany = array(
		'Bid' => array(
			'className' => 'Bid',
			'foreignKey' => 'job_id',
			'dependent' => true,
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'exclusive' => '',
			'finderQuery' => '',
			'counterQuery' => ''
		),
		'Message' => array(
			'className' => 'Message',
			'foreignKey' => 'job_id',
			'dependent' => true,
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'exclusive' => '',
			'finderQuery' => '',
			'counterQuery' => ''
		)
	);
}
?>