<?php
class TranslatorSkill extends AppModel {
	var $name = 'TranslatorSkill';
	//The Associations below have been created with all possible keys, those that are not needed can be removed

	var $belongsTo = array(
		'Translator' => array(
			'className' => 'Translator',
			'foreignKey' => 'translator_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'SrcLanguage' => array(
			'className' => 'Language',
			'foreignKey' => 'src_language_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'TrgtLanguage' => array(
			'className' => 'Language',
			'foreignKey' => 'trgt_language_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		)
	);
}
?>