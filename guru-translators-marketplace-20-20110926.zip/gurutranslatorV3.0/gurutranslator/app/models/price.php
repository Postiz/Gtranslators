<?php
class Price extends AppModel {
	var $name = 'Price';
	//The Associations below have been created with all possible keys, those that are not needed can be removed

	var $belongsTo = array(		
		'SrcLanguage' => array(
			'className' => 'Language',
			'foreignKey' => 'src_language_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'TrgtLanguage' => array(
			'className' => 'Language',
			'foreignKey' => 'trgt_language_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		)
	);
}
?>