<?php
class Certificate extends AppModel {
	var $name = 'Certificate';
	//The Associations below have been created with all possible keys, those that are not needed can be removed

	var $belongsTo = array(
		'Translator' => array(
			'className' => 'Translator',
			'foreignKey' => 'translator_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		)
	);
}
?>