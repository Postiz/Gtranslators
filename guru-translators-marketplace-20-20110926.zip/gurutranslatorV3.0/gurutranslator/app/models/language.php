<?php
class Language extends AppModel {
	var $name = 'Language';
	var $validate = array(
		'name' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				//'message' => 'Your custom message here',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
	);
	var $hasMany = array(
        'SourceText' => array(
            'className' => 'Job',
            'foreignKey' => 'src_language_id'
        ),
        'TargetText' => array(
            'className' => 'Job',
            'foreignKey' => 'trgt_language_id'
        ),
        'SrcLanguage' => array(
            'className' => 'Price',
            'foreignKey' => 'src_language_id'
        ),
        'TrgtLanguage' => array(
            'className' => 'Price',
            'foreignKey' => 'trgt_language_id'
        ),
		'SrcLanguage' => array(
            'className' => 'TranslatorSkill',
            'foreignKey' => 'src_language_id'
        ),
        'TrgtLanguage' => array(
            'className' => 'TranslatorSkill',
            'foreignKey' => 'trgt_language_id'
        ),
		'FirstLanguage' => array(
            'className' => 'Translator',
            'foreignKey' => 'first_language_id'
        ),
        'SecondLanguage' => array(
            'className' => 'Translator',
            'foreignKey' => 'second_language_id'
        )
    );

}
?>