<?php
class Admin extends AppModel {
	var $name = 'Admin';
}
?>