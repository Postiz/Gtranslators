<?php
class AppController extends Controller {
    var $helpers = array('Javascript', 'Form', 'Session'); 
    var $components = array('Session');
        
	function genRandomString($length = null) {
	    if(!isset($length)){
			$length = 50;
	    }
	    $characters = '0123456789abcdefghijklmnopqrstuvwxyz';
	    $string = '';
	    for ($p = 0; $p < $length; $p++) {
	        @$string .= $characters[mt_rand(0, strlen($characters))];
	    }
	    return $string;
	}
	
	function sendEmail($to, $toName, $subject, $msg){
		App::import('Component', 'Emaill');
		$Email = new EmaillComponent();
		$this->loadModel('Setting');
		$this->Setting->id = 5;
		$Email->from = $this->Setting->field('value');
		$Email->to = $to;
		$Email->toName = $toName;
        $Email->subject = $subject;
        $Email->html_body = $msg;
        $result = $Email->send();
        return $result;
	}
	
	function uploadFile($destFolder, $fileElementName, $extensions){
		
		$error = "";
		$msg = "";
		//$fileElementName = 'fileToUpload';
		
		if(!empty($_FILES[$fileElementName]['error'])){
			switch($_FILES[$fileElementName]['error']){		
				case '1':
					$msg = 'The uploaded file exceeds the upload_max_filesize directive in php.ini';
					break;
				case '2':
					$msg = 'The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form';
					break;
				case '3':
					$msg = 'The uploaded file was only partially uploaded';
					break;
				case '4':
					$msg = 'No file was uploaded.';
					break;		
				case '6':
					$msg = 'Missing a temporary folder';
					break;
				case '7':
					$msg = 'Failed to write file to disk';
					break;
				case '8':
					$msg = 'File upload stopped by extension';
					break;
				case '999':
				default:
					$msg = 'No error code avaiable';
			}
		}elseif(empty($_FILES[$fileElementName]['tmp_name']) || $_FILES[$fileElementName]['tmp_name'] == 'none'){
			$msg = 'No file was uploaded..';
		}else{
			$destFile = $destFolder . "/" . $_FILES[$fileElementName]["name"];
			$path_parts = pathinfo($destFile);
			$validExts = explode(",", $extensions);
			$valid = false;
			for($i=0; $i<count($validExts); $i++){
				if(strtolower($path_parts['extension']) == $validExts[$i]){
					$valid = true;
					break;
				}
			}
			if($valid){
				
				if(file_exists($destFile)){						
					$fileNoExt = $path_parts['filename'];
					$i=0;
					while(true){
						$destFile = $destFolder . "/" . $fileNoExt . '-' . $i . '.' . $path_parts['extension'];
						if(!file_exists($destFile)){
							break;
						}
						$i++;
					}
				}
				
				move_uploaded_file($_FILES[$fileElementName]["tmp_name"], $destFile);
				$path_parts = pathinfo($destFile);
				$msg = "success";
			}else{
				$msg = "Invalid extension";
			}			
		}		
		
		$ret = "{error: '" . $error . "',\n" . "msg: '" . $msg . "'\n" . "}";
		return $ret;
	}	
	
//	function express1($callback = null)
//	{
//		App::import('Component', 'Paypal');
//		$payPal = new PaypalComponent();
//		
//		if (isset($callback) && isset($_REQUEST['csid']))
//	    {
//	        // Restore session
//	        
//	        if (!$payPal->restoreSession($_REQUEST['csid']))
//	        {
//	            $this->redirect('/');
//	            exit;
//	        }
//	    }
//	    
//	    // Neither buyer nor credit card information since it
//	    // is handled by PayPal
//	    
//	    $order = array(
//	        'action' => CAKE_COMPONENT_PAYPAL_ORDER_TYPE_SALE,
//	        'description' => 'CakePHP Component',
//	        'total' => $this->amount
//	    );
//	    
//	    // Set up common component's parameters
//	    
//	    $payPal->setEnvironment(CAKE_COMPONENT_PAYPAL_ENVIRONMENT_SANDBOX);
//	    $payPal->setUser('gseler_1281213401_biz_api1.gmail.com');
//	    $payPal->setPassword('1281213406');
//	    $payPal->setSignature('ACMmCP5YQ.18ewdMme3qvhQz6Yt3AQAuhHECcATVDJFBKJNWZJcH5Pg-');
//	    $payPal->setOrder($order);
//	    
//	    if (!isset($callback))
//	    {
//	        // First call, user gets redirected to PayPal
//	    	
//	    	//'http://localhost/tolingo/jobs/express/pay?csid='
//	    	//'http://localhost/tolingo/jobs/express/cancel?csid='
//	        $payPal->setTokenUrl($this->tokenURL . session_id());
//	        $payPal->setCancelUrl($this->cancelURL . session_id());
//	        
//	        // Save current session
//	        
//	        $payPal->storeSession();
//	    
//	        // Make payment via PayPal
//	        
//	        $result = $payPal->expressCheckout();
//	        
//	        if ($result === false)
//	        {
//	            echo 'ERROR: ' . $payPal->getError();
//	            exit;
//	        }
//	    }
//	    else if ($callback == 'cancel')
//	    {
//	        echo 'SNIFF... Why not?';
//	        exit;
//	    }
//	    else if ($callback == 'pay')
//	    {
//	        // Second call, make payment via PayPal
//	        
//	        $result = $payPal->expressCheckout();
//	        
//	        // Check PayPal status
//	        
//	        if ($result === false)
//	        {
//	            echo 'ERROR: ' . $payPal->getError();
//	            exit;
//	        }
//	        else
//	        {
//	            echo 'Woha! Got the money!';
//	            echo '<pre>'; print_r($result); echo '</pre>';
//	            exit;
//	        }
//	    }
//	}
		
	function beforeFilter() {
		$user = $this->Session->read('Auth.User');
		
		
		$this->Session->write('fullName', $user['first_name'] . ' ' . $user['last_name']);
		$this->Session->write('id', $user['id']);
		$userType = $this->Session->read('UserType');
		$credit = $this->Session->read('credit');
		if($userType == 1 && is_null($credit) && isset($user['credit'])){
			$this->Session->write('credit', $user['credit']);
		}
		if(!isset($user['credit'])){
			$this->Session->delete('credit');
		}
		
		$this->loadModel('Setting');
		$this->Setting->id = 4;
		$this->Session->write('supportmail', $this->Setting->field('value'));
	}
}
?>