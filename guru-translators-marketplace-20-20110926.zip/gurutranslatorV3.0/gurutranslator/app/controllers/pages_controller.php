<?php
class PagesController extends AppController {
	var $name = 'Pages';
	var $uses = array('User');
	
	var $helpers = array('Html', 'Form', 'Javascript');
	var $components = array('FileUpload', 'Session');
	function display($param = null) {
		//Switch between layouts.
		if($param == "printable_version"){
			$this->layout = 'printable'; 
		}else if(strpos(strtolower($param), 'professional') !== false){
			$this->layout = 'professional';
		}else{
			$this->layout = 'default'; 
		}
		
		$path = func_get_args();

		$count = count($path);
		if (!$count) {
			$this->redirect('/');
		}
		$page = $subpage = $title = null;

		if (!empty($path[0])) {
			$page = $path[0];
		}
		if (!empty($path[1])) {
			$subpage = $path[1];
		}
		if (!empty($path[$count - 1])) {
			$title = Inflector::humanize($path[$count - 1]);
		}
		$this->set(compact('page', 'subpage', 'title'));
		//mine
		if (method_exists($this, $page)) { 
    		$this->$page(); 
    		$this->render($page);
    		return;
  		} 
		
	
		$this->render(implode('/', $path));
	}
	
	function calculateCost()
	{
	/*
		ini_set('upload_max_filesize', '50M');
		ini_set('max_execution_time', 0);
		ini_set('post_max_size', '50M');
		ini_set('memory_limit', '50M');
		
		if (!empty($this->data)){
			if(isset($this->data['CostCalculator']['input_text'])){
				$wordsCount = str_word_count($this->data['CostCalculator']['input_text']);
				$cost =  $wordsCount * $this->requestAction('/Prices/getPairPrice/' . $this->data['CostCalculator']['src_lang'] . '/' . $this->data['CostCalculator']['trgt_lang']);
				$this->Session->write('cost', $cost);
				$this->redirect(array('action'=>'home'));
			}else if($this->FileUpload->success){
				//$contents = file_get_contents('files/tmp/' . $this->FileUpload->finalFile);
//				$stream = @fopen('files/tmp/' . $this->FileUpload->finalFile, "r");
//				$PDFContent = @fread ($stream, filesize('files/tmp/' . $this->FileUpload->finalFile));
//				ob_start();
//				print_r( $PDFContent );
//				$output = ob_get_clean();
//				
//				// if you want to append the print_r output of $some_array to, let's say, log.txt:
//				
//				file_put_contents( 'd:\\log.txt', file_get_contents( 'log.txt' ) . $output );
			}else{
				$this->Session->setFlash($this->FileUpload->showErrors());
			}
			$this->redirect(array('action'=>'home'));
		}
		
		*/
		if(!empty($this->data))
		{

			if(isset($this->data))
			{
				$second = $this->calculatefile();
				
				$filePath = APP.WEBROOT_DIR.DS.'contents'.DS.date("ymdhms")."_".$this->data['CostCalculator']['file']['name'];
				
				$fileSize = filesize($filePath);
				$size = $fileSize / 1024;
				
				$theFileSize = round($size* 0.02, 2) ;
				//echo "<br/>";
				$totalprice = $second * $this->requestAction('/Prices/getPairPrice/' . $this->data['CostCalculator']['src_lang'] . '/' . $this->data['CostCalculator']['trgt_lang']) * $theFileSize;
				//echo "<br/>";
				$totalprice = round($totalprice, 2);
				//echo "<br/>";
				//exit;
				$users = $this->Session->read('Auth.User.id');

				$csv = $this->User->read(null,$users);
				
				if($csv['User']['csv'] == 1)
				{
					$discount = ($totalprice * 20)/100;
					
					$totalprice = $totalprice - $discount;
				}

				$this->Session->write('slang',$this->data['CostCalculator']['src_lang']);
				$this->Session->write('tlang',$this->data['CostCalculator']['trgt_lang']);
				$this->Session->write('uploadfilename',date("ymdhms")."_".$this->data['CostCalculator']['file']['name']);
				$this->Session->write('refname',date("ymdhms")."_".$this->data['CostCalculator']['referece']['name']);
				$this->Session->write('categoryID',$this->data['CostCalculator']['category']);
				$this->Session->write('tprice',$totalprice);
			
				
				$place_data = array($this->data['CostCalculator']['src_lang'],$this->data['CostCalculator']['trgt_lang'],$this->data['CostCalculator']['file']['name'],$this->Session->read('place_order_id'),$this->data['CostCalculator']['referece']['name'],$totalprice);
				
				$this->Session->write('PlaceOrder',$place_data);
				$this->Session->write('cost', $totalprice);
				
				
				$data = $this->Session->read('PlaceOrder');
				$users = $this->Session->read('Auth.User.id');
				if(isset($users))
				{
					if(!empty($data))
					{
						$users = $this->Session->read('Auth.User.id');
						$slang = $this->Session->read('slang');
						$tlang = $this->Session->read('tlang');
						$filename = addslashes($this->Session->read('uploadfilename'));
						$refname = $this->Session->read('refname');
						$cat = $this->Session->read('categoryID');
						$tprice = $this->Session->read('tprice');
		
						$this->User->query("INSERT INTO jobs (input_txt,src_language_id,trgt_language_id,category_id,user_id,total_price,referance) VALUES ('$filename','$slang','$tlang','$cat','$users','$tprice','$refname')");
						
						$slang = $this->Session->delete('slang');
						$tlang = $this->Session->delete('tlang');
						$filename = $this->Session->delete('uploadfilename');
						$refname = $this->Session->delete('refname');
						$cat = $this->Session->delete('categoryID');
						$tprice = $this->Session->delete('tprice');
						$this->Session->delete('cost');
					}
				}

				$this->redirect(array('action'=>'home'));
			}			
		}
	}
	
	function professionalTranslation(){
		if(!isset($this->params['pass'][1])){
			$pageType = "englishgerman";
		}else{
			$pageType = $this->params['pass'][1];
		}
		$prices = null;
		switch(strtolower($pageType)){
			case "englishgerman":
				$prices = $this->requestAction('/Prices/getLanguagePrices/German');
				break;
			case "englishspanish":
			case "legaltranslation":				
			case "webpagetranslation":
			case "englishtranslation":
			case "technicaltranslation":
			case "documenttranslation":
			case "professionaltranslation":
				$prices = $this->requestAction('/Prices/getLanguagePrices/English');				
				break;
			
			case "englishportuguese":
				$prices = $this->requestAction('/Prices/getLanguagePrices/Portuguese');				
				break;
			
			case "englishitalian":
				$prices = $this->requestAction('/Prices/getLanguagePrices/Italian');				
				break;
			case "spanishtranslation":
				$prices = $this->requestAction('/Prices/getLanguagePrices/Spanish');				
				break;
			case "frenchtranslation":
				$prices = $this->requestAction('/Prices/getLanguagePrices/French');				
				break;			
			case "russianenglish":
				$prices = $this->requestAction('/Prices/getLanguagePrices/Russian');				
				break;
			default:
				$pageType = "englishgerman";
				$prices = $this->requestAction('/Prices/getLanguagePrices/German');
		}
		
		$this->set('prices', $prices);
		
		$this->set('pageType', strtolower($pageType));
	}
	
	function error() {
		$id = $this->params['pass'][1];
		if (!$id) {
			$this->Session->setFlash(__('Invalid Error.', true));
			$this->redirect(array('action'=>'home'));
		}
		switch ($id)
		{
		case 1:
		  $this->set('msg', 'javascript is not enabled in your browser, please enable it to be able to view the contents.');
		  break;
		case 2:
		  $this->set('msg', 'Error Msg 2');
		  break;
		case 3:
		  $this->set('msg', 'Error Msg 3');
		  break;
		default:
		  $this->set('msg', 'Undefined error occured.');
		}
		
	}
	
	function company_invite(){
		if(!empty($this->data)){

			$result = $this->sendEmail($this->data['toEmail'], $this->data['toName'], 'Try GeTranslator', $this->data['msg']);
			if($result){
				$this->set('msg', 'Email sent successfully');
			}else{
				$this->set('msg', 'Error in sending email');
			}
		} 
	}
	
	function control_panel() {
		$this->layout = 'admin';
		if (!$this->Session->read('Auth.Admin')) {			
			$this->redirect(array('controller' => 'Admins', 'action' => 'login'));
		}
		
		$this->loadModel('Translator');
		$this->Translator->recursive = -1;
		
		$translators = $this->Translator->find('count');
		$this->set('translators', $translators);
		
		$activeTranslators = $this->Translator->find('count', array('conditions' => array('active' => 1)));
		$this->set('activeTranslators', $activeTranslators);
		
		$bannedTranslators = $this->Translator->find('count', array('conditions' => array('banned' => 1)));
		$this->set('bannedTranslators', $bannedTranslators);
		
		$pendingTranslators = $this->Translator->find('count', array('conditions' => array('active' => 1, 'accepted' => 0)));
		$this->set('pendingTranslators', $pendingTranslators);
		
		$acceptedTranslators = $this->Translator->find('count', array('conditions' => array('accepted' => 1)));
		$this->set('acceptedTranslators', $acceptedTranslators);
		
		$this->loadModel('User');
		$this->User->recursive = -1;
		
		$users = $this->User->find('count');
		$this->set('users', $users);
		
		$this->loadModel('Job');
		$this->Job->recursive = -1;
		
		$jobs = $this->Job->find('count');
		$this->set('jobs', $jobs);
		
		$openJobs = $this->Job->find('count', array('conditions' => array('winner_bid_id' => null)));
		$this->set('openJobs', $openJobs);
		
		$this->loadModel('Bid');
		$this->Bid->recursive = -1;
		
		$bids = $this->Bid->find('count');
		$this->set('bids', $bids);
		
		$this->loadModel('PaymentRequest');
		$this->PaymentRequest->recursive = -1;
		
		$pendingPayments = $this->PaymentRequest->find('count', array('conditions' => array('paid' => 0)));
		$this->set('pendingPayments', $pendingPayments);
	}
	
	function setLang($lang, $url){
		$this->autoRender = False;
		switch ($lang){
			case 'en':
				$this->Session->delete('Config.language');
				break;
			case 'it':
				$this->Session->write('Config.language', 'ita');
				break;
		}
	}
	
	function beforeFilter() {
		parent::beforeFilter();
		$this->FileUpload->uploadDir = 'files/tmp';		
	}
	
	function calculatefile()
	{
		
		require_once "script/class.mp3file.php";
		
		$file_path = APP.WEBROOT_DIR.DS.'contents'.DS.date("ymdhms")."_".$this->data['CostCalculator']['file']['name'];
		
		$DateFile = date("ymdhms")."_".$this->data['CostCalculator']['file']['name'];
		$this->Session->write('dateFilename',$DateFile);
		
		$file_path1 = APP.WEBROOT_DIR.DS.'referance'.DS.date("ymdhms")."_".$this->data['CostCalculator']['referece']['name'];
		
		move_uploaded_file($this->data['CostCalculator']['referece']['tmp_name'],$file_path1);
		move_uploaded_file($this->data['CostCalculator']['file']['tmp_name'],$file_path);
		$mp3fileObj = new mp3file($file_path);
		$filetype = $mp3fileObj->file_extension($file_path);
		
		switch ($filetype) {
			case 'mp3':
				$result = $mp3fileObj->get_metadata();
				$price = $result['Length'];	
				
				break;
			case 'wav':
				$result = $mp3fileObj->getWavDuration($file_path);
				$price = $result;	
				break;
			default:
				$result = $mp3fileObj->getfilesize($file_path);
				$price = $result;	
		}

		$users = $this->Session->read('Auth.User.id');

		$csv = $this->User->read(null,$users);

		return $price;

	}
	
	function uploadcsv()
	{
		if(!empty($this->data))
		{
			
			if(isset($this->data))
			{
				require_once('script/class.phpmailer.php');
				$file_path = APP.WEBROOT_DIR.DS.'csv'.DS.date("ymdhms")."_".$this->data['CostCalculator']['file']['name'];
				$userID = $this->Session->read('Auth.User.id');
				
				
				$data = array(
				   'User' => array(
								'id'=>$userID,
								'csv'=>1
				   )
				);
				
				$this->User->query("UPDATE users SET csv = '1' WHERE id = '$userID'");
				
				move_uploaded_file($this->data['CostCalculator']['file']['tmp_name'],$file_path);
				$handle = fopen($file_path, "r");
				
				$dataArr = array();
				$cou = 0;
				while (($data = fgetcsv($handle,"" , ",")) !== FALSE)
				{	
					$cou ++;
					if($cou > 1)
					{
						$from = "info@toughwebs.com";
						$to = $data[0];
						$subject = "SUBJECT";
						$msg = "Hello, I have just found a brand new service on the Internet and I thought it might interest you. It is a self-service transcription platform where you can upload your dictation audio files and have them transcribed easily. One can even register as a transcriber to get transcription jobs and get paid for it. Hope you'll enjoy it!";
					
			
						$mail = new phpmailer;
						$mail->IsHTML(false);
						$mail->AddAddress($to);
						$mail->From = $from;
						$mail->CharSet = 'UTF-8';
						$mail->Subject = $subject;
						$mail->Body = $msg;
						$flag = $mail->send();			
					}
				}	
			}
			
			$messagecsv = "Congrats, you sucessfully uploaded csv file, now you will get 20% off on translation price.";
			$this->Session->write('messagecsv',$messagecsv);
			$this->redirect(array('action'=>'uploadcsv'));
		}
		
	}
	
}

?>