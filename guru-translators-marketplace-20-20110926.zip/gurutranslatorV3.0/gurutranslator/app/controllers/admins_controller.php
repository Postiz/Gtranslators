<?php
class AdminsController extends AppController {

	var $name = 'Admins';
	var $components = array('Auth', 'Session', 'AppAuth');

	function index() {
		$this->Admin->recursive = 0;
		$this->set('admins', $this->paginate());
	}

//	function view($id = null) {
//		if (!$id) {
//			$this->Session->setFlash(__('Invalid admin', true));
//			$this->redirect(array('action' => 'index'));
//		}
//		$this->set('admin', $this->Admin->read(null, $id));
//	}

	function add() {
		if (!empty($this->data)) {
			$this->Admin->create();
			$this->data['Admin']['password'] = $this->Auth->password($this->data['Admin']['password']);
			if ($this->Admin->save($this->data)) {
				$this->Session->setFlash(__('The admin account has been saved', true));
				$this->redirect(array('action' => 'add'));
			} else {
				$this->Session->setFlash(__('The admin account could not be saved. Please, try again.', true));
			}
		}
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid admin account', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			$this->data['Admin']['Password'] = $this->Auth->password($this->data['Admin']['password']);
			if ($this->Admin->save($this->data)) {
				$this->Session->setFlash(__('The admin account has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The admin account could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Admin->read(null, $id);
		}
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for admin account', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->Admin->delete($id)) {
			$this->Session->setFlash(__('Admin account deleted', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Admin account was not deleted', true));
		$this->redirect(array('action' => 'index'));
	}
	
	function login() {
		$this->layout = "printable";
		if(isset($logout)){
			$this->Session->delete('UserType');
			App::import('Component', 'AppAuth');
			$AppAuth = new AppAuthComponent();
			$AppAuth->logout();
		}
		if(!empty($this->data)){
			$this->Auth->login($this->data);
	 	}
	}
	function logout() {
		$this->redirect($this->Auth->logout());
	}
	
	function setCommission(){
		$this->loadModel('Setting');		
		if(empty($this->data)){
			$this->Setting->recursive = -1;
			$comm = $this->Setting->find('all', array('fields' => array('value'), 'conditions' => array('key' => 'commission')));
			$this->set('commission', $comm[0]['Setting']['value']);
		}else{			
			if($this->data['Admin']['commission'] < 0 || $this->data['Admin']['commission'] > 100){
				$this->Session->setFlash(__('Error in commission percentage value.', true));
			}else{
				$this->Setting->id = 1;
				if($this->Setting->saveField('value', $this->data['Admin']['commission'])){
					$this->Session->setFlash(__('Commission percentage updated successfully.', true));				
				}else{
					$this->Session->setFlash(__('Error. Please try again later.', true));
				}
			}
		}
	}
	
	function setTransAcceptance(){
		$this->loadModel('Setting');
		if(!empty($this->data)){
			$this->Setting->id = 2;
			if($this->Setting->saveField('value', $this->data['mode'])){
				$this->Session->setFlash(__('Acceptance mode updated successfully.', true));				
			}else{
				$this->Session->setFlash(__('Error. Please try again later.', true));
			}
		}
		
		$this->Setting->recursive = -1;
		$mode = $this->Setting->find('all', array('fields' => array('value'), 'conditions' => array('key' => 'auto_accept_translators')));
		$this->set('mode', $mode[0]['Setting']['value']);
	}
	
	function manageEmails(){
		$this->loadModel('Setting');
		$this->Setting->recursive = -1;
		
		$mails = $this->Setting->find('all', array('fields' => array('key', 'value'), 'conditions' => array('OR' => array('id' => array(3, 4, 5)))));
		$this->set('mails', $mails);
	}
	
	function editEmail($emailType = null){
		if (!$emailType && empty($this->data)){
			$this->Session->setflash(__('Please select email first.', true));
			$this->redirect(array('action' => 'manageEmails'));
		}
		
		$this->loadModel('Setting');
		$this->Setting->recursive = -1;
		if(empty($this->data)){
			$mails = $this->Setting->find('all', array('fields' => array('id', 'key', 'value'), 'conditions' => array('key' => $emailType)));
			if(count($mails) == 0){
				$this->Session->setflash(__('Email not found.', true));
				$this->redirect(array('action' => 'manageEmails'));
			}else{
				$this->set('emailType', $mails[0]['Setting']['key']);
				$this->set('id', $mails[0]['Setting']['id']);
			}
		}else{
			$this->Setting-> id = $this->data['Admin']['id'];
			if($this->Setting->saveField('value', $this->data['Admin']['email'])){
				$this->Session->setFlash(__('Email changed successfully', true));
				$this->redirect(array('action' => 'manageEmails'));
			}else{
				$this->Session->setFlash(__('Error. Please try again later.', true));
			}
		}
		
	}
		
	function beforeFilter() {
		parent::beforeFilter();
		$this->AppAuth->allow('*');
		$this->Auth->allow('*');
		$this->layout = 'admin';
		
		if($this->Session->read('Auth.Admin')){
			$this->Session->write('UserType', 2);
		}
		
		$this->Auth->userModel = 'Admin';
		$this->Auth->allow('add');
		$this->Auth->logoutRedirect = array('action' => 'login'); 
		$this->Auth->autoRedirect = true;
		$this->Auth->loginRedirect = array('controller' => 'Pages', 'action' => 'control_panel');
		$this->Auth->loginAction = array('action' => 'login');
	}
}
?>