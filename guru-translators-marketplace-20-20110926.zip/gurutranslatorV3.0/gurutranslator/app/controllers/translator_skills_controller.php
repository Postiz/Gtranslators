<?php
class TranslatorSkillsController extends AppController {

	var $name = 'TranslatorSkills';

	function index() {
		$this->TranslatorSkill->recursive = 0;
		$this->set('translatorSkills', $this->paginate());
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid translator skill', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('translatorSkill', $this->TranslatorSkill->read(null, $id));
	}

	function add() {
		if (!empty($this->data)) {
			$this->TranslatorSkill->create();
			if ($this->TranslatorSkill->save($this->data)) {
				$this->Session->setFlash(__('The translator skill has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The translator skill could not be saved. Please, try again.', true));
			}
		}
		$translators = $this->TranslatorSkill->Translator->find('list');
		$srcLanguages = $this->TranslatorSkill->SrcLanguage->find('list');
		$trgtLanguages = $this->TranslatorSkill->TrgtLanguage->find('list');
		$this->set(compact('translators', 'srcLanguages', 'trgtLanguages'));
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid translator skill', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->TranslatorSkill->save($this->data)) {
				$this->Session->setFlash(__('The translator skill has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The translator skill could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->TranslatorSkill->read(null, $id);
		}
		$translators = $this->TranslatorSkill->Translator->find('list');
		$srcLanguages = $this->TranslatorSkill->SrcLanguage->find('list');
		$trgtLanguages = $this->TranslatorSkill->TrgtLanguage->find('list');
		$this->set(compact('translators', 'srcLanguages', 'trgtLanguages'));
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for translator skill', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->TranslatorSkill->delete($id)) {
			$this->Session->setFlash(__('Translator skill deleted', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Translator skill was not deleted', true));
		$this->redirect(array('action' => 'index'));
	}
}
?>