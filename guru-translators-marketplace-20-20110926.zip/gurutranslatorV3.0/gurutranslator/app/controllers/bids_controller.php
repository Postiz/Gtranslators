<?php
class BidsController extends AppController {

	var $name = 'Bids';
	var $components = array('Session'); 

//	function index() {
//		$this->Bid->recursive = 0;
//		$this->set('bids', $this->paginate());
//	}

	function view($id = null) {
		if(!$this->Session->read('Auth.User')){
			$this->Session->setFlash(__('Please login first', true));
			$this->Session->write('Auth.redirect', $this->here);
			$this->redirect('/users/login');
		}
		if (!$id) {
			$this->Session->setFlash(__('Invalid bid', true));
			$this->redirect('/pages/home');
		}
		$bid = $this->Bid->read(null, $id);
		$userType = $this->Session->read('UserType');
		if($userType == 0){
			$this->loadModel('Job');
			$this->Job->id = $bid['Job']['id'];
			$userID = $this->Job->field('user_id');
			if($userID != $this->Session->read('Auth.User.id')){
				$this->Session->setFlash(__('Invalid bid', true));
				$this->redirect('/pages/home');
			}
		}elseif ($userType == 1){
			if($bid['Bid']['translator_id'] != $this->Session->read('Auth.User.id')){
				$this->Session->setFlash(__('Invalid bid', true));
				$this->redirect('/pages/home');
			}
		}
		$this->set('bid', $bid);
	}

	function add($jobID = null) {
		if(!$this->Session->read('Auth.User')){
			$this->Session->setFlash(__('Please login first', true));
			$this->Session->write('Auth.redirect', $this->here);
			$this->redirect('/users/login');
		}
		
		$userType = $this->Session->read('UserType');
		if($userType == 0){
			$this->redirect('/pages/home');
		}
		
		if (!empty($this->data)) {
			$this->Bid->create();
			$user = $this->Session->read('Auth.User');
			$this->data['Bid']['translator_id'] = $user['id'];
			
			if ($this->Bid->save($this->data)) {				
				$job = $this->Bid->Job->find('all', array('conditions' => array('Job.id' => $this->data['Bid']['job_id'])));
				
				$idx = strpos(strtolower($this->here), '/bids/add');
				$jobURL = 'http://' . $_SERVER['SERVER_NAME'] . substr($this->here, 0, $idx) . '/jobs/view/' . $this->data['Bid']['job_id'];
				$bidURL = 'http://' . $_SERVER['SERVER_NAME'] . substr($this->here, 0, $idx) . '/bids/view/' . $this->Bid->id;
				$msg = 'A new bid added on the <a href="' . $jobURL . '">' . $job[0]['Job']['order_title'] . '</a>.' .'Click <a href="' . $bidURL . '">here</a> to open it.';				
				$this->sendEmail($job[0]['User']['username'], $job[0]['User']['first_name'] . ' ' . $job[0]['User']['last_name'], 'New bid', $msg);
				
				$this->Session->setFlash(__('Your bid has been added successfully', true));
				//$this->redirect(array('controller' => 'Jobs', 'action' => 'view', $this->data['Bid']['job_id']));
				$idx = strpos(strtolower($this->here), '/bids/add');
				echo '<script type="text/javascript">window.location = "' . substr($this->here, 0, $idx+1) . 'jobs/view/' . $this->data['Bid']['job_id'] . '"</script>';
			} else {
				$this->Session->setFlash(__('The bid could not be saved. Please, try again.', true));
			}
		}
//		$jobs = $this->Bid->Job->find('list');
//		$translators = $this->Bid->Translator->find('list');
//		$this->set(compact('jobs', 'translators'));
		$this->set('jobID', $jobID);
		$user = $this->Session->read('Auth.User');
		$this->set('transID', $user['id']);
	}

	function edit($id = null) {
		if(!$this->Session->read('Auth.User')){
			$this->Session->setFlash(__('Please login first', true));
			$this->Session->write('Auth.redirect', $this->here);
			$this->redirect('/users/login');
		}
		
		$bid = $this->Bid->read(null, $id);
		$userType = $this->Session->read('UserType');
		if($userType == 0){
			$this->redirect('/pages/home');
		}elseif ($userType == 1){
			if($bid['Bid']['translator_id'] != $this->Session->read('Auth.User.id')){
				$this->Session->setFlash(__('Invalid bid', true));
				$this->redirect('/pages/home');
			}
		}
		
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid bid', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->Bid->save($this->data)) {
				$job = $this->Bid->Job->find('all', array('conditions' => array('Job.id' => $this->data['Bid']['job_id'])));
				$idx = strpos(strtolower($this->here), '/bids/edit');
				$jobURL = 'http://' . $_SERVER['SERVER_NAME'] . substr($this->here, 0, $idx) . '/jobs/view/' . $this->data['Bid']['job_id'];
				$bidURL = 'http://' . $_SERVER['SERVER_NAME'] . substr($this->here, 0, $idx) . '/bids/view/' . $this->Bid->id;
				$msg = 'An existing bid had been edited on the <a href="' . $jobURL . '">' . $job[0]['Job']['order_title'] . '</a>. Click <a href="' . $bidURL . '">here</a> to open it.';				
				$this->sendEmail($job[0]['User']['username'], $job[0]['User']['first_name'] . ' ' . $job[0]['User']['last_name'], 'Bid edited', $msg);
				
				$this->Session->setFlash(__('Your bid has been updated successfully', true));
				//$this->redirect(array('controller' => 'Jobs', 'action' => 'view', $this->data['Bid']['job_id']));
				$idx = strpos(strtolower($this->here), '/bids/edit');
				echo '<script type="text/javascript">window.location = "' . substr($this->here, 0, $idx+1) . 'jobs/view/' . $this->data['Bid']['job_id'] . '"</script>';
			} else {
				$this->Session->setFlash(__('The bid could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Bid->read(null, $id);
		}
		$jobs = $this->Bid->Job->find('list');
		$translators = $this->Bid->Translator->find('list');
		$this->set(compact('jobs', 'translators'));
	}

//	function delete($id = null) {
//		if (!$id) {
//			$this->Session->setFlash(__('Invalid id for bid', true));
//			$this->redirect(array('action'=>'index'));
//		}
//		if ($this->Bid->delete($id)) {
//			$this->Session->setFlash(__('Bid deleted', true));
//			$this->redirect(array('action'=>'index'));
//		}
//		$this->Session->setFlash(__('Bid was not deleted', true));
//		$this->redirect(array('action' => 'index'));
//	}
}
?>