<?php
class LanguagesController extends AppController {

	var $name = 'Languages';
	
	function index() {
		$this->Language->recursive = 0;
		$this->set('languages', $this->paginate());
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid language', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('language', $this->Language->read(null, $id));
	}

	function add() {
		if (!empty($this->data)) {
			$this->Language->create();
			if ($this->Language->save($this->data)) {
				$this->Session->setFlash(__('The language has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The language could not be saved. Please, try again.', true));
			}
		}
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid language', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->Language->save($this->data)) {
				$this->Session->setFlash(__('The language has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The language could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Language->read(null, $id);
		}
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for language', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->Language->delete($id)) {
			$this->Session->setFlash(__('Language deleted', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Language was not deleted', true));
		$this->redirect(array('action' => 'index'));
	}
	
	function listLanguages(){
		$this->autoRender = false;
		$this->Language->recursive = -1;
		$languages = $this->Language->find('all', array('fields' => array('Language.id', 'Language.name'),
														 'order' => array('Language.name' => 'asc')));
		return json_encode($languages);
	}
	
	function getLanguageID($langName=null){
		$this->autoRender = false;
		$this->Language->recursive = -1;
		if(isset($langName)){
			$languages = $this->Language->find('all', array('fields' => array('Language.id'),
															'conditions' => array('Language.name = ' => $langName)));
			return $languages[0]['Language']['id'];
		}else{
			return -1;
		}
	}
	
	function setLang($lang){
		$this->autoRender = False;
		switch ($lang){
			case 'en':
				$this->Session->delete('Config.language');
				break;
			case 'it':
				$this->Session->write('Config.language', 'ita');
				break;
		}
		$this->redirect($this->referer());
	}
}
?>