<?php
class FeedbacksController extends AppController {

	var $name = 'Feedbacks';
	
	var $components = array('Session');

	function index() {
		if (!$this->Session->read('Auth.Admin')){
			$this->Session->write('Auth.redirect', $this->here);
			$this->redirect(array('controller' => 'Pages', 'action' => 'control_panel'));
		}
		$this->paginate = array('order' => array('Feedback.new' => 'desc', 'Feedback.created' => 'desc'));
		$this->layout = "admin";
		$this->Feedback->recursive = 0;
		$this->set('feedbacks', $this->paginate());
	}

	function view($id = null) {
		if (!$this->Session->read('Auth.Admin')){
			$this->Session->write('Auth.redirect', $this->here);
			$this->redirect(array('controller' => 'Pages', 'action' => 'control_panel'));
		}
		
		
		$this->layout = "admin";
		if (!$id) {
			$this->Session->setFlash(__('Invalid feedback', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->Feedback->id = $id;
		$this->Feedback->saveField('new', 0);
		$this->set('feedback', $this->Feedback->read(null, $id));
	}

	function add() {
		if (!empty($this->data)) {
			$this->Feedback->create();
			if ($this->Feedback->save($this->data)) {
				$this->Session->setFlash(__('Your message had been sent to us', true));
				$this->redirect(array('action' => 'add'));
			} else {
				$this->Session->setFlash(__('Your message couldn\'t be sent. Please, try again.', true));
			}
		}
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid feedback', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->Feedback->save($this->data)) {
				$this->Session->setFlash(__('The feedback has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The feedback could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Feedback->read(null, $id);
		}
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for feedback', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->Feedback->delete($id)) {
			$this->Session->setFlash(__('Feedback deleted', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Feedback was not deleted', true));
		$this->redirect(array('action' => 'index'));
	}
}
?>