<?php
class MessagesController extends AppController {

	var $name = 'Messages';
	var $components = array('Auth', 'AppAuth', 'Session'); 

	function index($jobID = null, $transID = null) {
		if($this->Session->read('Auth.Admin')){
			$this->set('admin', 1);
			$this->paginate = array('conditions' => array('Message.job_id' => $jobID, 'Message.translator_id' => $transID),
									'order' => array('Message.created' => 'desc'));
			$this->set('messages', $this->paginate());
		}else{
			$this->set('admin', 0);
			$userType = $this->Session->read('UserType');
			if(!isset($userType)){
				$this->AppAuth->logout();
				$this->Session->setFlash(__('Please login first', true));
				$this->redirect(array('action' => 'index', $jobID, $transID));
			}
			
			$user = $this->AppAuth->user();
			$this->Message->recursive = 0;
			if($userType == 0){
				$this->paginate = array('conditions' => array('Message.job_id' => $jobID, 'Message.translator_id' => $transID),
									'order' => array('Message.created' => 'desc'));
			}else{
				$this->paginate = array('conditions' => array('Message.job_id' => $jobID, 'Message.translator_id' => $user['User']['id']),
									'order' => array('Message.created' => 'desc'));
			}		
			$this->set('messages', $this->paginate());
			
			$this->set('jobID', $jobID);
			$this->Message->Job->id = $jobID;
			$winner_bid = $this->Message->Job->field('winner_bid_id');
			$hideNew = false;
			if($userType == 0){
				$this->set('transID', $transID);
				if($winner_bid != null){
					$this->loadModel('Bid');
					$this->Bid->id = $winner_bid;
					$winnerTranslatorID = $this->Bid->field('translator_id');
					if($winnerTranslatorID != $transID){
						$hideNew = true;
					}
				}			
			}else{
				$this->set('transID', $user['User']['id']);
				if($winner_bid != null){
					$this->loadModel('Bid');
					$this->Bid->id = $winner_bid;
					$winnerTranslatorID = $this->Bid->field('translator_id');
					if($winnerTranslatorID != $user['User']['id']){
						$hideNew = true;
					}
				}
			}
			$this->set('hideNew', $hideNew);
		}
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid message', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('message', $this->Message->read(null, $id));
	}

	function add($jobID = null, $transID = null) {
		$userType = $this->Session->read('UserType');
		if(!isset($userType)){
			$this->AppAuth->logout();
			$this->Session->setFlash(__('Please login first', true));
			$this->redirect(array('action' => 'add', $jobID, $transID));
		}
		
		if (!empty($this->data)) {
			$this->Message->create();
			if ($this->Message->save($this->data)) {
				$this->loadModel('Job');
				$this->Job->id = $this->data['Message']['job_id'];
				$idx = strpos(strtolower($this->here), '/messages/add');
				$jobURL = 'http://' . $_SERVER['SERVER_NAME'] . substr($this->here, 0, $idx) . '/jobs/view/' . $this->Job->field('id');
				
				$msg = 'A new message sent regarding job <a href="' . $jobURL . '">' . $this->Job->field('order_title') . '</a>';
				$msg .= '<br/><br/>';
				$msg .= $this->data['Message']['subject'];
				$msg .= '<br/>';
				$msg .= $this->data['Message']['body'];
				$msg .= '<br/><br/>';
				$msgURL = 'http://' . $_SERVER['SERVER_NAME'] . $this->here . '/' . $this->data['Message']['job_id'] . '/' . $this->data['Message']['translator_id'];
				$msg .= 'To reply on this message please click <a href="' . $msgURL . '">here</a>';
								
				if($this->data['Message']['user_id'] != null){ //send to translator					
					$this->Message->Translator->id = $this->data['Message']['translator_id'];
					$this->sendEmail($this->Message->Translator->field('Translator.username'), $this->Message->Translator->field('Translator.first_name') . ' ' . $this->Message->Translator->field('Translator.last_name'), 'A new message sent regarding job ' . $this->Job->field('order_title'), $msg);
				}else{ //send to user
					$this->loadModel('User');
					$this->User->id = $this->Job->field('user_id');
					$this->sendEmail($this->User->field('User.username'), $this->User->field('User.first_name') . ' ' . $this->User->field('User.last_name'), 'A new message sent regarding job ' . $this->Job->field('order_title'), $msg);
				}
				$this->Session->setFlash(__('The message has been sent', true));
				//$this->redirect(array('controller' => 'Jobs', 'action' => 'view', $this->data['Message']['job_id']));
				$idx = strpos(strtolower($this->here), '/messages/add');
				echo '<script type="text/javascript">window.location = "' . substr($this->here, 0, $idx+1) . 'jobs/view/' . $this->data['Message']['job_id'] . '"</script>';
			} else {
				$this->Session->setFlash(__('The message could not be saved. Please, try again.', true));
			}
		}
		
		$this->set('jobID', $jobID);
		$user = $this->AppAuth->user();
		if($userType == 0){
			$this->set('transID', $transID);
			$this->set('userID', $user['User']['id']);
		}else{			
			$this->set('transID', $user['User']['id']);
			$this->set('userID', null);
		}
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid message', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->Message->save($this->data)) {
				$this->Session->setFlash(__('The message has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The message could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Message->read(null, $id);
		}
		$translators = $this->Message->Translator->find('list');
		$users = $this->Message->User->find('list');
		$this->set(compact('translators', 'users'));
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for message', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->Message->delete($id)) {
			$this->Session->setFlash(__('Message deleted', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Message was not deleted', true));
		$this->redirect(array('action' => 'index'));
	}
	
	function beforeFilter() {
		parent::beforeFilter();
		$this->AppAuth->allow('index');
		$this->Auth->allow('index');
	}
}
?>