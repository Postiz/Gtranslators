<?php

class JobsController extends AppController {

	var $name = 'Jobs';
	var $components = array('AppAuth', 'Session'); 
	var $amount = 0;
    var $tokenURL = '';
	var $uses = array('Job','User','Setting');
    var $cancelURL = '';

	function index() {
		$this->Job->recursive = 0;
		if($this->Session->read('Auth.Admin')){
			$this->set('admin', 1);
		}else{
			$this->set('admin', 0);
			$userType = $this->Session->read('UserType');
			if(!isset($userType)){
				$this->AppAuth->logout();
				$this->Session->setFlash(__('Please login first', true));
				$this->redirect(array('action' => 'index'));
			}elseif ($userType == 0){
				$user = $this->AppAuth->user();
				$this->paginate = array('conditions' => array('Job.paid' => 1, 'Job.user_id' => $user['User']['id']),
									'order' => array('Job.modified' => 'desc'));
			}elseif ($userType == 1){
				$this->paginate = array('conditions' => array('Job.paid' => 1),
									'order' => array('Job.modified' => 'desc'));
			}
		}
		$this->set('jobs', $this->paginate());
		
	}

	function view($id = null) {
		if($this->Session->read('Auth.Admin')){
			$this->set('admin', 1);
		}else{
			$this->set('admin', 0);
			$userType = $this->Session->read('UserType');
			if(!isset($userType)){
				$this->AppAuth->logout();
				$this->Session->setFlash(__('Please login first', true));
				$this->redirect(array('action' => 'view', $id));
			}
			
			if (!$id) {
				$this->Session->setFlash(__('Invalid job', true));
				$this->redirect('/pages/home');
			}
			
			$user = $this->AppAuth->user();
			if($userType == 0){
				$userJobsCount = $this->Job->find('count', array('conditions' => array('Job.id' => $id, 'Job.user_id' => $user['User']['id'])));
				if($userJobsCount == 0){
					$this->Session->setFlash(__('Invalid job', true));
					$this->redirect('/pages/home');
				}
			}elseif ($userType == 1){
				$this->Job->id = $id;
				$winner_bid = $this->Job->field('winner_bid_id');
				if($winner_bid != null){
					$hide = 0;
					$this->loadModel('Bid');
					$this->Bid->id = $winner_bid;
					$winnerTranslatorID = $this->Bid->field('translator_id');
				}
				
				$transBid = $this->Job->Bid->find('all', array('conditions' => array('Bid.job_id' => $id, 'Bid.translator_id' => $user['User']['id'])));
				if(count($transBid) > 0){
					if($winnerTranslatorID != null){
						if($winnerTranslatorID != $user['User']['id']){
							$hide = 1;
						}else{
							$hide = 2;
						}
					}
					
					$this->set('bidded', true);
					$this->set('bidID', $transBid[0]['Bid']['id']);
					$this->set('transID', $user['User']['id']);
				}else{
					if($winnerTranslatorID != null){
						$hide = 1;
					}else{
						$this->set('bidded', false);
						$this->set('jobID', $id);
					}
				}
				$this->set('hide', $hide);
			}
			$this->set('userType', $userType);
		}		
		
		$this->set('job', $this->Job->read(null, $id));
		$bids = $this->Job->Bid->find('all', array('conditions' => array('Bid.job_id' => $id),
													'order' => array('Bid.created' => 'asc')));
		$this->set('bids', $bids);
		$this->set('commission',$this->Setting->find('all',array('conditions'=>array('Setting.key'=>'commission'))));
	}
	
	function direct(){
		App::import('Component', 'Paypal');
		$payPal = new PaypalComponent();
		
		$order = array(
	    'action' => CAKE_COMPONENT_PAYPAL_ORDER_TYPE_SALE,
	    'description' => 'CakePHP Component',
	    'total' => 100.00,
	    'buyer' => array (
	        'first' => 'Test',
		    'last' => 'User',
	        'address1' => 'add',
	        'address2' => '',
	        'city' => 'Delray Beach',
	        'state' => 'FL',
	        'zip' => 33445,
	        'country' => 'US'
		    ),
		    'cc' => array (
		        'type' => 'Visa', // Can be: Visa, MasterCard, Amex, Discover
		        'number' => '4498374358357044',
		        'expiration' => '01/2015',
		        'cvv2' => '123',
		        'owner' => array (
		            'first' => 'Test',
		            'last' => 'User'
		        )
		    )
		);
	
		$payPal->setEnvironment(CAKE_COMPONENT_PAYPAL_ENVIRONMENT_SANDBOX);
		$payPal->setUser('gseler_1281213401_biz_api1.gmail.com');
	    $payPal->setPassword('1281213406');
	    $payPal->setSignature('ACMmCP5YQ.18ewdMme3qvhQz6Yt3AQAuhHECcATVDJFBKJNWZJcH5Pg-');
		$payPal->setOrder($order);
		
		// Make payment via PayPal
		
		$result = $payPal->directPayment();
		
		// Check PayPal status
		
		if ($result === false)
		{
		    switch($payPal->getErrorCode())
		    {
		        case CAKE_COMPONENT_PAYPAL_ERROR_INVALID_CREDIT_CARD:
		            echo 'INVALID CREDIT CARD';
		            exit;
		            break;
		        case CAKE_COMPONENT_PAYPAL_ERROR_INVALID_CVV2:
		            echo 'INVALID Credit Card Verification Number.';
		            exit;
		            break;
		        default:
		            echo 'ERROR: ' . $payPal->getError();
		            exit;
		            break;
		    }
		}
		else
		{
		    echo 'Woha! Got the money!';
		    echo '<pre>'; print_r($result); echo '</pre>';
		    exit;
		}
	}
	
	
	function viewJob($id = null) {
		$userType = $this->Session->read('UserType');
		if(!isset($userType) || $userType != 0){
			$this->AppAuth->logout();
			$this->Session->setFlash(__('Please login first', true));
			$this->redirect(array('action' => 'view', $id));
		}
		
		if (!$id) {
			$this->Session->setFlash(__('Invalid job', true));
			$this->redirect(array('action' => 'index'));
		}
		
		$user = $this->AppAuth->user();
		if($userType == 0){
			$userJobsCount = $this->Job->find('count', array('conditions' => array('Job.id' => $id, 'Job.user_id' => $user['User']['id'])));
			if($userJobsCount == 0){
				$this->Session->setFlash(__('Invalid job', true));
				$this->redirect(array('action' => 'index'));
			}
		}
		$this->set('job', $this->Job->read(null, $id));
		$key = $this->genRandomString(10);
		$this->set('key', $key);
		$this->Job->id = $id;
		$this->Job->saveField('key', $key);
		
	}

//	function add() {
//		if(!$this->Session->read('Auth.User')){
//			$this->Session->setFlash(__('Please login first', true));
//			$this->Session->write('Auth.redirect', $this->here);
//			$this->redirect('/users/login');
//		}
//		
//		$userType = $this->Session->read('UserType');
//		if($userType != 0){
//			$this->Session->setFlash(__('Action not allowed', true));
//			$this->redirect('/pages/home');
//		}
//		
//		if (!empty($this->data)) {
//			$this->Job->create();
//			if ($this->Job->save($this->data)) {
//				$this->Session->setFlash(__('The job has been saved', true));
//				$this->redirect(array('action' => 'index'));
//			} else {
//				$this->Session->setFlash(__('The job could not be saved. Please, try again.', true));
//			}
//		}
//		$srcLanguages = $this->Job->SrcLanguage->find('list');
//		$trgtLanguages = $this->Job->TrgtLanguage->find('list');
//		$categories = $this->Job->Category->find('list');
//		$users = $this->Job->User->find('list');
//		$this->set(compact('srcLanguages', 'trgtLanguages', 'categories', 'users'));
//	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid order', true));
			$this->redirect(array('action' => 'index'));
		}
		
		if(!$this->Session->read('Auth.User')){
			$this->Session->setFlash(__('Please login first', true));
			$this->Session->write('Auth.redirect', $this->here);
			$this->redirect('/users/login');
		}
		
		$userType = $this->Session->read('UserType');
		if($userType != 0){
			$this->Session->setFlash(__('Action not allowed', true));
			$this->redirect('/pages/home');
		}elseif($userType == 0){
			$this->Job->id = $id;
			if($this->Job->field('user_id') != $this->Session->read('Auth.User.id')){
				$this->Session->setFlash(__('Action not allowed', true));
				$this->redirect('/pages/home');
			}
		}
		
		if (!empty($this->data)) {
			if ($this->Job->save($this->data)) {
				$this->Session->setFlash(__('The order has been updated', true));
				$this->redirect(array('action' => 'viewJob', $this->data['Job']['id']));
			} else {
				$this->Session->setFlash(__('The order could not be updated. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->set('job', $this->Job->find('all', array('conditions' => array('Job.id' => $id))));
			$this->data = $this->Job->read(null, $id);
		}		
	}
	
	function award($jobID, $bidID){
		$this->autoRender = false;
		$this->Job->id = $jobID;
		if(!is_null($this->Job->field('winner_bid_id'))){
			$this->Session->setFlash(__('Job already awarded.', true));
			$this->redirect(array('controller' => 'pages', 'action' => 'home'));
		}else{
			if($this->Job->saveField('winner_bid_id', $bidID)){
				$this->Session->setFlash(__('Bid had been awarded to job', true));
				$this->loadModel('Bid');
				$this->Bid->id = $bidID;
				$transID = $this->Bid->field('translator_id');
				$this->loadModel('Translator');
				$this->Translator->id = $transID;
				$credit = $this->Translator->field('credit');
				$this->loadModel('Setting');
				$this->Setting->recursive = -1;
				$comm = $this->Setting->find('all', array('fields' => array('value'), 'conditions' => array('key' => 'commission')));
				$jobPrice = $this->Job->field('total_price');
				$credit += ($jobPrice - ($jobPrice * $comm[0]['Setting']['value'] / 100));
				$this->Translator->saveField('credit', $credit);
				
				$idx = strpos(strtolower($this->here), '/jobs/award');
				$jobURL = 'http://' . $_SERVER['SERVER_NAME'] . substr($this->here, 0, $idx) . '/jobs/view/' . $this->Job->field('id');
				$bidURL = 'http://' . $_SERVER['SERVER_NAME'] . substr($this->here, 0, $idx) . '/bids/view/' . $this->Bid->field('id');
				$msg = 'Your <a href = "' . $bidURL . '">bid</a> on <a href = "' . $jobURL . '">' . $this->Job->field('order_title') . '</a> had been won. Please note that a commission fees equal ' . $comm[0]['Setting']['value'] . '% had been taken';
				$this->sendEmail($this->Translator->field('username'), $this->Translator->field('first_name') . ' ' . $this->Translator->field('last_name'), 'Your bid won', $msg);
				
				$bids = $this->Bid->find('all', array('conditions' => array('Bid.job_id' => $jobID)));
				foreach ($bids as $bid){
					if($bid['Bid']['translator_id'] != $transID){
						$bidURL = 'http://' . $_SERVER['SERVER_NAME'] . substr($this->here, 0, $idx) . '/bids/view/' . $bid['Bid']['id'];
						$msg = 'Your <a href = "' . $bidURL . '">bid</a> on <a href = "' . $jobURL . '">' . $this->Job->field('order_title') . '</a> did not win';
						$this->sendEmail($bid['Translator']['username'], $bid['Translator']['first_name'] . ' ' . $bid['Translator']['last_name'], "Your bid didn't win", $msg);
					}
				}
			}else{
				$this->Session->setFlash(__('Error in awarding', true));
			}
			$idx = strpos(strtolower($this->here), '/award');
			echo '<script type="text/javascript">window.location = "' . substr($this->here, 0, $idx+1) . 'view/' . $jobID . '"</script>';
		}
		//$this->redirect(array('action' => 'view', $jobID));
	}

	function delete($id = null) {
		if($this->Session->read('Auth.Admin')){
			if (!$id) {
				$this->Session->setFlash(__('Invalid id for job', true));
				$this->redirect(array('action'=>'index'));
			}			
			if ($this->Job->delete($id, true)) {
				$this->Session->setFlash(__('Job deleted', true));
				$this->redirect(array('action'=>'index'));
			}
			$this->Session->setFlash(__('Job was not deleted', true));
			$this->redirect(array('action'=>'index'));
		}else{
			$userType = $this->Session->read('UserType');
			if(!isset($userType) || $userType != 0){
				$this->AppAuth->logout();
				$this->Session->setFlash(__('Please login first', true));
				$this->redirect(array('action' => 'enterText'));
			}
			
			if (!$id) {
				$this->Session->setFlash(__('Invalid id for job', true));
				$this->redirect(array('action'=>'index'));
			}
			if ($this->Job->delete($id, true)) {
				$this->Session->setFlash(__('Job deleted', true));
				$this->redirect(array('action' => 'customerAllJobs', $this->Session->read('Auth.User.id'), 0));
			}
			$this->Session->setFlash(__('Job was not deleted', true));
			$this->redirect(array('action' => 'customerAllJobs', $this->Session->read('Auth.User.id'), 0));
		}		
	}
	
	function enterText(){		
		$userType = $this->Session->read('UserType');
		if(!isset($userType) || $userType != 0){
			$this->AppAuth->logout();
			$this->Session->setFlash(__('Please login first', true));
			$this->redirect(array('action' => 'enterText'));
		}
		
		$this->Job->Category->recursive = -1;
		$categories = $this->Job->Category->find('list', array('fields' => array('Category.id', 'Category.name'),
																    	   'order' => array('Category.Name' => 'asc')));
		$tmp = array(null => '-- Choose Category --');
		$categories = $tmp + $categories;
		$this->set('cats', $categories);
		
		$this->Job->SrcLanguage->recursive = -1;
		$srcLanguages = $this->Job->SrcLanguage->find('list', array('fields' => array('SrcLanguage.id', 'SrcLanguage.name'),
																    	   'order' => array('SrcLanguage.Name' => 'asc')));
		$tmp = array(null => '-- Choose Source Language --');
		$srcLanguages = $tmp + $srcLanguages;
		$this->set(compact('srcLanguages', 'categories'));		
		
		if (!empty($this->data)) {

			//$this->data['Job']['word_count'] = str_word_count($this->data['Job']['input_txt']);
			//$this->data['Job']['total_price'] = $this->data['Job']['word_count'] * $this->requestAction('/Prices/getPairPrice/' . $this->data['Job']['src_language_id'] . '/' . $this->data['Job']['trgt_language_id']);
			$this->data['Job']['user_id'] = $this->Session->read('Auth.User.id');
			
			$price = $this->calculatefile();
			
			$filePath = APP.WEBROOT_DIR.DS.'contents'.DS.$this->data['Job']['inputname'];
				
			$fileSize = filesize($filePath);
			
			$size = $fileSize / 1024;
			
			$theFileSize = round($size* 0.02, 2) ;
			
			$totalprice = $price * $this->requestAction('/Prices/getPairPrice/' . $this->data['Job']['src_language_id'] . '/' . $this->data['Job']['trgt_language_id']) * $theFileSize;
			
			
			$users = $this->Session->read('Auth.User.id');

			$csv = $this->User->read(null,$users);
			
			if($csv['User']['csv'] == 1)
			{
				$discount = ($totalprice * 20)/100;
				$totalprice = $totalprice - $discount;
			}
			
			
			$file_path1 = APP.WEBROOT_DIR.DS.'referance'.DS.$this->data['Job']['referance']['name'];
			move_uploaded_file($this->data['Job']['referance']['tmp_name'],$file_path1);
			
			$this->data['Job']['input_txt'] = $this->data['Job']['inputname'];
			$this->data['Job']['referance'] = $this->data['Job']['referance']['name'];
			
			
			$this->data['Job']['word_count'] = $price;
			$this->data['Job']['total_price'] = $totalprice;
			$this->Session->write('cost', $totalprice);

			$this->Job->create();
			if ($this->Job->save($this->data))
			{
				$this->redirect(array('action' => 'jobSettings', $this->Job->id, 1));
			}
			else
			{
				$this->Session->setFlash(__('Error. Please try again.', true));
			}
		}	
	}
	
	function quote($id, $type){
		if($type == 0){
			$jobs = $this->Job->find('all', array('conditions' => array('Job.id' => $id)));
			$this->set('quan', 1);
		}elseif ($type == 1){
			$jobs = $this->Job->find('all', array('conditions' => array('Job.key' => $id)));
			$totalCost = 0;
			foreach ($jobs as $job){
				$totalCost += $job['Job']['total_price'];
			}
			$this->set('totalCost', $totalCost);
			$this->set('quan', count($jobs));
		}else{
			$this->Session->setFlash(__('Invalid Order', true));
			$this->redirect(array('controller' => 'Pages', 'action' => 'home'));
		}
		$this->set('job', $jobs[0]);
		$this->Job->User->Country->id = $jobs[0]['User']['country_id'];
		$this->set('country', $this->Job->User->Country->field('country_name'));
		
		$this->sendEmail($jobs[0]['User']['username'], $jobs[0]['User']['first_name'] . ' ' . $jobs[0]['User']['last_name'], 'Quote requested', 'The quote details goes here');
	}
	
	function viewPdf($id = null)
    {
        if (!$id)
        {
            $this->Session->setFlash(__('Sorry, there was no property ID submitted.', true));
            $this->redirect(array('action'=>'index'), null, true);
        }
        Configure::write('debug',0); // Otherwise we cannot use this method while developing

        $id = intval($id);

        $property = $this->__view($id); // here the data is pulled from the database and set for the view

        if (empty($property))
        {
            $this->Session->setFlash(__('Sorry, there is no property with the submitted ID.', true));
            $this->redirect(array('action'=>'index'), null, true);
        }

        $this->layout = 'pdf'; //this will use the pdf.ctp layout
        $this->render();
    } 
	
	function customerJobs($custID){
		if (!$this->Session->read('Auth.User')) {
			$this->redirect(array('controller' => 'Users', 'action' => 'login'));
		}elseif($this->Session->read('Auth.User.id') != $custID){
			$this->redirect(array('controller' => 'Users', 'action' => 'login'));
		}else{
			$userType = $this->Session->read('UserType');
			if(is_null($userType) || $userType != 0){
				$this->requestAction(array('controller' => 'Users', 'action' => 'logout'));
				$this->redirect(array('controller' => 'Users', 'action' => 'login'));
			}
		}		
		$custJobs = $this->Job->find('all', array('conditions' => array('Job.user_id' => $custID, 'Job.paid' => 0)));
		$this->set('custJobs', $custJobs);
		$this->set('key', $this->genRandomString(10));
	}
	
	function customerAllJobs($custID, $paid){
		if (!$this->Session->read('Auth.User')) {
			$this->redirect(array('controller' => 'Users', 'action' => 'login'));
		}elseif($this->Session->read('Auth.User.id') != $custID){
			$this->redirect(array('controller' => 'Users', 'action' => 'login'));
		}else{
			$userType = $this->Session->read('UserType');
			if(is_null($userType) || $userType != 0){
				$this->requestAction(array('controller' => 'Users', 'action' => 'logout'));
				$this->redirect(array('controller' => 'Users', 'action' => 'login'));
			}
		}
		
		if(is_null($paid)){
			$paid = 0;
		}
		
		if($paid){
			$custJobs = $this->Job->find('all', array('conditions' => array('Job.user_id' => $custID, 'Job.paid' => 1)));
		}else{
			$custJobs = $this->Job->find('all', array('conditions' => array('Job.user_id' => $custID, 'Job.paid' => 0)));	
		}
		
		$this->set('custJobs', $custJobs);
		$this->set('paid', $paid);
		$this->set('custID', $custID);
	}
	
	function setJobKey($jobID, $key){
		$this->autoRender = false;
		$this->Job->id = $jobID;
		if($key == 'null'){
			$this->Job->saveField('key', null);
		}else{
			$this->Job->saveField('key', $key);
		}
	}
	
	function jobPayment($key = null, $view){
		if(isset($key)){
			$this->Job->recursive = -1;
			$jobs = $this->Job->find('all', array('conditions' => array('key' => $key)));
			if(count($jobs) == 0){
				if(isset($view)){
					$this->Session->setFlash(__('Order not found', true));
					$this->redirect(array('action' => 'customerAllJobs', $this->Session->read('Auth.User.id'), 0));
				}else{
					$this->Session->setFlash(__('Please select at leaset one order', true));
					$this->redirect(array('action' => 'customerJobs', $this->Session->read('Auth.User.id')));	
				}
				
			}
			
			$billValue = "";
			foreach($jobs as $job){
				$billValue += $job['Job']['total_price'];
			}
			$this->set('billVal', $billValue);
			$this->data['Job']['key'] = $key;
		}else{
			$this->redirect(array('action' => 'pay', $this->data['Job']['key']));
		}
	}
	
	function express($callback = null)
	{
		$vendorPath = Configure::corePaths('component');

include $vendorPath['components'][0] . 'Paypal.php';
		//App::import('Component', 'Paypal');
		
		$payPal = new PaypalComponent();
		
		if (isset($callback) && isset($_REQUEST['csid']))
	    {
	        // Restore session
	        
	        if (!$payPal->restoreSession($_REQUEST['csid']))
	        {
	            $this->redirect('/');
	            exit;
	        }
	    }
	    
	    // Neither buyer nor credit card information since it
	    // is handled by PayPal
	    
	    $order = array(
	        'action' => CAKE_COMPONENT_PAYPAL_ORDER_TYPE_SALE,
	        'description' => 'CakePHP Component',
	        'total' => $this->Session->read('amount')
	    );
	    
	    // Set up common component's parameters
	    
	    $payPal->setEnvironment(CAKE_COMPONENT_PAYPAL_ENVIRONMENT_SANDBOX);
	    $payPal->setUser('getran_1283719769_biz_api1.gmail.com');
	    $payPal->setPassword('1283719779');
	    $payPal->setSignature('Agx-7U6s1nLB9W4TsgHk0-v1IbsdAJsItN-.BqK.XqpZ3-AG6W8mQil6');
	    $payPal->setOrder($order);
	    
	    if (!isset($callback))
	    {
	        // First call, user gets redirected to PayPal
	    	
	    	//'http://localhost/tolingo/jobs/express/pay?csid='
	    	//'http://localhost/tolingo/jobs/express/cancel?csid='
	        $payPal->setTokenUrl($this->tokenURL . session_id());
	        $payPal->setCancelUrl($this->cancelURL . session_id());
	        
	        // Save current session
	        
	        $payPal->storeSession();
	    
	        // Make payment via PayPal
	        
	        $result = $payPal->expressCheckout();
	        
	        if ($result === false)
	        {
	            echo 'ERROR: ' . $payPal->getError();
	            exit;
	        }
	    }
	    else if ($callback == 'cancel')
	    {
	        //echo 'SNIFF... Why not?';
	        $this->Session->delete('amount');
	        $idx = strpos(strtolower($this->here), 'express');
        	$URL = 'http://' . $_SERVER['SERVER_NAME'] . substr($_SERVER['REQUEST_URI'], 0, $idx) . 'payCancelled';
        	echo '<script type="text/javascript">window.location = "' . $URL . '"</script>';
	    	exit;
	    }
	    else if ($callback == 'pay')
	    {
	        // Second call, make payment via PayPal
	        
	        $result = $payPal->expressCheckout();
	        
	        $this->Session->delete('amount');
	        
	        // Check PayPal status
	        
	        if ($result === false)
	        {
	            echo 'ERROR: ' . $payPal->getError();
	            exit;
	        }
	        else
	        {
	        	$idx = strpos(strtolower($this->here), 'express');
	        	$URL = 'http://' . $_SERVER['SERVER_NAME'] . substr($_SERVER['REQUEST_URI'], 0, $idx) . 'paySucceeded';
	        	echo '<script type="text/javascript">window.location = "' . $URL . '"</script>';
	        	//$this->redirect(array('action' => 'paidSucceeded'));
	        	//$this->requestAction($url, $extra)
//	            echo 'Woha! Got the money!';
//	            echo '<pre>'; print_r($result); echo '</pre>';
	            exit;
	        }
	    }
	}
	
	function paySucceeded(){
		$paidJobs = $this->Session->read('paidJobs');
		foreach ($paidJobs as $job){
			$this->Job->id = $job;
			$this->Job->saveField('paid', 1);
		}
	}
	
	function payCancelled(){
		
	}
	
	function pay($key){
		$this->autoRender = false;
		$this->Job->recursive = -1;
		$jobs = $this->Job->find('all', array('conditions' => array('key' => $key)));
		if(count($jobs) == 0){
			$this->Session->setFlash(__('Please select at leaset one order', true));
			$this->redirect(array('action' => 'customerJobs', $this->Session->read('Auth.User.id')));
		}
		
		$jobIDs = array();
		$billValue = "";
		foreach($jobs as $job){
			$billValue += $job['Job']['total_price'];
			array_push($jobIDs, $job['Job']['id']);
		}
		
		$this->amount = $billValue;
		$this->Session->write('amount', $this->amount);
		$this->Session->write('paidJobs', $jobIDs);
		$idx = strpos(strtolower($this->here), 'pay');
		$this->tokenURL = 'http://' . $_SERVER['SERVER_NAME'] . substr($_SERVER['REQUEST_URI'], 0, $idx) . 'express/pay?csid=';
		$this->cancelURL = 'http://' . $_SERVER['SERVER_NAME'] . substr($_SERVER['REQUEST_URI'], 0, $idx) . 'express/cancel?csid=';
		$this->express();
	}
	
	function jobSettings($jobID, $first){
		if(!isset($first)){
			$this->Job->id = $this->data['Job']['id'];
			$this->Job->saveField('currency', $this->data['Job']['currency']);
			$this->Job->saveField('order_title', $this->data['Job']['OrderTitle']);
			$this->Job->saveField('translator_briefing', $this->data['Job']['OrderBrief']);
			
			if ($this->Job->save()) {
				$this->redirect(array('action' => 'customerJobs', $this->Session->read('Auth.User.id')));
			}
		}else{
			$this->data = $this->Job->read(null, $jobID);
			if($this->data['Job']['trans_type'] == 'e'){
				$this->set('transType', 'Express Translation');
			}else if($this->data['Job']['trans_type'] == 's'){
				$this->set('transType', 'Standard Translation');
			}
			
			$this->Job->SrcLanguage->recursive = -1;
			$srcLanguage = $this->Job->SrcLanguage->find('all', array('fields' => array('SrcLanguage.name'),
																		'conditions' => array('SrcLanguage.id' => $this->data['Job']['src_language_id'])));
			$this->set('srcLang', $srcLanguage[0]['SrcLanguage']['name']);
			
			$this->Job->TrgtLanguage->recursive = -1;
			$trgtLanguage = $this->Job->TrgtLanguage->find('all', array('fields' => array('TrgtLanguage.name'),
																		'conditions' => array('TrgtLanguage.id' => $this->data['Job']['trgt_language_id'])));
			$this->set('trgtLang', $trgtLanguage[0]['TrgtLanguage']['name']);
		
		}
	}
	
	function login() {
	    
	}
	
	function logout(){
		$this->redirect($this->AppAuth->logout());
	}
	
	function beforeFilter() {
		parent::beforeFilter();
		$this->AppAuth->allow('index', 'view', 'delete');
	}
	
	function calculatefile()
	{
		
		require_once "script/class.mp3file.php";
		
		$file_path = APP.WEBROOT_DIR.DS.'contents'.DS.$this->data['Job']['inputname'];
		//echo $file_path = "upload/audio/" . date("ymdhms")."_".$prefix.$_FILES["file"]["name"];
		//move_uploaded_file($this->data['Job']['file']['tmp_name'],$file_path);
		$mp3fileObj = new mp3file($file_path);
		$filetype = $mp3fileObj->file_extension($file_path);
		
		switch ($filetype) {
			case 'mp3':
				$result = $mp3fileObj->get_metadata();
				$price = $result['Length'];	
				
				break;
			case 'wav':
				$result = $mp3fileObj->getWavDuration($file_path);
				$price = $result;	
				break;
			default:
				$result = $mp3fileObj->getfilesize($file_path);
				$price = $result;	
		}

		

		return $price;

	}
	
	
	function ajaxfilecalculation($filename)
	{
		
		require_once "script/class.mp3file.php";
		
		$file_path = APP.WEBROOT_DIR.DS.'contents'.DS.$filename;

		$mp3fileObj = new mp3file($file_path);
		$filetype = $mp3fileObj->file_extension($file_path);
		
		switch ($filetype) {
			case 'mp3':
				$result = $mp3fileObj->get_metadata();
				$price = $result['Length'];				
				break;
			case 'wav':
				$result = $mp3fileObj->getWavDuration($file_path);
				$price = $result;	
				break;
			default:
				$result = $mp3fileObj->getfilesize($file_path);
				$price = $result;	
		}
		
		echo $price;
		exit;
	}
	
	function userdetail()
	{
		$users = $this->Session->read('Auth.User.id');

		$csv = $this->User->read(null,$users);
		if($csv['User']['csv'] == 1)
		{
			echo 1;	
		}
		else
		{
			echo 0;
		}
		exit;
	}
	
}
?>