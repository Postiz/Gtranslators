<?php
class PaymentRequestsController extends AppController {

	var $name = 'PaymentRequests';
	var $components = array('Session');

	function index($transID = null) {
		$userType = $this->Session->read('UserType');
		$user = $this->Session->read('Auth.User');
		if($userType == 1){
			if(is_null($transID)){
				$this->Session->setFlash(__('Invalid translator', true));
				$this->redirect('/pages/home');
			}elseif($user['id'] != $transID){
				$this->Session->setFlash(__('Invalid translator', true));
				$this->redirect('/pages/home');
			}else{
				$count = $this->PaymentRequest->Translator->find('count', array('conditions' => array('Translator.id' => $transID)));
				if($count == 0){
					$this->Session->setFlash(__('Invalid translator', true));
					$this->redirect('/pages/home');
				}
			}
			
			$this->paginate = array('conditions' => array('PaymentRequest.paid' => '0', 'PaymentRequest.translator_id' => $transID),
									'order' => array('PaymentRequest.created' => 'desc'));
		}elseif($userType == 2){
			if (!$this->Session->read('Auth.Admin')){
				$this->Session->write('Auth.redirect', $this->here);
				$this->redirect(array('controller' => 'Pages', 'action' => 'control_panel'));
			}		
			
			$this->layout = 'admin';
			$this->paginate = array('conditions' => array('PaymentRequest.paid' => '0'),
									'order' => array('PaymentRequest.created' => 'desc'));
		}else{
			$this->Session->setFlash(__('Please login first', true));
			$this->redirect('/pages/home');
		}
		
		$this->PaymentRequest->recursive = 0;
		$this->set('paymentRequests', $this->paginate());
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid payment request', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('paymentRequest', $this->PaymentRequest->read(null, $id));
	}

	function add($transID = null) {
		if (empty($this->data)) {
			if($transID == null){
				$this->Session->setFlash(__('Invalid translator', true));
				$this->redirect(array('/pages/home'));
			}
			$count = $this->PaymentRequest->Translator->find('count', array('conditions' => array('Translator.id' => $transID)));
			if($count == 0){
				$this->Session->setFlash(__('Invalid translator', true));
				$this->redirect(array('/pages/home'));
			}
		}else{
			if($this->data['PaymentRequest']['amount'] < 30){
				$this->Session->setFlash(__("The payment request can't be less than 30$", true));
				$this->redirect(array('action' => 'add', $this->data['PaymentRequest']['translator_id']));
			}
			$translator = $this->PaymentRequest->Translator->find('all', array('fields' => array('Translator.credit'),
																				'conditions' => array('Translator.id' => $this->data['PaymentRequest']['translator_id'])));
			if($translator[0]['Translator']['credit'] < $this->data['PaymentRequest']['amount']){
				$this->Session->setFlash(__("The payment request can't be more than your credit", true));
				$this->redirect(array('action' => 'add', $this->data['PaymentRequest']['translator_id']));
			}
			$this->PaymentRequest->create();
			if ($this->PaymentRequest->save($this->data)) {		
				$this->PaymentRequest->Translator->id = $this->data['PaymentRequest']['translator_id'];
				$credit = $this->PaymentRequest->Translator->field('Translator.credit');
				$this->PaymentRequest->Translator->saveField('credit', $credit - $this->data['PaymentRequest']['amount']); 
				$this->Session->write('credit', $credit - $this->data['PaymentRequest']['amount']);
				
				$idx = strpos(strtolower($this->here), '/payment_requests');
				$transURL = 'http://' . $_SERVER['SERVER_NAME'] . substr($_SERVER['REQUEST_URI'], 0, $idx) . '/translators/view/' . $this->PaymentRequest->Translator->field('Translator.id');
				$msg = 'A payment request with the amount ' . $this->data['PaymentRequest']['amount'] . '$ had been posted by <a href="' . $transURL . '">' . $this->PaymentRequest->Translator->field('Translator.username') . '</a>';
				$this->loadModel('Admin');
				$admin = $this->Admin->find('first');
				$this->sendEmail($admin['Admin']['email'], 'Admin', 'Payment requested', $msg);				
				
				$this->Session->setFlash(__('The payment request has been sent', true));
				//$this->redirect(array('action' => 'index', $this->data['PaymentRequest']['translator_id']));
				$idx = strpos(strtolower($this->here), '/add');
				echo '<script type="text/javascript">window.location = "' . substr($this->here, 0, $idx+1) . 'index/' . $this->data['PaymentRequest']['translator_id'] . '"</script>';
			} else {
				$this->Session->setFlash(__('The payment request could not be sent. Please, try again.', true));
			}
		}
		if(isset($transID)){
			$this->set('transID', $transID);
		}
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid payment request', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->PaymentRequest->save($this->data)) {
				$this->Session->setFlash(__('The payment request has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The payment request could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->PaymentRequest->read(null, $id);
		}
		$translators = $this->PaymentRequest->Translator->find('list');
		$this->set(compact('translators'));
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for payment request', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->PaymentRequest->delete($id)) {
			$this->Session->setFlash(__('Payment request deleted', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Payment request was not deleted', true));
		$this->redirect(array('action' => 'index'));
	}
	
	function pay($id){
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for payment request', true));
			$this->redirect(array('action'=>'index'));
		}
		$payReq = $this->PaymentRequest->find('all', array('conditions' => array('PaymentRequest.id' => $id)));
		if(count($payReq) == 0){
			$this->Session->setFlash(__('Invalid payment request', true));
			$this->redirect(array('action'=>'index'));
		}
		if($payReq[0]['PaymentRequest']['paid'] == 1){
			$this->Session->setFlash(__('Request alredy paid', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->write('PayRequestID', $payReq[0]['PaymentRequest']['id']);
		$this->Session->write('PayRequest.payPalUsername', $payReq[0]['PaymentRequest']['paypal_username']);
		$this->Session->write('PayRequest.payPalPassword', $payReq[0]['PaymentRequest']['paypal_password']);
		$this->Session->write('PayRequest.payPalsignature', $payReq[0]['PaymentRequest']['paypal_signature']);
		$this->Session->write('PayRequest.amount', $payReq[0]['PaymentRequest']['amount']);
		
		$idx = strpos(strtolower($this->here), '/pay/');
		$this->tokenURL = 'http://' . $_SERVER['SERVER_NAME'] . substr($_SERVER['REQUEST_URI'], 0, $idx) . '/express/pay?csid=';
		$this->cancelURL = 'http://' . $_SERVER['SERVER_NAME'] . substr($_SERVER['REQUEST_URI'], 0, $idx) . '/express/cancel?csid=';
		$this->express();
		
	}
	
	function express($callback = null)
	{
		$vendorPath = Configure::corePaths('component');
//
include $vendorPath['components'][0] . 'Paypal.php';
		//App::import('Component', 'Paypal');
		$payPal = new PaypalComponent();
		
		if (isset($callback) && isset($_REQUEST['csid']))
	    {
	        // Restore session
	        
	        if (!$payPal->restoreSession($_REQUEST['csid']))
	        {
	            $this->redirect('/');
	            exit;
	        }
	    }
	    
	    // Neither buyer nor credit card information since it
	    // is handled by PayPal
	    
	    $order = array(
	        'action' => CAKE_COMPONENT_PAYPAL_ORDER_TYPE_SALE,
	        'description' => 'CakePHP Component',
	        'total' => $this->Session->read('PayRequest.amount')
	    );
	    
	    // Set up common component's parameters
	    
	    $payPal->setEnvironment(CAKE_COMPONENT_PAYPAL_ENVIRONMENT_SANDBOX);
	    $payPal->setUser($this->Session->read('PayRequest.payPalUsername'));
	    $payPal->setPassword($this->Session->read('PayRequest.payPalPassword'));
	    $payPal->setSignature($this->Session->read('PayRequest.payPalsignature'));
	    $payPal->setOrder($order);
	    
	    if (!isset($callback))
	    {
	        // First call, user gets redirected to PayPal
	    	
	    	//'http://localhost/tolingo/jobs/express/pay?csid='
	    	//'http://localhost/tolingo/jobs/express/cancel?csid='
	        $payPal->setTokenUrl($this->tokenURL . session_id());
	        $payPal->setCancelUrl($this->cancelURL . session_id());
	        
	        // Save current session
	        
	        $payPal->storeSession();
	    
	        // Make payment via PayPal
	        
	        $result = $payPal->expressCheckout();
	        
	        if ($result === false)
	        {
	            echo 'ERROR: ' . $payPal->getError();
	            $this->Session->delete('PayRequest');
	            exit;
	        }
	    }
	    else if ($callback == 'cancel')
	    {
	    	$this->Session->delete('PayRequest');
	    	$idx = strpos(strtolower($this->here), 'express');
        	$URL = 'http://' . $_SERVER['SERVER_NAME'] . substr($_SERVER['REQUEST_URI'], 0, $idx) . 'payCancelled';
        	echo '<script type="text/javascript">window.location = "' . $URL . '"</script>';
	        exit;
	    }
	    else if ($callback == 'pay')
	    {
	        // Second call, make payment via PayPal
	        
	        $result = $payPal->expressCheckout();
	        
	        $this->Session->delete('PayRequest');
	        
	        // Check PayPal status
	        
	        if ($result === false)
	        {
	            echo 'ERROR: ' . $payPal->getError();
	            exit;
	        }
	        else
	        {
	        	$idx = strpos(strtolower($this->here), 'express');
	        	$URL = 'http://' . $_SERVER['SERVER_NAME'] . substr($_SERVER['REQUEST_URI'], 0, $idx) . 'paySucceeded';
	        	echo '<script type="text/javascript">window.location = "' . $URL . '"</script>';
	        	//$this->redirect(array('action' => 'paidSucceeded'));
	        	//$this->requestAction($url, $extra)
//	            echo 'Woha! Got the money!';
//	            echo '<pre>'; print_r($result); echo '</pre>';
	            exit;
	        }
	    }
	}
	
	function paySucceeded(){
		$this->layout = 'admin';
		$paidReq = $this->Session->read('PayRequestID');		
		$req = $this->PaymentRequest->read(null, $paidReq);
		
		$this->PaymentRequest->set(array(
			'paid' => 1
		));
		$this->PaymentRequest->save();
		$this->Session->delete('PayRequestID');
		
		$msg = 'The payment request sent on ' . $req['PaymentRequest']['created'] . ' with the amount ' . $req['PaymentRequest']['amount'] . '$ had been successfully processed';
		$this->sendEmail($req['Translator']['username'], $req['Translator']['first_name'] . ' ' . $req['Translator']['last_name'], 'Payment received', $msg);
		
	}
	
	function payCancelled(){
		$this->layout = 'admin';
	}
}
?>