$('document').ready(function(){
	$("#JobEnterTextForm").validate();
	writeQuote();
	showHideTrgtLang();
	$("#JobSrcLanguageId").change(function(){
		showHideTrgtLang();
		writeQuote();
		//zwriteQuote();
	});
	$("#JobTrgtLanguageId").change(function(){
		writeQuote();
	});
	$("file_upload").change(function(){
		writeQuote();
	});
});


function writeQuote(){
	var textValue = $("#next").val();
	var text = "";
	var tmp;
	
	
	if($("#JobSrcLanguageId").val() == "" || $("#JobSrcLanguageId").val() == null
			|| $("#JobTrgtLanguageId").val() == "" || $("#JobTrgtLanguageId").val() == null)
	{
		text += '<div class="sidetop"></div>';
		text += '<div class="widgetspace1">';
		text += '<font size="3">Quote</font>';
		text += '<br/><br/>To request a quote please select original and target language.';
		text += '</div>';
		text += '<div class="sidebot"></div><br/>';
		text1 = '<div class="sidetop"></div>';
		text1 += '<div class="widgetspace">';
		text1 += '<font size="3">Discount</font><br/><br/>';
		text1 += "Upload an email list as csv file and get 20% off on translation price";
		text1 += '</div>';
		text1 += '<div class="sidebot"></div>';
	}
	/*
	if($("#JobInputTxt").val() != "" && $("#JobInputTxt").val() != null){

		var count = $("#JobInputTxt").val().split(" ");
		text += '<br/><br/>The text contains ';
		tmp = 'The text contains ';
		if(count.length == 1){
			text += '1 Word';
			tmp += '1 Word';
		}else{
			text += count.length + ' Words';
			tmp += count.length + ' Words';
		}
		$.cookie('wordsCount', tmp);
	}
	*/
	if($("#JobSrcLanguageId").val() != "" && $("#JobSrcLanguageId").val() != null
			&& $("#JobTrgtLanguageId").val() != "" && $("#JobTrgtLanguageId").val() != null
			&& $("#next").val() != "" && $("#next").val() != null){
		
		if(textValue != '')
		{
			var ajax = '';
			var URL1 = window.location.href;
			var idx1 = URL1.indexOf('jobs/enterText', 0);
			var reqURL1 = URL1.substring(0, idx1) + 'jobs/ajaxfilecalculation/'+textValue;
			var ajaxCount = '';

			var totalCost = 0;
			$.ajax({
				type: 'POST',
				url: reqURL1,
				success: function(data1){					
					ajaxCount = data1;
					var URL2 = window.location.href;
					var idx2 = URL2.indexOf('jobs/enterText', 0);
					var reqURL2 = URL2.substring(0, idx2) + 'prices/getPairPrice/' + $("#JobSrcLanguageId").val() + "/" + $("#JobTrgtLanguageId").val();
					
					var totalCost = 0;
					$.ajax({
						type: 'POST',
						url: reqURL2,
						success: function(data){
							totalCost = ajaxCount * data;
							text += '<div class="sidetop"></div>';
							text += '<div class="widgetspace1">';
							text += '<font size="3">Quote</font>';
							text += '<br/><br/>Your order costs ';
							text += totalCost;
							text += '$ and will be finished during x days';
							$.cookie('period', 'Your order will be finished during x days');							
							$.cookie('totalCost', totalCost + '$');
							text += '</div>';
							text += '<div class="sidebot"></div><br/>';
							text1 = '<div class="sidetop"></div>';
							text1 += '<div class="widgetspace1">';
							text1 += '<font size="3">Discount</font><br/><br/>';
							text1 += "Upload an email list as csv file and get 20% off on translation price";
							text1 += '</div>';
							text1 += '<div class="sidebot"></div>';
							var finalText = text + text1;
							$("#sidebar").html(finalText);

							$.cookie('sidebar', text);
							
						}
					});	
					
				}
			});
		}
		else
		{
		
			var URL = window.location.href;
			var idx = URL.indexOf('jobs/enterText', 0);
			var reqURL = URL.substring(0, idx) + 'prices/getPairPrice/' + $("#JobSrcLanguageId").val() + "/" + $("#JobTrgtLanguageId").val();
			
			var totalCost = 0;
			$.ajax({
				type: 'POST',
				url: reqURL,
				success: function(data){
					var count = $("#JobInputTxt").val().split(" ");
					totalCost = count.length * data;
					text += '<div class="sidetop"></div>';
					text += '<div class="widgetspace1">';
					text += '<font size="3">Quote</font>';
					text += 'Your order costs ';
					text += totalCost;
					text += '$ and will be finished during x days';
					$.cookie('period', 'Your order will be finished during x days');
					
					$.cookie('totalCost', totalCost + '$');
					
					text += '</div>';
					text += '<div class="sidebot"></div>';
					$("#sidebar").html(text);
					
					$.cookie('sidebar', text);
					
					
				}
			});	
		}
		
	}
	
	
	
	var finalText = text + text1;
	$("#sidebar").html(finalText);

	$.cookie('sidebar', text);
}

function showHideTrgtLang(){
	if($("#JobSrcLanguageId").val() == null || $("#JobSrcLanguageId").val() == ""){
		$("#div_trgt_lang").html('Please select the original language first.');
	}else{
		var URL = window.location.href;
		var reqURL = URL.substring(0, URL.indexOf('jobs/', 0)) + 'languages/listLanguages'; 
		$.ajax({
	    	type: 'POST',
	    	url: reqURL,
	    	dataType: 'json',
	    	success: function(data){
				if(data.length != 0){
					var languages = "";
					languages += '<select id="JobTrgtLanguageId" class="required" name="data[Job][trgt_language_id]">';
					languages += '<option value="">-- Choose Target Language --</option>';
					$.each(data, function(){
						languages += '<option value="' + this['Language']['id'] + '">' + this['Language']['name'] + '</option>';						
					});
					languages += '</select>';
				}
				
				$("#div_trgt_lang").html(languages);
				
				$("#JobTrgtLanguageId").change(function(){
					writeQuote();
				});
		    },
		    error: function(message){
		        alert(message);
		    }
		});
	}
}