<?php
class PricesController extends AppController {

	var $name = 'Prices';

	function index() {
		$this->Price->recursive = 0;
		$this->paginate = array('fields' => array('SrcLanguage.name', 'TrgtLanguage.name', 'price'),
								'order' => array('SrcLanguage.name' => 'asc', 'TrgtLanguage.name' => 'asc'),
								'limit' => 50); 
		$this->set('prices', $this->paginate());
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid price', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('price', $this->Price->read(null, $id));
	}

	function add() {
		if (!empty($this->data)) {
			$this->Price->create();
			if ($this->Price->save($this->data)) {
				$this->Session->setFlash(__('The price has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The price could not be saved. Please, try again.', true));
			}
		}
		$srcLanguages = $this->Price->SrcLanguage->find('list');
		$trgtLanguages = $this->Price->TrgtLanguage->find('list');
		$this->set(compact('srcLanguages', 'trgtLanguages'));
	}
	
	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid price', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->Price->save($this->data)) {
				$this->Session->setFlash(__('The price has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The price could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Price->read(null, $id);
		}
		$srcLanguages = $this->Price->SrcLanguage->find('list');
		$trgtLanguages = $this->Price->TrgtLanguage->find('list');
		$this->set(compact('srcLanguages', 'trgtLanguages'));
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for price', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->Price->delete($id)) {
			$this->Session->setFlash(__('Price deleted', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Price was not deleted', true));
		$this->redirect(array('action' => 'index'));
	}
	
	function getLanguagePrices($srcLang){
		$this->autoRender = false;
		$this->loadModel('Language');
		//$this->Language->recursive = -1;
		$EngLangID = $this->Language->find('all', array('fields' => array('Language.id'),
														'conditions' => array('Language.name' => 'English')));
		$srcLangID = $this->Language->find('all', array('fields' => array('Language.id'),
														'conditions' => array('Language.name' => $srcLang)));
		
		$this->Price->recursive = 2;
		$prices = $this->Price->find('all', array('fields' => array('Price.<em>price</em>', 'SrcLanguage.name', 'TrgtLanguage.name'),
													'conditions' => array('Price.src_language_id' => $srcLangID[0]['Language']['id'])));
		$EngPrice = $this->Price->find('all', array('fields' => array('Price.price', 'SrcLanguage.name', 'TrgtLanguage.name'),
													'conditions' => array('Price.src_language_id' => $EngLangID[0]['Language']['id'], 'Price.trgt_language_id' => $srcLangID[0]['Language']['id'])));
		return array_merge($EngPrice, $prices);
	}
	
	function getPairPrice($srcLangID, $trgtLangID){
		$this->autoRender = false;
		$this->Price->recursive = -1;
		$price = $this->Price->find('all', array('fields' => array('price'),
													'conditions' => array('src_language_id' => $srcLangID, 'trgt_language_id' => $trgtLangID)));
		if(count($price) == 0){
			return 17.32;
		}else{
			return $price[0]['Price']['price'];
		}
	}
}
?>