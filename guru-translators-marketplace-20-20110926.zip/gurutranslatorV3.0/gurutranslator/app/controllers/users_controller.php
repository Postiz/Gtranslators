<?php
class UsersController extends AppController {

	var $name = 'Users';
	var $components = array('AppAuth', 'Mailer', 'Cookie', 'Session'); 

	function index() {
		$this->User->recursive = 0;
		$this->set('users', $this->paginate());
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid user', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('user', $this->User->read(null, $id));
	}

	function add() {
		if (!empty($this->data)) {
			$this->User->create();
			//$this->data = $this->AppAuth->hashPasswords($this->data);
			if ($this->User->save($this->data)) {
				$msg = 'Guru Translator says: welcome!<br/>' . $this->data['User']['first_name'] . ' ' . $this->data['User']['last_name'];
				$this->sendEmail($this->data['User']['username'], $this->data['User']['first_name'] . ' ' . $this->data['User']['last_name'], 'Transcree Translator registration', $msg);
				$this->Session->setFlash(__('Registration completed successfully, please check your email', true));
				$this->redirect(array('controller'=>'pages','action' => 'home'));
				$this->AppAuth->login();
				
				$this->Session->write('fullName', $this->data['User']['first_name'] . ' ' . $this->data['User']['last_name']);
				//$this->redirect('/pages/home');
				$idx = strpos(strtolower($this->here), '/users/add');
				echo '<script type="text/javascript">window.location = "' . substr($this->here, 0, $idx+1) . 'pages/home"</script>';
			} else {
				$this->Session->setFlash(__("Registration process couldn't be completed. Please, try again.", true));
			}
		}
		$countries = $this->User->Country->find('list', array('fields' => array('Country.id', 'Country.country_name')));
		$tmp = array(null => '-- Please select --');
		$countries = $tmp + $countries;
		$this->set(compact('countries'));
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid user', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->User->save($this->data)) {
				$this->Session->setFlash(__('The user has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The user could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->User->read(null, $id);
		}
		$countries = $this->User->Country->find('list');
		$this->set(compact('countries'));
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for user', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->User->delete($id)) {
			$this->Session->setFlash(__('User deleted', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('User was not deleted', true));
		$this->redirect(array('action' => 'index'));
	}
	
	function getPendingOrders(){
		
	}
	
	function requestQuote(){
		
	}
	
	function createBill(){
		
	}
	
	function checkEmailExists($email){
		$this->autoRender = false;
		$users = $this->User->find('all', array('fields' => array('User.id'),
												'conditions' => array('User.username' => $email)));
		if(count($users) > 0){
			return true;
		}else{
			$this->loadmodel('Translator');
			$translators = $this->Translator->find('all', array('fields' => array('Translator.id'),
																'conditions' => array('Translator.username' => $email)));
			if(count($translators) > 0){
				return true;
			}else{
				return false;
			}
		}
	}
	
	function login() {
	    //-- code inside this function will execute only when autoRedirect was set to false (i.e. in a beforeFilter).
	    if ($this->AppAuth->user()) 
		{
			$data = $this->Session->read('PlaceOrder');
			
			if(!empty($data))
			{
				$users = $this->Session->read('Auth.User.id');
				$slang = $this->Session->read('slang');
				$tlang = $this->Session->read('tlang');
				$filename = addslashes($this->Session->read('uploadfilename'));
				//$this->Session->write('dateFilename',$DateFile);
				$refname = $this->Session->read('refname');
				$cat = $this->Session->read('categoryID');
				$tprice = $this->Session->read('tprice');

				$csv = $this->User->read(null,$users);

				if($csv['User']['csv'] == 1)
				{
					$discount = ($tprice * 20)/100;
					$tprice = $tprice - $discount;
				}

				$this->User->query("INSERT INTO jobs (input_txt,src_language_id,trgt_language_id,category_id,user_id,total_price,referance) VALUES ('$filename','$slang','$tlang','$cat','$users','$tprice','$refname')");
				
				$slang = $this->Session->delete('slang');
				$tlang = $this->Session->delete('tlang');
				$filename = $this->Session->delete('uploadfilename');
				$refname = $this->Session->delete('refname');
				$cat = $this->Session->delete('categoryID');
				$tprice = $this->Session->delete('tprice');
				$this->Session->delete('cost');
			}
			
	        if (!empty($this->data) && $this->data['User']['remember']) {
	            $cookie = array();
	            $cookie['username'] = $this->data['User']['username'];
				$cookie['password'] = $this->data['User']['password'];
				
	            $this->Cookie->write('AppAuth.User', $cookie, true, '+2 weeks');
	            unset($this->data['User']['remember']);
	            $this->Session->setFlash(__('Your cookie is set.', true));
	        }
	        if($this->Session->read('Auth.redirect')){
	        	$this->redirect($this->Session->read('Auth.redirect'));
	        }else{
	        	$this->redirect($this->AppAuth->loginRedirect);	
	        }	        
	    }
	    if (empty($this->data)) {
	        $cookie = $this->Cookie->read('AppAuth.User');
	        $this->Session->write('User', $cookie);
	        if (!is_null($cookie)) {
	            if ($this->AppAuth->login($cookie)) {
	                //  Clear AppAuth message, just in case we use it.
					if($this->Session->read('Auth.redirect')){
			        	$this->redirect($this->Session->read('Auth.redirect'));
			        }else{
			        	$this->redirect($this->AppAuth->loginRedirect);	
			        }
	            } else { // Delete invalid Cookie
	                $this->Cookie->del('AppAuth.User');
	            }
	        }
	    }
	}
	
	function logout(){
		$this->Session->delete('UserType');
		$this->Session->delete('credit');
		$this->Session->delete('cost');
		$this->redirect($this->AppAuth->logout());
	}
	
	function summary(){	
		$userType = $this->Session->read('UserType');
		if(is_null($userType) || $userType != 0){
			$this->AppAuth->logout();
			$this->redirect(array('action' => 'summary'));
		}
		$user = $this->AppAuth->user();
		$this->loadModel('Job');
		$custJobs = $this->Job->find('all', array('conditions' => array('Job.user_id' => $user['User']['id'], 'Job.paid' => 0)));
		if(count($custJobs) > 0){
			$this->set('custJobs', count($custJobs));
		}
		$this->Session->write('fullName', $user['User']['first_name'] . ' ' . $user['User']['last_name']);
	}
	
	function orders(){
		$this->redirect(array('controller' => 'Jobs', 'action' => 'customerAllJobs', $this->Session->read('Auth.User.id'), 0));
	}
	
	function invoices(){
		$this->redirect(array('controller' => 'Jobs', 'action' => 'customerJobs', $this->Session->read('Auth.User.id')));
	}
	
	function settings(){
	}
	
	function editDetails($id = null){
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid customer', true));
			$this->redirect(array('action' => 'summary'));
		}
		if (!empty($this->data)) {
			if ($this->User->save($this->data)) {
				$this->Session->setFlash(__('Your details has been saved', true));
				$this->redirect(array('action' => 'settings'));
			} else {
				$this->Session->setFlash(__('Your details could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->User->read(null, $id);
		}
		$countries = $this->User->Country->find('list', array('fields' => array('Country.id', 'Country.country_name')));
		$tmp = array(null => '-- Please select --');
		$countries = $tmp + $countries;
		$this->set(compact('countries'));
		
		$days = array();
		for($i=1; $i<=31; $i++){
			$days[$i] = $i;
		}
		$this->set('days', array_merge(array(null => 'Day'), $days));
		$years = array();
		$year = date('Y');
		for($i=$year-5; $i>=$year-95; $i--){
			$years[$i] = $i;
		}
		$this->set('years', array_merge(array(null => 'Year'), $years));
		$months = array(null => 'Month', 1 => 'Jan', 2 => 'Feb', 3 => 'Mar', 4 => 'Apr', 5 => 'May', 6 => 'Jun',
								7 => 'Jul', 8 => 'Aug', 9 => 'Sep', 10 => 'Oct', 11 => 'Nov', 12 => 'Dec');		
		$this->set('months', $months);
		
		$types = array(null => '--none--', 1 => 'Skype', 2 => 'ICQ', 3 => 'AOL');
		$this->set('types', $types);
	}
	
	function changeEmail($id = null){
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid customer', true));
			$this->redirect(array('action' => 'summary'));
		}
		if (!empty($this->data)) {
			$this->User->recursive = -1;
			$password = $this->User->find('all', array('fields' => array('password'), 
														'conditions' => array('User.id' => $this->data['User']['id'])));
			if($password[0]['User']['password'] !== $this->AppAuth->hashPasswords($this->data['User']['password'])){
				$this->data['User']['password'] = '';
				$this->Session->setFlash(__('Wrong password. Please, try again.', true));
			}else if ($this->User->save($this->data)) {
				$this->Session->setFlash(__('Your email had been updated.', true));
				$this->redirect(array('action' => 'settings'));
			} else {
				$this->Session->setFlash(__('Your email could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->User->read(array('username', 'id'), $id);
		}
	}
	
	function editPassword($id = null){
	if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid customer', true));
			$this->redirect(array('action' => 'summary'));
		}
		if (!empty($this->data)) {
			$this->User->recursive = -1;
			$password = $this->User->find('all', array('fields' => array('password'), 
														'conditions' => array('User.id' => $this->data['User']['id'])));
			if($password[0]['User']['password'] !== $this->AppAuth->hashPasswords($this->data['User']['password'])){
				$this->data['User']['password'] = '';
				$this->Session->setFlash(__('Wrong password. Please, try again.', true));
			}else{
				$this->data['User']['password'] = $this->data['User']['newPassword'];
				$this->data = $this->AppAuth->hashPasswords($this->data);
				if ($this->User->save($this->data)) {			
					$this->Session->setFlash(__('Your password had been updated.', true));
					$this->redirect(array('action' => 'settings'));
				}else{
					$this->Session->setFlash(__('The password could not be updated. Please, try again.', true));
				}
			}
		}
		if (empty($this->data)) {
			$this->data = $this->User->read(array('username', 'id'), $id);
		}
	}
	
	function forgotPassword(){
		if(!empty($this->data)){
			$this->User->recursive = -1;
			$user = $this->User->find('all', array('fields' => array('id', 'first_name', 'last_name'), 
													'conditions' => array('username' => $this->data['User']['email'])));
			if(!$this->User->read(null, $user[0]['User']['id'])){
				$this->Session->setFlash(__('Customer not found.', true));
				$this->redirect(array('action' => 'forgotPassword'));
			}else{
				$key = $this->genRandomString();
				$this->User->set(array('password_key' => $key));
				if($this->User->save()){
					//Configure::write('debug', 2);
					$idx = strpos(strtolower($this->here), 'forgotpassword');
					$URL = 'http://' . $_SERVER['SERVER_NAME'] . substr($_SERVER['REQUEST_URI'], 0, $idx) . 'resetPassword/' . $key;
					$msg = 'Click the following link' . '<br/>' . $URL;
					$to = $user[0]['User']['first_name'] . ' ' . $user[0]['User']['last_name'];
					$this->sendEmail($this->data['User']['email'], $to, 'Confirm password change', $msg);
					//Configure::write('debug', 0);
					//$this->redirect(array('action' => 'passwordConfirmation'));
					$idx = strpos(strtolower($this->here), '/forgotpassword');
					echo '<script type="text/javascript">window.location = "' . substr($this->here, 0, $idx+1) . 'passwordConfirmation"</script>';	
				}
			}
		}
	}
	
	function resetPassword($key){
		$this->User->recursive = -1;
		$user = $this->User->find('all', array('fields' => array('id', 'username', 'first_name', 'last_name'), 
												'conditions' => array('password_key' => $key)));
		if(!$this->User->read(null, $user[0]['User']['id'])){
			$this->Session->setFlash(__('Customer not found.', true));
			$this->redirect(array('action' => 'forgotPassword'));
		}else{
			$newPassword = $this->genRandomString(8);
			$this->data['User']['username'] = $user[0]['User']['username'];
			$this->data['User']['password'] = $newPassword;
			$this->data = $this->AppAuth->hashPasswords($this->data);
			if ($this->User->save($this->data)) {
				$msg = 'Your new password is ' . $newPassword;
				$this->sendEmail($user[0]['User']['username'], $user[0]['User']['first_name'] . ' ' . $user[0]['User']['last_name'], 'Your new password', $msg);
			}
		}
	}
	
	function passwordConfirmation(){
		
	}
	
	function beforeFilter() {
		parent::beforeFilter();		
		
		$this->AppAuth->allow('add', 'checkEmailExists', 'login', 'forgotPassword', 'passwordConfirmation', 'resetPassword');
		$this->AppAuth->logoutRedirect = array('controller' => 'pages', 'action' => 'home'); 
		//$this->AppAuth->loginAction = array('controller' => 'Users', 'action' => 'login');
//		//$this->AppAuth->autoRedirect = false;
//		//$this->AppAuth->loginRedirect = array('action' => 'summary');
//		$this->AppAuth->logoutRedirect = array('controller' => 'pages', 'action' => 'home'); 
//		$this->AppAuth->authError ='';		
	}
}
?>