<?php
class TranslatorsController extends AppController {

	var $name = 'Translators';
	var $components = array('AppAuth', 'Session', 'Cookie', 'FileUpload');

	function index() {
		$this->Translator->recursive = 0;
		$this->set('translators', $this->paginate());
	}
	
	function listPending(){
		if (!$this->Session->read('Auth.Admin')){
			$this->AppAuth->logout();
			$this->Session->write('Auth.redirect', $this->here);
			$this->redirect(array('controller' => 'Pages', 'action' => 'control_panel'));
		}		
		
		$this->layout = 'admin';
		$this->Translator->recursive = 0;
		$this->paginate = array('fields' => array('id', 'username'),
								'conditions' => array('Translator.accepted' => 0),
								'order' => array('Translator.username' => 'asc'));
		$this->set('translators', $this->paginate());
	}
	
	function accept($id){
		if(!$this->Session->read('Auth.Admin')){
			$this->AppAuth->logout();
			$this->Session->write('Auth.redirect', $this->here);
			$this->redirect(array('controller' => 'Pages', 'action' => 'control_panel'));
		}
		$this->autoRender = false;
		$this->Translator->id = $id;
		if($this->Translator->saveField('accepted', true)){
			$this->Session->setFlash(__('Translator accepted', true));
		}else{
			$this->Session->setFlash(__('Acceptence failed', true));
		}
		$this->redirect(array('action' => 'listPending'));
	}
	
	function listUnbanned(){
		if (!$this->Session->read('Auth.Admin')){
			$this->AppAuth->logout();
			$this->Session->write('Auth.redirect', $this->here);
			$this->redirect(array('controller' => 'Pages', 'action' => 'control_panel'));
		}		
		
		$this->layout = 'admin';
		$this->Translator->recursive = 0;
		$this->paginate = array('fields' => array('id', 'username'),
								'conditions' => array('Translator.banned' => 0),
								'order' => array('Translator.username' => 'asc'));
		$this->set('translators', $this->paginate());
	}
	
	function ban($id){
		$this->autoRender = false;
		$this->Translator->id = $id;
		if($this->Translator->saveField('banned', true)){
			$this->Session->setFlash(__('Translator banned', true));
		}else{
			$this->Session->setFlash(__('Banning failed', true));
		}
		$this->redirect(array('action' => 'listUnbanned'));
	}

	function view($id = null, $admin = null) {
		if(isset($admin)){
			if(!$this->Session->read('Auth.Admin')){
				$this->Session->setFlash(__('Please login first', true));
				$this->Session->write('Auth.redirect', $this->here);
				$this->redirect(array('controller' => 'Admins', 'action' => 'login'));
			}
			$this->layout = "admin";
		}else{
			if(!$this->Session->read('Auth.User')){
				$this->Session->setFlash(__('Please login first', true));
				$this->Session->write('Auth.redirect', $this->here);
				$this->redirect(array('controller' => 'Users', 'action' => 'login'));
			}
		}
		$userType = $this->Session->read('UserType');
		if(!isset($userType)){
			$this->AppAuth->logout();
			$this->Session->setFlash(__('Please login first', true));
			$this->redirect(array('action' => 'view', $id));
		}
		if (!$id) {
			$this->Session->setFlash(__('Invalid translator', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('translator', $this->Translator->read(null, $id));
		
		$certificates = $this->Translator->Certificate->find('all', array('conditions' => array('Certificate.translator_id' => $id)));
		$this->set('certificates', $certificates);
		
		$skills = $this->Translator->TranslatorSkill->find('all', array('conditions' => array('TranslatorSkill.translator_id' => $id)));
		$this->set('skills', $skills);
		
		$specialists = $this->Translator->TranslatorSpecialist->find('all', array('conditions' => array('TranslatorSpecialist.translator_id' => $id)));
		$this->set('specialists', $specialists);
	}

	function add() {
		if (!empty($this->data)) {
			$this->Translator->create();
			$key = $this->genRandomString(25);
			$this->data['Translator']['activation_code'] = $key;
			$this->data['Translator']['password'] = $this->AppAuth->password($this->data['Translator']['password']);
						
			if ($this->Translator->save($this->data)) {
				$idx = strpos(strtolower($this->here), 'add');
				$URL = 'http://' . $_SERVER['SERVER_NAME'] . substr($_SERVER['REQUEST_URI'], 0, $idx) . 'activate/' . $this->Translator->id . '/' . $key;
					
				$to = $this->data['Translator']['username'];
				$toName = $this->data['Translator']['first_name'] . ' ' . $this->data['Translator']['last_name'];
				$msg = 'To activate your account please click the following link' . '<br/>' . $URL;
				$this->sendEmail($to, $toName, 'Guru Translator registration', $msg, '/Translators/activate');
				
				//$this->redirect(array('action' => 'activate'));
				$idx = strpos(strtolower($this->here), '/translators/add');
				echo '<script type="text/javascript">window.location = "' . substr($this->here, 0, $idx+1) . 'translators/activate"</script>';
			}else {
				$this->Session->setFlash(__('Your account could not be created. Please, try again.', true));
			}
		}
		$countries = $this->Translator->Country->find('list', array('fields' => array('Country.id', 'Country.country_name')));
		$tmp = array(null => '-- Please select --');
		$countries = $tmp + $countries;
		$firstLanguages = $this->Translator->FirstLanguage->find('list');
		$secondLanguages = $this->Translator->SecondLanguage->find('list');
		$this->set(compact('countries', 'firstLanguages', 'secondLanguages'));
	}
	
	function activate($id = null, $key = null){
		if(isset($id) && isset($key)){
			$this->Translator->recursive = -1;			
			$translator = $this->Translator->findAllById($id);
			if($translator[0]['Translator']['activation_code'] != $key){
				$this->set('msg', 'Invalid account or activation key');
				return;
			}
			
			$this->Session->write('User', $translator[0]['Translator']);
			
			if(count($translator) > 0){
				$this->Translator->id = $id;
				$this->Translator->set(array('active' => true, 'state' => 1));
				if($this->Translator->save()){
					$this->Session->setFlash(__('Thank you for activating your account', true));
					$this->AppAuth->login();
					$this->Session->write('fullName', $translator[0]['Translator']['first_name'] . ' ' . $translator[0]['Translator']['last_name']);
					$this->redirect(array('action' => 'addExperience', $id));
				}
			}
			else{
				$this->set('msg', 'Invalid account or activation key');
			}
		}else{
			$this->set('msg', 'You will now receive an e-mail. Please click on the link to activate your account and to complete the registration process.');
		}
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid translator', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->Translator->save($this->data)) {
				$this->Session->setFlash(__('The translator has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The translator could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Translator->read(null, $id);
		}
		$countries = $this->Translator->Country->find('list');
		$firstLanguages = $this->Translator->FirstLanguage->find('list');
		$secondLanguages = $this->Translator->SecondLanguage->find('list');
		$this->set(compact('countries', 'firstLanguages', 'secondLanguages'));
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for translator', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->Translator->delete($id)) {
			$this->Session->setFlash(__('Translator deleted', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Translator was not deleted', true));
		$this->redirect(array('action' => 'index'));
	}
	
	function addExperience($id){
		if(!empty($this->data)){
			if($this->FileUpload->success){
				$user = $this->AppAuth->user();
				
				$this->Translator->id = $user['User']['id'];
				$this->Translator->set(array('experience' => $this->data['Translator']['experience'], 'cv_file_name' => $this->FileUpload->finalFile, 'state' => 2));
				if($this->Translator->save()){
					chmod($this->FileUpload->finalFile, 0777);
					$this->redirect(array('action' => 'addQualifications', $this->Translator->id));
				}else{
					$this->Session->setFlash(__('Error in saving your data. Please, try again.', true));
				}
			}else{
				$this->Session->setFlash(__('Your CV could not be uploaded. Please, try again.', true));
				$this->redirect(array('action' => 'addExperience', $this->Translator->id));
			}
		}else{
			if(!isset($id)){
				$this->Session->setFlash(__('Invalid account.', true));
				$this->redirect(array('action' => 'login'));
			}else{
				$this->data = $this->Translator->read(null, $id);
			}
		}
	}
	
	function uploadFile($id){
		$this->autoRender = false;
		
		if($this->FileUpload->success){
			$srcFileName = $this->FileUpload->uploadedFile;
			$this->Translator->Certificate->create();
			$this->Translator->Certificate->set(array('original_file_name' => $srcFileName['name'],
														'final_file_name' => $this->FileUpload->finalFile,
														'translator_id' => $id));
			$this->Translator->Certificate->save();
			
			chmod($this->FileUpload->finalFile, 0777);
		}
		
		$user = $this->AppAuth->user();
		$this->redirect(array('action' => 'addCertificate', $user['User']['id']));
	}
	
	function removeCertificate($certificateID){
		$this->autoRender = false;
		
		$this->Translator->Certificate->recursive = -1;
		$certificate = $this->Translator->Certificate->find('all', array('fields' => array('Certificate.final_file_name'),
																			'conditions' => array('Certificate.id' => $certificateID)));
		unlink('CVs/' . $certificate[0]['Certificate']['final_file_name']);
		$this->Translator->Certificate->delete($certificateID);
		
		$user = $this->AppAuth->user();
		$this->redirect(array('action' => 'addCertificate', $user['User']['id']));
	}
	
	function addQualifications($id){
		if(!empty($this->data)){
			$this->data['Translator']['state'] = 3;
			$user = $this->AppAuth->user();
			$this->Translator->id = $user['User']['id'];
			$this->Translator->set(array('professional' => $this->data['Translator']['professional'],
			'state' => 3));
			if($this->Translator->save()){
				$this->redirect(array('action' => 'addCertificate', $this->Translator->id));
			}else{
				$this->Session->setFlash(__('Error in saving your data', true));
			}
		}else{
			$this->data = $this->Translator->read(null, $id);
		}
	}
	
	function addCertificate($id, $leave = null){		
		$certificates = $this->Translator->Certificate->find('all', array('fields' => array('Certificate.id', 'Certificate.original_file_name', 'Certificate.final_file_name'),
																			'conditions' => array('Certificate.translator_id' => $id)));
		$this->set('certificates', $certificates);
		
		$this->set('id', $id);
		
		if($leave){
			if(count($certificates) == 0){
				$this->Session->setFlash(__('Please upload at least on certificate'), true);
			}else{
				$this->Translator->id = $id;
				if(!$this->Translator->saveField('state', 4)){
					$this->Session->setFlash(__('Error in saving your data'), true);
				}else{
					$this->redirect(array('action' => 'addLanguages', $id));
				}
			}
		}
	}
	
	function removeSkillLanguages($skillID){
		$this->autoRender = false;
		$user = $this->AppAuth->user();
		$this->Translator->TranslatorSkill->delete($skillID);
		
		$this->Translator->TranslatorSkill->recursive = -1;
		
		$skills = $this->Translator->TranslatorSkill->query('SELECT translator_skills.id, lang1.name, lang2.name FROM translator_skills, languages lang1, languages lang2 WHERE translator_id = ' . $user['User']['id'] . ' and lang1.id = src_language_id and  lang2.id = trgt_language_id');
		
		return json_encode($skills);
	}
	
	function addSkillLanguages($id, $srcLang, $trgtLang){
		$this->autoRender = false;
		
		$this->Translator->TranslatorSkill->query('INSERT INTO translator_skills(translator_id, src_language_id, trgt_language_id) VALUES (' . $id . ', ' . $srcLang . ', ' . $trgtLang . ')');
		
		$this->Translator->TranslatorSkill->recursive = -1;
		$skills = $this->Translator->TranslatorSkill->query('SELECT translator_skills.id, lang1.name, lang2.name FROM translator_skills, languages lang1, languages lang2 WHERE translator_id = ' . $id . ' and lang1.id = src_language_id and  lang2.id = trgt_language_id'); 
		
		return json_encode($skills);
	}
	
	function addLanguages($id){
		$this->Translator->FirstLanguage->recursive = -1;
		$languages = $this->Translator->FirstLanguage->find('list', array('fields' => array('FirstLanguage.id', 'FirstLanguage.name'),
																		  'order' => array('FirstLanguage.Name' => 'asc')));
		$tmp = array(null => '-- Please select language --');
		$languages = $tmp + $languages;
		$this->set('languages', $languages);
		
		$this->Translator->TranslatorSkill->recursive = -1;
		$user = $this->AppAuth->user();
		$skills = $this->Translator->TranslatorSkill->query('SELECT translator_skills.id, lang1.name, lang2.name FROM translator_skills, languages lang1, languages lang2 WHERE translator_id = ' . $user['User']['id'] . ' and lang1.id = src_language_id and  lang2.id = trgt_language_id');
		$this->set('skills', $skills);
		
		if(!empty($this->data)){			
			$this->Translator->id = $user['User']['id'];
			$this->data['Translator']['state'] = 5;
			if(!$this->Translator->save($this->data)){
				$this->Session->setFlash(__('Error in saving your data', true));
			}else{				
				$this->redirect(array('action' => 'addSpecialists', $user['User']['id']));
			}
		}else{
			$this->data['Translator']['id'] = $id;
			$this->set('id', $id);
		}
	}
	
	function addSpecialists($id){
		$this->loadModel('Category');
		$cats = $this->Category->find('all', array('fields' => array('Category.id', 'Category.name'),
													'order' => array('Category.name' => 'asc')));
		$this->set('cats', $cats);
		
		$user = $this->AppAuth->user();
		
		if(!empty($this->data)){
			$saved = false;
			foreach ($cats as $cat){
				if($this->data['translator'][$cat['Category']['id']] != null){
					$saved = true;
				}
				$this->Translator->TranslatorSpecialist->create();
				if($this->data['translator'][$cat['Category']['id']] == 'E'){
					if($this->data['Translator'][$cat['Category']['id']] == ""){
						$this->Session->setFlash(__('Please type your experience', true));
						$this->redirect(array('action' => 'addSpecialists', $user['User']['id']));
						break;
					}else{
						$this->Translator->TranslatorSpecialist->set('desc', $this->data['Translator'][$cat['Category']['id']]);
					}
				}
				$this->Translator->id = $user['User']['id'];
				$this->Translator->TranslatorSpecialist->set(array('value' => $this->data['translator'][$cat['Category']['id']],
																	'translator_id' => $user['User']['id'],
																	'category_id' => $cat['Category']['id']));
				$this->Translator->TranslatorSpecialist->save();
			}
			if($saved){
				$this->Translator->id = $user['User']['id'];
				if($this->Translator->saveField('state', 6)){
					$this->redirect(array('action' => 'addComplete', $user['User']['id']));
				}else{
					$this->Session->setFlash(__('Error in saving your data', true));
					$this->redirect(array('action' => 'addSpecialists', $user['User']['id']));
				}
			}else{
				$this->Session->setFlash(__('Please select at least one category', true));
				$this->redirect(array('action' => 'addSpecialists', $user['User']['id']));
			}
		}
	}
	
	function addComplete($id){
		if(!empty($this->data)){
			$user = $this->AppAuth->user();
			$this->Translator->id = $user['User']['id'];;
			if($this->Translator->saveField('state', 7)){
				$this->redirect(array('action' => 'regCompleted'));
			}
		}
	}
	
	function regCompleted(){
		
	}
	
	function checkEmailExists($email){
		$this->autoRender = false;
		$translators = $this->Translator->find('all', array('fields' => array('Translator.id'),
															'conditions' => array('Translator.username' => $email)));
		if(count($translators) > 0){
			return true;
		}
		else{
			$this->loadmodel('User');
			$users = $this->User->find('all', array('fields' => array('User.id'),
													'conditions' => array('User.username' => $email)));
			if(count($users) > 0){
				return true;
			}else{
				return false;
			}
		}
	}
	
	function redirectUponState(){
		$this->autoRender = false;
		
		$user = $this->Session->read('Auth.User');
		if($user['active'] == 0){
			$this->Session->setFlash(__('Please activate your account', true));
			$this->AppAuth->logout();
			$this->Session->delete('UserType');
			$this->redirect('/pages/home');
		}
		if($user['banned'] == 1){
			$this->Session->setFlash(__('Your account is banned', true));
			$this->AppAuth->logout();
			$this->Session->delete('UserType');
			$this->redirect('/pages/home');
		}
		
		switch ($user['state']){
			case 1:
				$this->redirect(array('action' => 'addExperience', $user['id']));
				break;
			case 2:
				$this->redirect(array('action' => 'addQualifications', $user['id']));
				break;
			case 3:
				$this->redirect(array('action' => 'addCertificate', $user['id']));
				break;
			case 4:
				$this->redirect(array('action' => 'addLanguages', $user['id']));
				break;
			case 5:
				$this->redirect(array('action' => 'addSpecialists', $user['id']));
				break;
			case 6:
				$this->redirect(array('action' => 'addComplete', $user['id']));
				break;
			case 7:
				if($user['accepted'] == 0){
					$this->loadModel('Setting');
					$this->Setting->recursive = -1;
					$mode = $this->Setting->find('all', array('fields' => array('value'), 'conditions' => array('key' => 'auto_accept_translators')));
					if($mode[0]['Setting']['value'] == 0){					
						$this->Session->setFlash(__('Your account is not accepted yet', true));
						$this->AppAuth->logout();
						$this->Session->delete('UserType');
						$this->redirect('/pages/home');
					}else{
						$this->Translator->id = $user['id'];
						$this->Translator->saveField('accepted', true);
					}
				}				
			
				$loginRedirect = $this->Session->read('Auth.redirect');				
				if(is_null($loginRedirect) || $loginRedirect == '/'){
					$this->redirect(array('controller' => 'Jobs', 'action' => 'index'));
				}elseif(strtolower($loginRedirect) == '/jobs/index' || strtolower($loginRedirect) == '/jobs/' || strtolower($loginRedirect) == '/jobs'){
					$this->redirect(array('controller' => 'Jobs', 'action' => 'index'));
				}else{
					$this->redirect($loginRedirect);
				}
				break;
			default:
				$this->redirect(array('action' => 'addExperience', $user['id']));
				break;	
		}
	}
	
	function login() {
		//$this->redirect(array('controller' => 'Users', 'action' => 'login', 1));
	    //-- code inside this function will execute only when autoRedirect was set to false (i.e. in a beforeFilter).
		
	    if ($this->AppAuth->user()) {
	        if (!empty($this->data) && $this->data['Translator']['remember']) {
	            $cookie = array();
	            $cookie['username'] = $this->data['Translator']['username'];
	            $cookie['password'] = $this->data['Translator']['password'];
	            $this->Cookie->write('AppAuth.Translator', $cookie, true, '+2 weeks');
	            unset($this->data['Translator']['remember']);
	            $this->Session->setFlash(__('Your cookie is set.', true));
	        }
	        //$this->redirect(array('action' => 'redirectUponState'));
	    }
	    if (empty($this->data)) {
	        $cookie = $this->Cookie->read('AppAuth.Translator');
	        if (!is_null($cookie)) {
	            if ($this->AppAuth->login($cookie)) {
	                //  Clear AppAuth message, just in case we use it.
	                //$this->redirect($this->AppAuth->loginRedirect);
	            } else { // Delete invalid Cookie
	                $this->Cookie->del('AppAuth.Translator');
	            }
	        }
	    }
	}
	
	function logout(){
		$this->redirect($this->AppAuth->logout());
	}
	
	function beforeFilter() {
		parent::beforeFilter();
		
		$this->AppAuth->allow('login','view', 'accept', 'add', 'checkEmailExists', 'activate', 'listPending', 'listUnbanned');
		
		//$this->AppAuth->loginAction = array('controller' => 'Users', 'action' => 'login');
		//$this->AppAuth->logoutRedirect = array('controller' => 'pages', 'action' => 'home'); 
		
		//$this->AppAuth->autoRedirect = false;
//		$this->AppAuth->loginRedirect = array('action' => 'redirectUponState');
//		
//		$this->AppAuth->authError ='';		
		
		$this->FileUpload->uploadDir = 'CVs';
		$this->FileUpload->fileVar = 'cv';
		$this->FileUpload->allowedTypes = array('application/pdf',
											  	'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
											  	'application/msword');
	}
}
?>