<?php
class TranslatorSpecialistsController extends AppController {

	var $name = 'TranslatorSpecialists';

	function index() {
		$this->TranslatorSpecialist->recursive = 0;
		$this->set('translatorSpecialists', $this->paginate());
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid translator specialist', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('translatorSpecialist', $this->TranslatorSpecialist->read(null, $id));
	}

	function add() {
		if (!empty($this->data)) {
			$this->TranslatorSpecialist->create();
			if ($this->TranslatorSpecialist->save($this->data)) {
				$this->Session->setFlash(__('The translator specialist has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The translator specialist could not be saved. Please, try again.', true));
			}
		}
		$translators = $this->TranslatorSpecialist->Translator->find('list');
		$categories = $this->TranslatorSpecialist->Category->find('list');
		$this->set(compact('translators', 'categories'));
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid translator specialist', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->TranslatorSpecialist->save($this->data)) {
				$this->Session->setFlash(__('The translator specialist has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The translator specialist could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->TranslatorSpecialist->read(null, $id);
		}
		$translators = $this->TranslatorSpecialist->Translator->find('list');
		$categories = $this->TranslatorSpecialist->Category->find('list');
		$this->set(compact('translators', 'categories'));
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for translator specialist', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->TranslatorSpecialist->delete($id)) {
			$this->Session->setFlash(__('Translator specialist deleted', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Translator specialist was not deleted', true));
		$this->redirect(array('action' => 'index'));
	}
}
?>