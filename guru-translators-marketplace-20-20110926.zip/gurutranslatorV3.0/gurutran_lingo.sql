-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 05, 2011 at 09:34 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `gurutran_lingo`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(500) NOT NULL,
  `password` varchar(500) NOT NULL,
  `email` varchar(500) default NULL,
  `created` date NOT NULL,
  `modified` date NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `username_2` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`, `email`, `created`, `modified`) VALUES
(1, 'admin', 'bfe3d710c333846fce805242001b7e3ce8ed1a55', 'support@guruscript.com', '2011-02-02', '2011-05-05');

-- --------------------------------------------------------

--
-- Table structure for table `bids`
--

CREATE TABLE `bids` (
  `id` int(11) NOT NULL auto_increment,
  `job_id` int(11) NOT NULL,
  `translator_id` int(11) NOT NULL,
  `subject` varchar(500) NOT NULL,
  `body` varchar(5000) NOT NULL,
  `period` int(11) NOT NULL,
  `created` date NOT NULL,
  `modified` date NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `job_id_2` (`job_id`,`translator_id`),
  KEY `job_id` (`job_id`,`translator_id`),
  KEY `translator_id` (`translator_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `bids`
--


-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(250) NOT NULL,
  `created` date default NULL,
  `modified` date default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `created`, `modified`) VALUES
(1, 'Corresponde/Job applications', NULL, NULL),
(2, 'Economy / Business', NULL, NULL),
(3, 'Software / Internet', NULL, NULL),
(4, 'Industry / Technology', NULL, NULL),
(5, 'Marketing / PR', NULL, NULL),
(6, 'Tourism', NULL, NULL),
(7, 'Art / Culture', NULL, NULL),
(8, 'Architecture', NULL, NULL),
(10, 'Law', NULL, NULL),
(11, 'Politics', NULL, NULL),
(12, 'Insurance / Finance', NULL, NULL),
(13, 'Science / Research', NULL, NULL),
(14, 'Private / Leisure', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `certificates`
--

CREATE TABLE `certificates` (
  `id` int(11) NOT NULL auto_increment,
  `original_file_name` varchar(1000) NOT NULL,
  `final_file_name` varchar(1000) NOT NULL,
  `translator_id` int(11) NOT NULL,
  `created` date NOT NULL,
  `modified` date NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `translator_id` (`translator_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `certificates`
--


-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` int(11) NOT NULL auto_increment,
  `country_code` varchar(2) NOT NULL default '',
  `country_name` varchar(100) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=240 ;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES
(1, 'US', 'United States'),
(2, 'CA', 'Canada'),
(3, 'AF', 'Afghanistan'),
(4, 'AL', 'Albania'),
(5, 'DZ', 'Algeria'),
(6, 'DS', 'American Samoa'),
(7, 'AD', 'Andorra'),
(8, 'AO', 'Angola'),
(9, 'AI', 'Anguilla'),
(10, 'AQ', 'Antarctica'),
(11, 'AG', 'Antigua and/or Barbuda'),
(12, 'AR', 'Argentina'),
(13, 'AM', 'Armenia'),
(14, 'AW', 'Aruba'),
(15, 'AU', 'Australia'),
(16, 'AT', 'Austria'),
(17, 'AZ', 'Azerbaijan'),
(18, 'BS', 'Bahamas'),
(19, 'BH', 'Bahrain'),
(20, 'BD', 'Bangladesh'),
(21, 'BB', 'Barbados'),
(22, 'BY', 'Belarus'),
(23, 'BE', 'Belgium'),
(24, 'BZ', 'Belize'),
(25, 'BJ', 'Benin'),
(26, 'BM', 'Bermuda'),
(27, 'BT', 'Bhutan'),
(28, 'BO', 'Bolivia'),
(29, 'BA', 'Bosnia and Herzegovina'),
(30, 'BW', 'Botswana'),
(31, 'BV', 'Bouvet Island'),
(32, 'BR', 'Brazil'),
(33, 'IO', 'British lndian Ocean Territory'),
(34, 'BN', 'Brunei Darussalam'),
(35, 'BG', 'Bulgaria'),
(36, 'BF', 'Burkina Faso'),
(37, 'BI', 'Burundi'),
(38, 'KH', 'Cambodia'),
(39, 'CM', 'Cameroon'),
(40, 'CV', 'Cape Verde'),
(41, 'KY', 'Cayman Islands'),
(42, 'CF', 'Central African Republic'),
(43, 'TD', 'Chad'),
(44, 'CL', 'Chile'),
(45, 'CN', 'China'),
(46, 'CX', 'Christmas Island'),
(47, 'CC', 'Cocos (Keeling) Islands'),
(48, 'CO', 'Colombia'),
(49, 'KM', 'Comoros'),
(50, 'CG', 'Congo'),
(51, 'CK', 'Cook Islands'),
(52, 'CR', 'Costa Rica'),
(53, 'HR', 'Croatia (Hrvatska)'),
(54, 'CU', 'Cuba'),
(55, 'CY', 'Cyprus'),
(56, 'CZ', 'Czech Republic'),
(57, 'DK', 'Denmark'),
(58, 'DJ', 'Djibouti'),
(59, 'DM', 'Dominica'),
(60, 'DO', 'Dominican Republic'),
(61, 'TP', 'East Timor'),
(62, 'EC', 'Ecudaor'),
(63, 'EG', 'Egypt'),
(64, 'SV', 'El Salvador'),
(65, 'GQ', 'Equatorial Guinea'),
(66, 'ER', 'Eritrea'),
(67, 'EE', 'Estonia'),
(68, 'ET', 'Ethiopia'),
(69, 'FK', 'Falkland Islands (Malvinas)'),
(70, 'FO', 'Faroe Islands'),
(71, 'FJ', 'Fiji'),
(72, 'FI', 'Finland'),
(73, 'FR', 'France'),
(74, 'FX', 'France, Metropolitan'),
(75, 'GF', 'French Guiana'),
(76, 'PF', 'French Polynesia'),
(77, 'TF', 'French Southern Territories'),
(78, 'GA', 'Gabon'),
(79, 'GM', 'Gambia'),
(80, 'GE', 'Georgia'),
(81, 'DE', 'Germany'),
(82, 'GH', 'Ghana'),
(83, 'GI', 'Gibraltar'),
(84, 'GR', 'Greece'),
(85, 'GL', 'Greenland'),
(86, 'GD', 'Grenada'),
(87, 'GP', 'Guadeloupe'),
(88, 'GU', 'Guam'),
(89, 'GT', 'Guatemala'),
(90, 'GN', 'Guinea'),
(91, 'GW', 'Guinea-Bissau'),
(92, 'GY', 'Guyana'),
(93, 'HT', 'Haiti'),
(94, 'HM', 'Heard and Mc Donald Islands'),
(95, 'HN', 'Honduras'),
(96, 'HK', 'Hong Kong'),
(97, 'HU', 'Hungary'),
(98, 'IS', 'Iceland'),
(99, 'IN', 'India'),
(100, 'ID', 'Indonesia'),
(101, 'IR', 'Iran (Islamic Republic of)'),
(102, 'IQ', 'Iraq'),
(103, 'IE', 'Ireland'),
(104, 'IL', 'Israel'),
(105, 'IT', 'Italy'),
(106, 'CI', 'Ivory Coast'),
(107, 'JM', 'Jamaica'),
(108, 'JP', 'Japan'),
(109, 'JO', 'Jordan'),
(110, 'KZ', 'Kazakhstan'),
(111, 'KE', 'Kenya'),
(112, 'KI', 'Kiribati'),
(113, 'KP', 'Korea, Democratic People''s Republic of'),
(114, 'KR', 'Korea, Republic of'),
(115, 'KW', 'Kuwait'),
(116, 'KG', 'Kyrgyzstan'),
(117, 'LA', 'Lao People''s Democratic Republic'),
(118, 'LV', 'Latvia'),
(119, 'LB', 'Lebanon'),
(120, 'LS', 'Lesotho'),
(121, 'LR', 'Liberia'),
(122, 'LY', 'Libyan Arab Jamahiriya'),
(123, 'LI', 'Liechtenstein'),
(124, 'LT', 'Lithuania'),
(125, 'LU', 'Luxembourg'),
(126, 'MO', 'Macau'),
(127, 'MK', 'Macedonia'),
(128, 'MG', 'Madagascar'),
(129, 'MW', 'Malawi'),
(130, 'MY', 'Malaysia'),
(131, 'MV', 'Maldives'),
(132, 'ML', 'Mali'),
(133, 'MT', 'Malta'),
(134, 'MH', 'Marshall Islands'),
(135, 'MQ', 'Martinique'),
(136, 'MR', 'Mauritania'),
(137, 'MU', 'Mauritius'),
(138, 'TY', 'Mayotte'),
(139, 'MX', 'Mexico'),
(140, 'FM', 'Micronesia, Federated States of'),
(141, 'MD', 'Moldova, Republic of'),
(142, 'MC', 'Monaco'),
(143, 'MN', 'Mongolia'),
(144, 'MS', 'Montserrat'),
(145, 'MA', 'Morocco'),
(146, 'MZ', 'Mozambique'),
(147, 'MM', 'Myanmar'),
(148, 'NA', 'Namibia'),
(149, 'NR', 'Nauru'),
(150, 'NP', 'Nepal'),
(151, 'NL', 'Netherlands'),
(152, 'AN', 'Netherlands Antilles'),
(153, 'NC', 'New Caledonia'),
(154, 'NZ', 'New Zealand'),
(155, 'NI', 'Nicaragua'),
(156, 'NE', 'Niger'),
(157, 'NG', 'Nigeria'),
(158, 'NU', 'Niue'),
(159, 'NF', 'Norfork Island'),
(160, 'MP', 'Northern Mariana Islands'),
(161, 'NO', 'Norway'),
(162, 'OM', 'Oman'),
(163, 'PK', 'Pakistan'),
(164, 'PW', 'Palau'),
(165, 'PA', 'Panama'),
(166, 'PG', 'Papua New Guinea'),
(167, 'PY', 'Paraguay'),
(168, 'PE', 'Peru'),
(169, 'PH', 'Philippines'),
(170, 'PN', 'Pitcairn'),
(171, 'PL', 'Poland'),
(172, 'PT', 'Portugal'),
(173, 'PR', 'Puerto Rico'),
(174, 'QA', 'Qatar'),
(175, 'RE', 'Reunion'),
(176, 'RO', 'Romania'),
(177, 'RU', 'Russian Federation'),
(178, 'RW', 'Rwanda'),
(179, 'KN', 'Saint Kitts and Nevis'),
(180, 'LC', 'Saint Lucia'),
(181, 'VC', 'Saint Vincent and the Grenadines'),
(182, 'WS', 'Samoa'),
(183, 'SM', 'San Marino'),
(184, 'ST', 'Sao Tome and Principe'),
(185, 'SA', 'Saudi Arabia'),
(186, 'SN', 'Senegal'),
(187, 'SC', 'Seychelles'),
(188, 'SL', 'Sierra Leone'),
(189, 'SG', 'Singapore'),
(190, 'SK', 'Slovakia'),
(191, 'SI', 'Slovenia'),
(192, 'SB', 'Solomon Islands'),
(193, 'SO', 'Somalia'),
(194, 'ZA', 'South Africa'),
(195, 'GS', 'South Georgia South Sandwich Islands'),
(196, 'ES', 'Spain'),
(197, 'LK', 'Sri Lanka'),
(198, 'SH', 'St. Helena'),
(199, 'PM', 'St. Pierre and Miquelon'),
(200, 'SD', 'Sudan'),
(201, 'SR', 'Suriname'),
(202, 'SJ', 'Svalbarn and Jan Mayen Islands'),
(203, 'SZ', 'Swaziland'),
(204, 'SE', 'Sweden'),
(205, 'CH', 'Switzerland'),
(206, 'SY', 'Syrian Arab Republic'),
(207, 'TW', 'Taiwan'),
(208, 'TJ', 'Tajikistan'),
(209, 'TZ', 'Tanzania, United Republic of'),
(210, 'TH', 'Thailand'),
(211, 'TG', 'Togo'),
(212, 'TK', 'Tokelau'),
(213, 'TO', 'Tonga'),
(214, 'TT', 'Trinidad and Tobago'),
(215, 'TN', 'Tunisia'),
(216, 'TR', 'Turkey'),
(217, 'TM', 'Turkmenistan'),
(218, 'TC', 'Turks and Caicos Islands'),
(219, 'TV', 'Tuvalu'),
(220, 'UG', 'Uganda'),
(221, 'UA', 'Ukraine'),
(222, 'AE', 'United Arab Emirates'),
(223, 'GB', 'United Kingdom'),
(224, 'UM', 'United States minor outlying islands'),
(225, 'UY', 'Uruguay'),
(226, 'UZ', 'Uzbekistan'),
(227, 'VU', 'Vanuatu'),
(228, 'VA', 'Vatican City State'),
(229, 'VE', 'Venezuela'),
(230, 'VN', 'Vietnam'),
(231, 'VG', 'Virigan Islands (British)'),
(232, 'VI', 'Virgin Islands (U.S.)'),
(233, 'WF', 'Wallis and Futuna Islands'),
(234, 'EH', 'Western Sahara'),
(235, 'YE', 'Yemen'),
(236, 'YU', 'Yugoslavia'),
(237, 'ZR', 'Zaire'),
(238, 'ZM', 'Zambia'),
(239, 'ZW', 'Zimbabwe');

-- --------------------------------------------------------

--
-- Table structure for table `feedbacks`
--

CREATE TABLE `feedbacks` (
  `id` int(11) NOT NULL auto_increment,
  `sender` varchar(100) default NULL,
  `body` varchar(5000) NOT NULL,
  `new` tinyint(1) NOT NULL default '1',
  `created` date NOT NULL,
  `modified` date NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `feedbacks`
--

INSERT INTO `feedbacks` (`id`, `sender`, `body`, `new`, `created`, `modified`) VALUES
(1, 'ttt@yy.ccc', 'xcvdfvfdbvdfbvdfc', 0, '2010-07-28', '2010-09-08'),
(2, 'fff@dd.ccc', 'xcsdcsd', 0, '2010-09-08', '2011-02-08');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` int(11) NOT NULL auto_increment,
  `input_txt` varchar(5000) default NULL,
  `output_txt` varchar(5000) default NULL,
  `src_language_id` int(11) NOT NULL,
  `trgt_language_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `trans_type` char(1) NOT NULL default 'S',
  `currency` varchar(1) NOT NULL default 'd',
  `order_title` varchar(500) default NULL,
  `translator_briefing` varchar(5000) default NULL,
  `user_id` int(11) NOT NULL,
  `word_count` int(11) default NULL,
  `total_price` float default NULL,
  `paid` tinyint(1) NOT NULL default '0',
  `key` varchar(100) default NULL,
  `winner_bid_id` int(11) default NULL,
  `created` date default NULL,
  `modified` date default NULL,
  `referance` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `src_language_id` (`src_language_id`),
  KEY `trgt_language_id` (`trgt_language_id`),
  KEY `category_id` (`category_id`),
  KEY `customer_id` (`user_id`),
  KEY `customer_id_2` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `jobs`
--


-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE `languages` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  `created` date default NULL,
  `modified` date default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `name`, `created`, `modified`) VALUES
(1, 'Bosnian', NULL, NULL),
(2, 'Bulgarian', NULL, NULL),
(3, 'Catalan', NULL, NULL),
(4, 'Croatian', NULL, NULL),
(5, 'Danish', NULL, NULL),
(6, 'English', NULL, NULL),
(7, 'French', NULL, NULL),
(8, 'Italian', NULL, NULL),
(10, 'Norwegian', NULL, NULL),
(11, 'Portuguese', NULL, NULL),
(12, 'Russian', NULL, NULL),
(13, 'Slovenian', NULL, NULL),
(14, 'Spanish', NULL, NULL),
(15, 'Turkish', NULL, NULL),
(16, 'White Russian', NULL, NULL),
(17, 'German', NULL, NULL),
(18, 'Polish', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL auto_increment,
  `translator_id` int(11) NOT NULL,
  `user_id` int(11) default NULL,
  `job_id` int(11) NOT NULL,
  `subject` varchar(500) NOT NULL,
  `body` varchar(5000) NOT NULL,
  `created` date NOT NULL,
  `modified` date NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `translator_id` (`translator_id`),
  KEY `job_id` (`job_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `messages`
--


-- --------------------------------------------------------

--
-- Table structure for table `payment_requests`
--

CREATE TABLE `payment_requests` (
  `id` int(11) NOT NULL auto_increment,
  `translator_id` int(11) NOT NULL,
  `paypal_username` varchar(500) NOT NULL,
  `paypal_password` varchar(1000) NOT NULL,
  `paypal_signature` varchar(1000) NOT NULL,
  `amount` float NOT NULL,
  `paid` tinyint(1) NOT NULL default '0',
  `created` date NOT NULL,
  `modified` date NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `translator_id` (`translator_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `payment_requests`
--


-- --------------------------------------------------------

--
-- Table structure for table `prices`
--

CREATE TABLE `prices` (
  `id` int(11) NOT NULL auto_increment,
  `src_language_id` int(11) NOT NULL,
  `trgt_language_id` int(11) NOT NULL,
  `price` float NOT NULL,
  `created` date NOT NULL,
  `modified` date NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `src_language_id_2` (`src_language_id`,`trgt_language_id`),
  KEY `src_language_id` (`src_language_id`),
  KEY `trgt_language_id` (`trgt_language_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `prices`
--

INSERT INTO `prices` (`id`, `src_language_id`, `trgt_language_id`, `price`, `created`, `modified`) VALUES
(1, 6, 17, 14.36, '2010-08-01', '2010-08-01'),
(2, 17, 6, 16.16, '2010-08-01', '2010-08-01'),
(3, 17, 14, 11.51, '2010-08-01', '2010-08-01'),
(4, 17, 12, 11.27, '2010-08-01', '2010-08-01'),
(5, 17, 8, 11.68, '2010-08-01', '2010-08-01'),
(6, 14, 6, 15.16, '2010-08-02', '2010-08-02'),
(7, 6, 14, 11.49, '2010-08-02', '2010-08-02'),
(8, 14, 12, 10.44, '2010-08-02', '2010-08-02'),
(9, 14, 8, 11.75, '2010-08-02', '2010-08-02'),
(10, 14, 7, 14.77, '2010-08-02', '2010-08-02'),
(11, 6, 7, 16.87, '2010-08-02', '2010-08-02'),
(12, 7, 6, 15.16, '2010-08-02', '2010-08-02'),
(13, 7, 12, 9.44, '2010-08-02', '2010-08-02'),
(14, 7, 8, 10.42, '2010-08-02', '2010-08-02'),
(15, 7, 14, 12.64, '2010-08-02', '2010-08-02'),
(16, 6, 8, 10.17, '2010-08-02', '2010-08-02'),
(17, 8, 6, 15.16, '2010-08-02', '2010-08-02'),
(18, 8, 14, 11.68, '2010-08-02', '2010-08-02'),
(19, 8, 17, 14.91, '2010-08-02', '2010-08-02'),
(20, 8, 7, 14.05, '2010-08-02', '2010-08-02'),
(21, 6, 11, 10.77, '2010-08-02', '2010-08-02'),
(22, 11, 6, 15.67, '2010-08-02', '2010-08-02'),
(23, 11, 7, 15.67, '2010-08-02', '2010-08-02'),
(24, 11, 8, 22.25, '2010-08-02', '2010-08-02'),
(25, 11, 18, 8.77, '2010-08-02', '2010-08-02'),
(26, 6, 12, 7.19, '2010-08-02', '2010-08-02'),
(27, 12, 6, 17.69, '2010-08-02', '2010-08-02'),
(28, 12, 17, 15.67, '2010-08-02', '2010-08-02'),
(29, 12, 8, 12.43, '2010-08-02', '2010-08-02');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL auto_increment,
  `key` varchar(100) NOT NULL,
  `value` varchar(500) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `key`, `value`) VALUES
(2, 'auto_accept_translators', '1'),
(1, 'commission', '50'),
(3, 'Contact Us', 'info@gurutranslatorscript.com'),
(4, 'Support', 'support@gurutranslatorscript.com'),
(5, 'noreply', 'info@gurutranslatorscript.com');

-- --------------------------------------------------------

--
-- Table structure for table `translators`
--

CREATE TABLE `translators` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(200) NOT NULL,
  `password` varchar(250) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `sex` char(1) NOT NULL default 'M',
  `company` varchar(250) default NULL,
  `street` varchar(500) NOT NULL,
  `postal_code` varchar(10) NOT NULL,
  `city` varchar(200) NOT NULL,
  `country_id` int(11) default NULL,
  `phone` varchar(100) default NULL,
  `mobile` varchar(100) NOT NULL,
  `experience` varchar(5000) default NULL,
  `cv_file_name` varchar(500) default NULL,
  `professional` char(1) NOT NULL default 'Y',
  `first_language_id` int(11) default NULL,
  `second_language_id` int(11) default NULL,
  `bilingual_desc` varchar(5000) default NULL,
  `language_skills` varchar(1000) default NULL,
  `abroad` char(1) default 'N',
  `specialist_skills` varchar(5000) default NULL,
  `activation_code` varchar(500) default NULL,
  `active` tinyint(1) default NULL,
  `credit` float NOT NULL default '0',
  `state` int(11) NOT NULL default '0',
  `accepted` tinyint(1) NOT NULL default '0',
  `banned` tinyint(1) NOT NULL default '0',
  `created` date default NULL,
  `modified` date default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `email` (`username`),
  KEY `country_id` (`country_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `translators`
--

INSERT INTO `translators` (`id`, `username`, `password`, `first_name`, `last_name`, `sex`, `company`, `street`, `postal_code`, `city`, `country_id`, `phone`, `mobile`, `experience`, `cv_file_name`, `professional`, `first_language_id`, `second_language_id`, `bilingual_desc`, `language_skills`, `abroad`, `specialist_skills`, `activation_code`, `active`, `credit`, `state`, `accepted`, `banned`, `created`, `modified`) VALUES
(1, 'demotrans@demotrans.com', '967e06343305d7753a4873b9188b0ea133948453', 'demotrans', 'demotrans', 'M', 'demotrans', 'demotrans', '789564', 'demotrans', 58, '', '789564321', NULL, NULL, 'Y', NULL, NULL, NULL, NULL, 'N', NULL, '7sejnuweik7gktr9af61tkdhl', 1, 0, 0, 0, 0, '2011-05-05', '2011-05-05');

-- --------------------------------------------------------

--
-- Table structure for table `translator_skills`
--

CREATE TABLE `translator_skills` (
  `id` int(11) NOT NULL auto_increment,
  `translator_id` int(11) NOT NULL,
  `src_language_id` int(11) NOT NULL,
  `trgt_language_id` int(11) NOT NULL,
  `created` date NOT NULL,
  `modified` date NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `translator_id` (`translator_id`,`src_language_id`,`trgt_language_id`),
  KEY `src_language_id` (`src_language_id`,`trgt_language_id`),
  KEY `trgt_language_id` (`trgt_language_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `translator_skills`
--


-- --------------------------------------------------------

--
-- Table structure for table `translator_specialists`
--

CREATE TABLE `translator_specialists` (
  `id` int(11) NOT NULL auto_increment,
  `translator_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `value` varchar(5) NOT NULL,
  `desc` varchar(5000) default NULL,
  `created` date NOT NULL,
  `modified` date NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `translator_id` (`translator_id`,`category_id`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `translator_specialists`
--


-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(100) NOT NULL,
  `password` varchar(500) NOT NULL,
  `sex` char(1) NOT NULL default 'M',
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `company` varchar(500) default NULL,
  `street` varchar(500) NOT NULL,
  `postal_code` varchar(10) NOT NULL,
  `city` varchar(100) NOT NULL,
  `country_id` int(11) default NULL,
  `phone` varchar(20) default NULL,
  `net` char(1) NOT NULL default 'N',
  `birth_day` int(11) default NULL,
  `birth_month` int(11) default NULL,
  `birth_year` int(11) default NULL,
  `language` varchar(1) default 'e',
  `currency` varchar(1) default 'd',
  `fax` varchar(100) default NULL,
  `mobile` varchar(25) default NULL,
  `website` varchar(100) default NULL,
  `messenger_username` varchar(100) default NULL,
  `messenger_type` int(11) default NULL,
  `notifications` tinyint(1) default '0',
  `password_key` varchar(1000) default NULL,
  `created` date default NULL,
  `modified` date default NULL,
  `csv` enum('0','1') NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `country_id` (`country_id`),
  KEY `country_id_2` (`country_id`),
  KEY `country_id_3` (`country_id`),
  KEY `country_id_4` (`country_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `sex`, `first_name`, `last_name`, `company`, `street`, `postal_code`, `city`, `country_id`, `phone`, `net`, `birth_day`, `birth_month`, `birth_year`, `language`, `currency`, `fax`, `mobile`, `website`, `messenger_username`, `messenger_type`, `notifications`, `password_key`, `created`, `modified`, `csv`) VALUES
(1, 'demo@demo.com', '998a737c234b1b44f6c354befa53ece7573678a3', 'M', 'demo', 'demo', 'demo', 'demo', '789654', 'demo', 57, '', '1', NULL, NULL, NULL, 'e', 'd', NULL, NULL, NULL, NULL, NULL, 0, NULL, '2011-05-05', '2011-05-05', '0');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bids`
--
ALTER TABLE `bids`
  ADD CONSTRAINT `bids_ibfk_1` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `bids_ibfk_2` FOREIGN KEY (`translator_id`) REFERENCES `translators` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `certificates`
--
ALTER TABLE `certificates`
  ADD CONSTRAINT `certificates_ibfk_1` FOREIGN KEY (`translator_id`) REFERENCES `translators` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `jobs`
--
ALTER TABLE `jobs`
  ADD CONSTRAINT `jobs_ibfk_1` FOREIGN KEY (`src_language_id`) REFERENCES `languages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `jobs_ibfk_2` FOREIGN KEY (`trgt_language_id`) REFERENCES `languages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `jobs_ibfk_3` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `jobs_ibfk_4` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`translator_id`) REFERENCES `translators` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `messages_ibfk_3` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `messages_ibfk_4` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `payment_requests`
--
ALTER TABLE `payment_requests`
  ADD CONSTRAINT `payment_requests_ibfk_1` FOREIGN KEY (`translator_id`) REFERENCES `translators` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `prices`
--
ALTER TABLE `prices`
  ADD CONSTRAINT `prices_ibfk_1` FOREIGN KEY (`src_language_id`) REFERENCES `languages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `prices_ibfk_2` FOREIGN KEY (`trgt_language_id`) REFERENCES `languages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `translators`
--
ALTER TABLE `translators`
  ADD CONSTRAINT `translators_ibfk_1` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `translator_skills`
--
ALTER TABLE `translator_skills`
  ADD CONSTRAINT `translator_skills_ibfk_1` FOREIGN KEY (`translator_id`) REFERENCES `translators` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `translator_skills_ibfk_2` FOREIGN KEY (`src_language_id`) REFERENCES `languages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `translator_skills_ibfk_3` FOREIGN KEY (`trgt_language_id`) REFERENCES `languages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `translator_specialists`
--
ALTER TABLE `translator_specialists`
  ADD CONSTRAINT `translator_specialists_ibfk_1` FOREIGN KEY (`translator_id`) REFERENCES `translators` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `translator_specialists_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
